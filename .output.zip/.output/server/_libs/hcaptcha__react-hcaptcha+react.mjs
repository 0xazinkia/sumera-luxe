import { i as __toESM, t as __commonJSMin } from "../_runtime.mjs";
//#region node_modules/react/cjs/react.production.js
/**
* @license React
* react.production.js
*
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*/
var require_react_production = /* @__PURE__ */ __commonJSMin(((exports) => {
	var REACT_ELEMENT_TYPE = Symbol.for("react.transitional.element");
	var REACT_PORTAL_TYPE = Symbol.for("react.portal");
	var REACT_FRAGMENT_TYPE = Symbol.for("react.fragment");
	var REACT_STRICT_MODE_TYPE = Symbol.for("react.strict_mode");
	var REACT_PROFILER_TYPE = Symbol.for("react.profiler");
	var REACT_CONSUMER_TYPE = Symbol.for("react.consumer");
	var REACT_CONTEXT_TYPE = Symbol.for("react.context");
	var REACT_FORWARD_REF_TYPE = Symbol.for("react.forward_ref");
	var REACT_SUSPENSE_TYPE = Symbol.for("react.suspense");
	var REACT_MEMO_TYPE = Symbol.for("react.memo");
	var REACT_LAZY_TYPE = Symbol.for("react.lazy");
	var REACT_ACTIVITY_TYPE = Symbol.for("react.activity");
	var MAYBE_ITERATOR_SYMBOL = Symbol.iterator;
	function getIteratorFn(maybeIterable) {
		if (null === maybeIterable || "object" !== typeof maybeIterable) return null;
		maybeIterable = MAYBE_ITERATOR_SYMBOL && maybeIterable[MAYBE_ITERATOR_SYMBOL] || maybeIterable["@@iterator"];
		return "function" === typeof maybeIterable ? maybeIterable : null;
	}
	var ReactNoopUpdateQueue = {
		isMounted: function() {
			return !1;
		},
		enqueueForceUpdate: function() {},
		enqueueReplaceState: function() {},
		enqueueSetState: function() {}
	};
	var assign = Object.assign;
	var emptyObject = {};
	function Component(props, context, updater) {
		this.props = props;
		this.context = context;
		this.refs = emptyObject;
		this.updater = updater || ReactNoopUpdateQueue;
	}
	Component.prototype.isReactComponent = {};
	Component.prototype.setState = function(partialState, callback) {
		if ("object" !== typeof partialState && "function" !== typeof partialState && null != partialState) throw Error("takes an object of state variables to update or a function which returns an object of state variables.");
		this.updater.enqueueSetState(this, partialState, callback, "setState");
	};
	Component.prototype.forceUpdate = function(callback) {
		this.updater.enqueueForceUpdate(this, callback, "forceUpdate");
	};
	function ComponentDummy() {}
	ComponentDummy.prototype = Component.prototype;
	function PureComponent(props, context, updater) {
		this.props = props;
		this.context = context;
		this.refs = emptyObject;
		this.updater = updater || ReactNoopUpdateQueue;
	}
	var pureComponentPrototype = PureComponent.prototype = new ComponentDummy();
	pureComponentPrototype.constructor = PureComponent;
	assign(pureComponentPrototype, Component.prototype);
	pureComponentPrototype.isPureReactComponent = !0;
	var isArrayImpl = Array.isArray;
	function noop() {}
	var ReactSharedInternals = {
		H: null,
		A: null,
		T: null,
		S: null
	};
	var hasOwnProperty = Object.prototype.hasOwnProperty;
	function ReactElement(type, key, props) {
		var refProp = props.ref;
		return {
			$$typeof: REACT_ELEMENT_TYPE,
			type,
			key,
			ref: void 0 !== refProp ? refProp : null,
			props
		};
	}
	function cloneAndReplaceKey(oldElement, newKey) {
		return ReactElement(oldElement.type, newKey, oldElement.props);
	}
	function isValidElement(object) {
		return "object" === typeof object && null !== object && object.$$typeof === REACT_ELEMENT_TYPE;
	}
	function escape(key) {
		var escaperLookup = {
			"=": "=0",
			":": "=2"
		};
		return "$" + key.replace(/[=:]/g, function(match) {
			return escaperLookup[match];
		});
	}
	var userProvidedKeyEscapeRegex = /\/+/g;
	function getElementKey(element, index) {
		return "object" === typeof element && null !== element && null != element.key ? escape("" + element.key) : index.toString(36);
	}
	function resolveThenable(thenable) {
		switch (thenable.status) {
			case "fulfilled": return thenable.value;
			case "rejected": throw thenable.reason;
			default: switch ("string" === typeof thenable.status ? thenable.then(noop, noop) : (thenable.status = "pending", thenable.then(function(fulfilledValue) {
				"pending" === thenable.status && (thenable.status = "fulfilled", thenable.value = fulfilledValue);
			}, function(error) {
				"pending" === thenable.status && (thenable.status = "rejected", thenable.reason = error);
			})), thenable.status) {
				case "fulfilled": return thenable.value;
				case "rejected": throw thenable.reason;
			}
		}
		throw thenable;
	}
	function mapIntoArray(children, array, escapedPrefix, nameSoFar, callback) {
		var type = typeof children;
		if ("undefined" === type || "boolean" === type) children = null;
		var invokeCallback = !1;
		if (null === children) invokeCallback = !0;
		else switch (type) {
			case "bigint":
			case "string":
			case "number":
				invokeCallback = !0;
				break;
			case "object": switch (children.$$typeof) {
				case REACT_ELEMENT_TYPE:
				case REACT_PORTAL_TYPE:
					invokeCallback = !0;
					break;
				case REACT_LAZY_TYPE: return invokeCallback = children._init, mapIntoArray(invokeCallback(children._payload), array, escapedPrefix, nameSoFar, callback);
			}
		}
		if (invokeCallback) return callback = callback(children), invokeCallback = "" === nameSoFar ? "." + getElementKey(children, 0) : nameSoFar, isArrayImpl(callback) ? (escapedPrefix = "", null != invokeCallback && (escapedPrefix = invokeCallback.replace(userProvidedKeyEscapeRegex, "$&/") + "/"), mapIntoArray(callback, array, escapedPrefix, "", function(c) {
			return c;
		})) : null != callback && (isValidElement(callback) && (callback = cloneAndReplaceKey(callback, escapedPrefix + (null == callback.key || children && children.key === callback.key ? "" : ("" + callback.key).replace(userProvidedKeyEscapeRegex, "$&/") + "/") + invokeCallback)), array.push(callback)), 1;
		invokeCallback = 0;
		var nextNamePrefix = "" === nameSoFar ? "." : nameSoFar + ":";
		if (isArrayImpl(children)) for (var i = 0; i < children.length; i++) nameSoFar = children[i], type = nextNamePrefix + getElementKey(nameSoFar, i), invokeCallback += mapIntoArray(nameSoFar, array, escapedPrefix, type, callback);
		else if (i = getIteratorFn(children), "function" === typeof i) for (children = i.call(children), i = 0; !(nameSoFar = children.next()).done;) nameSoFar = nameSoFar.value, type = nextNamePrefix + getElementKey(nameSoFar, i++), invokeCallback += mapIntoArray(nameSoFar, array, escapedPrefix, type, callback);
		else if ("object" === type) {
			if ("function" === typeof children.then) return mapIntoArray(resolveThenable(children), array, escapedPrefix, nameSoFar, callback);
			array = String(children);
			throw Error("Objects are not valid as a React child (found: " + ("[object Object]" === array ? "object with keys {" + Object.keys(children).join(", ") + "}" : array) + "). If you meant to render a collection of children, use an array instead.");
		}
		return invokeCallback;
	}
	function mapChildren(children, func, context) {
		if (null == children) return children;
		var result = [], count = 0;
		mapIntoArray(children, result, "", "", function(child) {
			return func.call(context, child, count++);
		});
		return result;
	}
	function lazyInitializer(payload) {
		if (-1 === payload._status) {
			var ctor = payload._result;
			ctor = ctor();
			ctor.then(function(moduleObject) {
				if (0 === payload._status || -1 === payload._status) payload._status = 1, payload._result = moduleObject;
			}, function(error) {
				if (0 === payload._status || -1 === payload._status) payload._status = 2, payload._result = error;
			});
			-1 === payload._status && (payload._status = 0, payload._result = ctor);
		}
		if (1 === payload._status) return payload._result.default;
		throw payload._result;
	}
	var reportGlobalError = "function" === typeof reportError ? reportError : function(error) {
		if ("object" === typeof window && "function" === typeof window.ErrorEvent) {
			var event = new window.ErrorEvent("error", {
				bubbles: !0,
				cancelable: !0,
				message: "object" === typeof error && null !== error && "string" === typeof error.message ? String(error.message) : String(error),
				error
			});
			if (!window.dispatchEvent(event)) return;
		} else if ("object" === typeof process && "function" === typeof process.emit) {
			process.emit("uncaughtException", error);
			return;
		}
		console.error(error);
	};
	var Children = {
		map: mapChildren,
		forEach: function(children, forEachFunc, forEachContext) {
			mapChildren(children, function() {
				forEachFunc.apply(this, arguments);
			}, forEachContext);
		},
		count: function(children) {
			var n = 0;
			mapChildren(children, function() {
				n++;
			});
			return n;
		},
		toArray: function(children) {
			return mapChildren(children, function(child) {
				return child;
			}) || [];
		},
		only: function(children) {
			if (!isValidElement(children)) throw Error("React.Children.only expected to receive a single React element child.");
			return children;
		}
	};
	exports.Activity = REACT_ACTIVITY_TYPE;
	exports.Children = Children;
	exports.Component = Component;
	exports.Fragment = REACT_FRAGMENT_TYPE;
	exports.Profiler = REACT_PROFILER_TYPE;
	exports.PureComponent = PureComponent;
	exports.StrictMode = REACT_STRICT_MODE_TYPE;
	exports.Suspense = REACT_SUSPENSE_TYPE;
	exports.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = ReactSharedInternals;
	exports.__COMPILER_RUNTIME = {
		__proto__: null,
		c: function(size) {
			return ReactSharedInternals.H.useMemoCache(size);
		}
	};
	exports.cache = function(fn) {
		return function() {
			return fn.apply(null, arguments);
		};
	};
	exports.cacheSignal = function() {
		return null;
	};
	exports.cloneElement = function(element, config, children) {
		if (null === element || void 0 === element) throw Error("The argument must be a React element, but you passed " + element + ".");
		var props = assign({}, element.props), key = element.key;
		if (null != config) for (propName in void 0 !== config.key && (key = "" + config.key), config) !hasOwnProperty.call(config, propName) || "key" === propName || "__self" === propName || "__source" === propName || "ref" === propName && void 0 === config.ref || (props[propName] = config[propName]);
		var propName = arguments.length - 2;
		if (1 === propName) props.children = children;
		else if (1 < propName) {
			for (var childArray = Array(propName), i = 0; i < propName; i++) childArray[i] = arguments[i + 2];
			props.children = childArray;
		}
		return ReactElement(element.type, key, props);
	};
	exports.createContext = function(defaultValue) {
		defaultValue = {
			$$typeof: REACT_CONTEXT_TYPE,
			_currentValue: defaultValue,
			_currentValue2: defaultValue,
			_threadCount: 0,
			Provider: null,
			Consumer: null
		};
		defaultValue.Provider = defaultValue;
		defaultValue.Consumer = {
			$$typeof: REACT_CONSUMER_TYPE,
			_context: defaultValue
		};
		return defaultValue;
	};
	exports.createElement = function(type, config, children) {
		var propName, props = {}, key = null;
		if (null != config) for (propName in void 0 !== config.key && (key = "" + config.key), config) hasOwnProperty.call(config, propName) && "key" !== propName && "__self" !== propName && "__source" !== propName && (props[propName] = config[propName]);
		var childrenLength = arguments.length - 2;
		if (1 === childrenLength) props.children = children;
		else if (1 < childrenLength) {
			for (var childArray = Array(childrenLength), i = 0; i < childrenLength; i++) childArray[i] = arguments[i + 2];
			props.children = childArray;
		}
		if (type && type.defaultProps) for (propName in childrenLength = type.defaultProps, childrenLength) void 0 === props[propName] && (props[propName] = childrenLength[propName]);
		return ReactElement(type, key, props);
	};
	exports.createRef = function() {
		return { current: null };
	};
	exports.forwardRef = function(render) {
		return {
			$$typeof: REACT_FORWARD_REF_TYPE,
			render
		};
	};
	exports.isValidElement = isValidElement;
	exports.lazy = function(ctor) {
		return {
			$$typeof: REACT_LAZY_TYPE,
			_payload: {
				_status: -1,
				_result: ctor
			},
			_init: lazyInitializer
		};
	};
	exports.memo = function(type, compare) {
		return {
			$$typeof: REACT_MEMO_TYPE,
			type,
			compare: void 0 === compare ? null : compare
		};
	};
	exports.startTransition = function(scope) {
		var prevTransition = ReactSharedInternals.T, currentTransition = {};
		ReactSharedInternals.T = currentTransition;
		try {
			var returnValue = scope(), onStartTransitionFinish = ReactSharedInternals.S;
			null !== onStartTransitionFinish && onStartTransitionFinish(currentTransition, returnValue);
			"object" === typeof returnValue && null !== returnValue && "function" === typeof returnValue.then && returnValue.then(noop, reportGlobalError);
		} catch (error) {
			reportGlobalError(error);
		} finally {
			null !== prevTransition && null !== currentTransition.types && (prevTransition.types = currentTransition.types), ReactSharedInternals.T = prevTransition;
		}
	};
	exports.unstable_useCacheRefresh = function() {
		return ReactSharedInternals.H.useCacheRefresh();
	};
	exports.use = function(usable) {
		return ReactSharedInternals.H.use(usable);
	};
	exports.useActionState = function(action, initialState, permalink) {
		return ReactSharedInternals.H.useActionState(action, initialState, permalink);
	};
	exports.useCallback = function(callback, deps) {
		return ReactSharedInternals.H.useCallback(callback, deps);
	};
	exports.useContext = function(Context) {
		return ReactSharedInternals.H.useContext(Context);
	};
	exports.useDebugValue = function() {};
	exports.useDeferredValue = function(value, initialValue) {
		return ReactSharedInternals.H.useDeferredValue(value, initialValue);
	};
	exports.useEffect = function(create, deps) {
		return ReactSharedInternals.H.useEffect(create, deps);
	};
	exports.useEffectEvent = function(callback) {
		return ReactSharedInternals.H.useEffectEvent(callback);
	};
	exports.useId = function() {
		return ReactSharedInternals.H.useId();
	};
	exports.useImperativeHandle = function(ref, create, deps) {
		return ReactSharedInternals.H.useImperativeHandle(ref, create, deps);
	};
	exports.useInsertionEffect = function(create, deps) {
		return ReactSharedInternals.H.useInsertionEffect(create, deps);
	};
	exports.useLayoutEffect = function(create, deps) {
		return ReactSharedInternals.H.useLayoutEffect(create, deps);
	};
	exports.useMemo = function(create, deps) {
		return ReactSharedInternals.H.useMemo(create, deps);
	};
	exports.useOptimistic = function(passthrough, reducer) {
		return ReactSharedInternals.H.useOptimistic(passthrough, reducer);
	};
	exports.useReducer = function(reducer, initialArg, init) {
		return ReactSharedInternals.H.useReducer(reducer, initialArg, init);
	};
	exports.useRef = function(initialValue) {
		return ReactSharedInternals.H.useRef(initialValue);
	};
	exports.useState = function(initialState) {
		return ReactSharedInternals.H.useState(initialState);
	};
	exports.useSyncExternalStore = function(subscribe, getSnapshot, getServerSnapshot) {
		return ReactSharedInternals.H.useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);
	};
	exports.useTransition = function() {
		return ReactSharedInternals.H.useTransition();
	};
	exports.version = "19.2.8";
}));
//#endregion
//#region node_modules/react/index.js
var require_react = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = require_react_production();
}));
//#endregion
//#region node_modules/@hcaptcha/react-hcaptcha/lib/dist/esm/index.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var he = Object.defineProperty;
var le = Object.defineProperties;
var ue = Object.getOwnPropertyDescriptors;
var j = Object.getOwnPropertySymbols;
var V = Object.prototype.hasOwnProperty;
var J = Object.prototype.propertyIsEnumerable;
var q = (t, e, n) => e in t ? he(t, e, {
	enumerable: !0,
	configurable: !0,
	writable: !0,
	value: n
}) : t[e] = n;
var g = (t, e) => {
	for (var n in e || (e = {})) V.call(e, n) && q(t, n, e[n]);
	if (j) for (var n of j(e)) J.call(e, n) && q(t, n, e[n]);
	return t;
};
var K = (t, e) => le(t, ue(e));
var de = (t, e) => {
	var n = {};
	for (var r in t) V.call(t, r) && e.indexOf(r) < 0 && (n[r] = t[r]);
	if (t != null && j) for (var r of j(t)) e.indexOf(r) < 0 && J.call(t, r) && (n[r] = t[r]);
	return n;
};
var l = (t, e, n) => (q(t, typeof e != "symbol" ? e + "" : e, n), n);
var C = (t, e, n) => new Promise((r, i) => {
	var a = (s) => {
		try {
			h(n.next(s));
		} catch (c) {
			i(c);
		}
	}, o = (s) => {
		try {
			h(n.throw(s));
		} catch (c) {
			i(c);
		}
	}, h = (s) => s.done ? r(s.value) : Promise.resolve(s.value).then(a, o);
	h((n = n.apply(t, e)).next());
});
var pe = "hCaptcha-script";
var k = "hCaptchaOnLoad";
var N = "script-error";
var b = "@hCaptcha/loader";
function fe(t) {
	return Object.entries(t).filter(([, e]) => e || e === !1).map(([e, n]) => `${encodeURIComponent(e)}=${encodeURIComponent(String(n))}`).join("&");
}
function G(t) {
	let e = t && t.ownerDocument || document;
	return {
		document: e,
		window: e.defaultView || e.parentWindow || window
	};
}
function X(t) {
	return t || document.head;
}
function me(t) {
	var e;
	t.setTag("source", b), t.setTag("url", document.URL), t.setContext("os", { UA: navigator.userAgent }), t.setContext("browser", g({}, ge())), t.setContext("device", K(g({}, ve()), {
		screen_width_pixels: screen.width,
		screen_height_pixels: screen.height,
		language: navigator.language,
		orientation: ((e = screen.orientation) == null ? void 0 : e.type) || "Unknown",
		processor_count: navigator.hardwareConcurrency,
		platform: navigator.platform
	}));
}
function ge() {
	var t, e, n, r, i, a;
	let o = navigator.userAgent, h, s;
	return o.indexOf("Firefox") !== -1 ? (h = "Firefox", s = (t = o.match(/Firefox\/([\d.]+)/)) == null ? void 0 : t[1]) : o.indexOf("Edg") !== -1 ? (h = "Microsoft Edge", s = (e = o.match(/Edg\/([\d.]+)/)) == null ? void 0 : e[1]) : o.indexOf("Chrome") !== -1 && o.indexOf("Safari") !== -1 ? (h = "Chrome", s = (n = o.match(/Chrome\/([\d.]+)/)) == null ? void 0 : n[1]) : o.indexOf("Safari") !== -1 && o.indexOf("Chrome") === -1 ? (h = "Safari", s = (r = o.match(/Version\/([\d.]+)/)) == null ? void 0 : r[1]) : o.indexOf("Opera") !== -1 || o.indexOf("OPR") !== -1 ? (h = "Opera", s = (i = o.match(/(Opera|OPR)\/([\d.]+)/)) == null ? void 0 : i[2]) : o.indexOf("MSIE") !== -1 || o.indexOf("Trident") !== -1 ? (h = "Internet Explorer", s = (a = o.match(/(MSIE |rv:)([\d.]+)/)) == null ? void 0 : a[2]) : (h = "Unknown", s = "Unknown"), {
		name: h,
		version: s
	};
}
function ye(t) {
	return new Promise((e) => setTimeout(e, t));
}
function ve() {
	let t = navigator.userAgent, e;
	t.indexOf("Win") !== -1 ? e = "Windows" : t.indexOf("Mac") !== -1 ? e = "Mac" : t.indexOf("Linux") !== -1 ? e = "Linux" : t.indexOf("Android") !== -1 ? e = "Android" : t.indexOf("like Mac") !== -1 || t.indexOf("iPhone") !== -1 || t.indexOf("iPad") !== -1 ? e = "iOS" : e = "Unknown";
	let n;
	return /Mobile|iPhone|iPod|Android/i.test(t) ? n = "Mobile" : /Tablet|iPad/i.test(t) ? n = "Tablet" : n = "Desktop", {
		model: e,
		family: e,
		device: n
	};
}
var xe = class Q {
	constructor(e) {
		l(this, "_parent"), l(this, "breadcrumbs", []), l(this, "context", {}), l(this, "extra", {}), l(this, "tags", {}), l(this, "request"), l(this, "user"), this._parent = e;
	}
	get parent() {
		return this._parent;
	}
	child() {
		return new Q(this);
	}
	setRequest(e) {
		return this.request = e, this;
	}
	removeRequest() {
		return this.request = void 0, this;
	}
	addBreadcrumb(e) {
		return typeof e.timestamp > "u" && (e.timestamp = (/* @__PURE__ */ new Date()).toISOString()), this.breadcrumbs.push(e), this;
	}
	setExtra(e, n) {
		return this.extra[e] = n, this;
	}
	removeExtra(e) {
		return delete this.extra[e], this;
	}
	setContext(e, n) {
		return typeof n.type > "u" && (n.type = e), this.context[e] = n, this;
	}
	removeContext(e) {
		return delete this.context[e], this;
	}
	setTags(e) {
		return this.tags = g(g({}, this.tags), e), this;
	}
	setTag(e, n) {
		return this.tags[e] = n, this;
	}
	removeTag(e) {
		return delete this.tags[e], this;
	}
	setUser(e) {
		return this.user = e, this;
	}
	removeUser() {
		return this.user = void 0, this;
	}
	toBody() {
		let e = [], n = this;
		for (; n;) e.push(n), n = n.parent;
		return e.reverse().reduce((r, i) => {
			var a;
			return r.breadcrumbs = [...(a = r.breadcrumbs) != null ? a : [], ...i.breadcrumbs], r.extra = g(g({}, r.extra), i.extra), r.contexts = g(g({}, r.contexts), i.context), r.tags = g(g({}, r.tags), i.tags), i.user && (r.user = i.user), i.request && (r.request = i.request), r;
		}, {
			breadcrumbs: [],
			extra: {},
			contexts: {},
			tags: {},
			request: void 0,
			user: void 0
		});
	}
	clear() {
		this.breadcrumbs = [], this.context = {}, this.tags = {}, this.user = void 0;
	}
};
var be = /^\s*at (?:(.*?) ?\()?((?:file|https?|blob|chrome-extension|address|native|eval|webpack|<anonymous>|[-a-z]+:|.*bundle|\/).*?)(?::(\d+))?(?::(\d+))?\)?\s*$/i;
var we = /^\s*(.*?)(?:\((.*?)\))?(?:^|@)?((?:file|https?|blob|chrome|webpack|resource|moz-extension).*?:\/.*?|\[native code\]|[^@]*(?:bundle|\d+\.js))(?::(\d+))?(?::(\d+))?\s*$/i;
var Ee = /^\s*at (?:((?:\[object object\])?.+) )?\(?((?:file|ms-appx|https?|webpack|blob):.*?):(\d+)(?::(\d+))?\)?\s*$/i;
var Ce = /^(?:(\w+):)\/\/(?:(\w+)(?::(\w+))?@)([\w.-]+)(?::(\d+))?\/(.+)/;
var I = "?";
var W = "An unknown error occurred";
var Re = "0.0.4";
function _e(t) {
	for (let e = 0; e < t.length; e++) t[e] = Math.floor(Math.random() * 256);
	return t;
}
function p(t) {
	return (t + 256).toString(16).substring(1);
}
function Oe() {
	let t = _e(new Array(16));
	return t[6] = t[6] & 15 | 64, t[8] = t[8] & 63 | 128, p(t[0]) + p(t[1]) + p(t[2]) + p(t[3]) + "-" + p(t[4]) + p(t[5]) + "-" + p(t[6]) + p(t[7]) + "-" + p(t[8]) + p(t[9]) + "-" + p(t[10]) + p(t[11]) + p(t[12]) + p(t[13]) + p(t[14]) + p(t[15]);
}
var Pe = [
	[be, "chrome"],
	[Ee, "winjs"],
	[we, "gecko"]
];
function Ie(t) {
	var e, n, r, i;
	if (!t.stack) return null;
	let a = [], o = (r = (n = (e = t.stack).split) == null ? void 0 : n.call(e, `
`)) != null ? r : [];
	for (let h = 0; h < o.length; ++h) {
		let s = null, c = null, u = null;
		for (let [y, v] of Pe) if (c = y.exec(o[h]), c) {
			u = v;
			break;
		}
		if (!(!c || !u)) {
			if (u === "chrome") s = {
				filename: (i = c[2]) != null && i.startsWith("address at ") ? c[2].substring(11) : c[2],
				function: c[1] || I,
				lineno: c[3] ? +c[3] : null,
				colno: c[4] ? +c[4] : null
			};
			else if (u === "winjs") s = {
				filename: c[2],
				function: c[1] || I,
				lineno: +c[3],
				colno: c[4] ? +c[4] : null
			};
			else if (u === "gecko") h === 0 && !c[5] && t.columnNumber !== void 0 && a.length > 0 && (a[0].column = t.columnNumber + 1), s = {
				filename: c[3],
				function: c[1] || I,
				lineno: c[4] ? +c[4] : null,
				colno: c[5] ? +c[5] : null
			};
			else continue;
			!s.function && s.lineno && (s.function = I), a.push(s);
		}
	}
	return a.length ? a.reverse() : null;
}
function Se(t) {
	let e = Ie(t);
	return {
		type: t.name,
		value: t.message,
		stacktrace: { frames: e != null ? e : [] }
	};
}
function ke(t) {
	let e = Ce.exec(t), n = e ? e.slice(1) : [];
	if (n.length !== 6) throw new Error("Invalid DSN");
	let r = n[5].split("/"), i = r.slice(0, -1).join("/");
	return n[0] + "://" + n[3] + (n[4] ? ":" + n[4] : "") + (i ? "/" + i : "") + "/api/" + r.pop() + "/envelope/?sentry_version=7&sentry_key=" + n[1] + (n[2] ? "&sentry_secret=" + n[2] : "");
}
function je(t, e, n) {
	var r, i;
	let a = g({
		event_id: Oe().replaceAll("-", ""),
		platform: "javascript",
		sdk: {
			name: "@hcaptcha/sentry",
			version: Re
		},
		environment: e,
		release: n,
		timestamp: Date.now() / 1e3
	}, t.scope.toBody());
	if (t.type === "exception") {
		a.message = (i = (r = t.error) == null ? void 0 : r.message) != null ? i : "Unknown error", a.fingerprint = [a.message];
		let o = [], h = t.error;
		for (let s = 0; s < 5 && h && (o.push(Se(h)), !(!h.cause || !(h.cause instanceof Error))); s++) h = h.cause;
		a.exception = { values: o.reverse() };
	}
	return t.type === "message" && (a.message = t.message, a.level = t.level), a;
}
function Ae(t) {
	if (t instanceof Error) return t;
	if (typeof t == "string") return new Error(t);
	if (typeof t == "object" && t !== null && !Array.isArray(t)) {
		let n = t, { message: r } = n, i = de(n, ["message"]), a = new Error(typeof r == "string" ? r : W);
		return Object.assign(a, i);
	}
	let e = new Error(W);
	return Object.assign(e, { cause: t });
}
function qe(t, e, n) {
	return C(this, null, function* () {
		var r, i;
		try {
			if (typeof fetch < "u" && typeof AbortSignal < "u") {
				let a;
				if (n) {
					let s = new AbortController();
					a = s.signal, setTimeout(() => s.abort(), n);
				}
				let o = yield fetch(t, K(g({}, e), { signal: a })), h = yield o.text();
				return {
					status: o.status,
					body: h
				};
			}
			return yield new Promise((a, o) => {
				var h, s;
				let c = new XMLHttpRequest();
				if (c.open((h = e == null ? void 0 : e.method) != null ? h : "GET", t), c.onload = () => a({
					status: c.status,
					body: c.responseText
				}), c.onerror = () => o(/* @__PURE__ */ new Error("XHR Network Error")), e == null ? void 0 : e.headers) for (let [u, y] of Object.entries(e.headers)) c.setRequestHeader(u, y);
				if (n) {
					let u = setTimeout(() => {
						c.abort(), o(/* @__PURE__ */ new Error("Request timed out"));
					}, n);
					c.onloadend = () => {
						clearTimeout(u);
					};
				}
				c.send((s = e == null ? void 0 : e.body) == null ? void 0 : s.toString());
			});
		} catch (a) {
			return {
				status: 0,
				body: (i = (r = a == null ? void 0 : a.toString) == null ? void 0 : r.call(a)) != null ? i : "Unknown error"
			};
		}
	});
}
var m;
var L = (m = class {
	constructor(t) {
		l(this, "apiURL"), l(this, "dsn"), l(this, "environment"), l(this, "release"), l(this, "sampleRate"), l(this, "debug"), l(this, "_scope"), l(this, "shouldBuffer", !1), l(this, "bufferlimit", 20), l(this, "buffer", []);
		var e, n, r, i, a;
		this.environment = t.environment, this.release = t.release, this.sampleRate = (e = t.sampleRate) != null ? e : 1, this.debug = (n = t.debug) != null ? n : !1, this._scope = (r = t.scope) != null ? r : new xe(), this.apiURL = ke(t.dsn), this.dsn = t.dsn, this.shouldBuffer = (i = t.buffer) != null ? i : !1, this.bufferlimit = (a = t.bufferLimit) != null ? a : 20;
	}
	static init(t) {
		m._instance || (m._instance = new m(t));
	}
	static get instance() {
		if (!m._instance) throw new Error("Sentry has not been initialized");
		return m._instance;
	}
	log(...t) {
		this.debug && console.log(...t);
	}
	get scope() {
		return this._scope;
	}
	static get scope() {
		return m.instance.scope;
	}
	withScope(t) {
		t(this._scope.child());
	}
	static withScope(t) {
		m.instance.withScope(t);
	}
	captureException(t, e) {
		this.captureEvent({
			type: "exception",
			level: "error",
			error: Ae(t),
			scope: e != null ? e : this._scope
		});
	}
	static captureException(t, e) {
		m.instance.captureException(t, e);
	}
	captureMessage(t, e = "info", n) {
		this.captureEvent({
			type: "message",
			level: e,
			message: t,
			scope: n != null ? n : this._scope
		});
	}
	static captureMessage(t, e = "info", n) {
		m.instance.captureMessage(t, e, n);
	}
	captureEvent(t) {
		if (Math.random() >= this.sampleRate) {
			this.log("Dropped event due to sample rate");
			return;
		}
		if (this.shouldBuffer) {
			if (this.buffer.length >= this.bufferlimit) return;
			this.buffer.push(t);
		} else this.sendEvent(t);
	}
	sendEvent(t, e = 5e3) {
		return C(this, null, function* () {
			try {
				this.log("Sending sentry event", t);
				let n = je(t, this.environment, this.release), r = {
					event_id: n.event_id,
					dsn: this.dsn
				}, a = JSON.stringify(r) + `
` + JSON.stringify({ type: "event" }) + `
` + JSON.stringify(n), o = yield qe(this.apiURL, {
					method: "POST",
					headers: { "Content-Type": "application/x-sentry-envelope" },
					body: a
				}, e);
				this.log("Sentry response", o.status), o.status !== 200 && (console.log(o.body), console.error("Failed to send event to Sentry", o));
			} catch (n) {
				console.error("Failed to send event", n);
			}
		});
	}
	flush(t = 5e3) {
		return C(this, null, function* () {
			try {
				this.log("Flushing sentry events", this.buffer.length);
				let e = this.buffer.splice(0, this.buffer.length).map((n) => this.sendEvent(n, t));
				yield Promise.all(e), this.log("Flushed all events");
			} catch (e) {
				console.error("Failed to flush events", e);
			}
		});
	}
	static flush(t = 5e3) {
		return m.instance.flush(t);
	}
	static reset() {
		m._instance = void 0;
	}
}, l(m, "_instance"), m);
var Le = "https://d233059272824702afc8c43834c4912d@sentry.hcaptcha.com/6";
var Me = "2.3.0";
var Te = "production";
function Ue(t = !0) {
	if (!t) return z();
	L.init({
		dsn: Le,
		release: Me,
		environment: Te
	});
	let e = L.scope;
	return me(e), z(e);
}
function z(t = null) {
	return {
		addBreadcrumb: (e) => {
			t && t.addBreadcrumb(e);
		},
		captureRequest: (e) => {
			t && t.setRequest(e);
		},
		captureException: (e) => {
			t && L.captureException(e, t);
		}
	};
}
function He({ scriptLocation: t, query: e, loadAsync: n = !0, crossOrigin: r = "anonymous", apihost: i = "https://js.hcaptcha.com", cleanup: a = !1, secureApi: o = !1, scriptSource: h = "" } = {}, s) {
	let c = X(t), u = G(c);
	return new Promise((y, v) => {
		let d = u.document.createElement("script");
		d.id = pe, h ? d.src = `${h}?onload=${k}` : o ? d.src = `${i}/1/secure-api.js?onload=${k}` : d.src = `${i}/1/api.js?onload=${k}`, d.crossOrigin = r, d.async = n;
		let w = (x, E) => {
			try {
				!o && a && c.removeChild(d), E(x);
			} catch (P) {
				v(P);
			}
		};
		d.onload = (x) => w(x, y), d.onerror = (x) => {
			s && s(d.src), w(x, v);
		}, d.src += e !== "" ? `&${e}` : "", c.appendChild(d);
	});
}
var S = [];
function Be(t = { cleanup: !1 }, e) {
	try {
		e.addBreadcrumb({
			category: b,
			message: "hCaptcha loader params",
			data: t
		});
		let r = G(X(t.scriptLocation)), i = S.find(({ scope: o }) => o === r.window);
		if (i) return e.addBreadcrumb({
			category: b,
			message: "hCaptcha already loaded"
		}), i.promise;
		let a = new Promise((o, h) => C(this, null, function* () {
			try {
				r.window[k] = () => {
					e.addBreadcrumb({
						category: b,
						message: "hCaptcha script called onload function"
					}), o(r.window.hcaptcha);
				};
				yield He(g({ query: fe({
					custom: t.custom,
					render: t.render,
					sentry: t.sentry,
					assethost: t.assethost,
					imghost: t.imghost,
					reportapi: t.reportapi,
					endpoint: t.endpoint,
					host: t.host,
					recaptchacompat: t.recaptchacompat,
					hl: t.hl,
					uj: t.uj
				}) }, t), (c) => {
					e.captureRequest({
						url: c,
						method: "GET"
					});
				}), e.addBreadcrumb({
					category: b,
					message: "hCaptcha loaded",
					data: i
				});
			} catch (s) {
				e.addBreadcrumb({
					category: b,
					message: "hCaptcha failed to load"
				});
				let c = S.findIndex((u) => u.scope === r.window);
				c !== -1 && S.splice(c, 1), h(new Error(N));
			}
		}));
		return S.push({
			promise: a,
			scope: r.window
		}), a;
	} catch (n) {
		return e.captureException(n), Promise.reject(new Error(N));
	}
}
function Y(t, e, n = 0) {
	return C(this, null, function* () {
		var r, i;
		let a = (r = t.maxRetries) != null ? r : 2, o = (i = t.retryDelay) != null ? i : 1e3, h = n < a ? "Retry loading hCaptcha Api" : "Exceeded maximum retries";
		try {
			return yield Be(t, e);
		} catch (s) {
			return e.addBreadcrumb({
				category: b,
				message: h
			}), n >= a ? (e.captureException(s), Promise.reject(s)) : (e.addBreadcrumb({
				category: b,
				message: `Waiting ${o}ms before retry attempt ${n + 1}`
			}), yield ye(o), n += 1, Y(t, e, n));
		}
	});
}
function Z() {
	return C(this, arguments, function* (t = {}) {
		return yield Y(t, Ue(t.sentry));
	});
}
function M(t) {
	let e = t && t.ownerDocument || document;
	return {
		document: e,
		window: e.defaultView || e.parentWindow || window
	};
}
function T(t) {
	return t || document.head;
}
var O = class extends import_react.Component {
	constructor(e) {
		super(e), this._hcaptcha = void 0, this.renderCaptcha = this.renderCaptcha.bind(this), this.resetCaptcha = this.resetCaptcha.bind(this), this.removeCaptcha = this.removeCaptcha.bind(this), this.isReady = this.isReady.bind(this), this._onReady = null, this.loadCaptcha = this.loadCaptcha.bind(this), this.handleOnLoad = this.handleOnLoad.bind(this), this.handleSubmit = this.handleSubmit.bind(this), this.handleExpire = this.handleExpire.bind(this), this.handleError = this.handleError.bind(this), this.handleOpen = this.handleOpen.bind(this), this.handleClose = this.handleClose.bind(this), this.handleChallengeExpired = this.handleChallengeExpired.bind(this), this.ref = import_react.createRef(), this.apiScriptRequested = !1, this.sentryHub = null, this.captchaId = "", this._pendingExecute = null, this.state = {
			isApiReady: !1,
			isRemoved: !1,
			elementId: e.id
		};
	}
	componentDidMount() {
		let n = M(T(this.props.scriptLocation));
		if (this._hcaptcha = n.window.hcaptcha || void 0, typeof this._hcaptcha != "undefined") {
			this.setState({ isApiReady: !0 }, () => {
				this.renderCaptcha();
			});
			return;
		}
		this.loadCaptcha();
	}
	componentWillUnmount() {
		let e = this._hcaptcha, n = this.captchaId;
		if (this._cancelPendingExecute("react-component-unmounted"), !!this.isReady()) try {
			e.reset(n), e.remove(n);
		} catch (r) {} finally {
			this.captchaId = "", this._onReady = null;
		}
	}
	shouldComponentUpdate(e, n) {
		return !(this.state.isApiReady !== n.isApiReady || this.state.isRemoved !== n.isRemoved);
	}
	componentDidUpdate(e) {
		[
			"sitekey",
			"size",
			"theme",
			"tabindex",
			"languageOverride",
			"endpoint"
		].every((i) => e[i] === this.props[i]) || this.removeCaptcha(() => {
			this.renderCaptcha();
		});
	}
	loadCaptcha() {
		if (this.apiScriptRequested) return;
		let { apihost: e, assethost: n, endpoint: r, host: i, imghost: a, languageOverride: o, reCaptchaCompat: h, reportapi: s, sentry: c, custom: u, loadAsync: y, scriptLocation: v, scriptSource: d, secureApi: w, cleanup: x = !0, userJourneys: E } = this.props;
		Z({
			render: "explicit",
			apihost: e,
			assethost: n,
			endpoint: r,
			hl: o,
			host: i,
			imghost: a,
			recaptchacompat: h === !1 ? "off" : null,
			reportapi: s,
			sentry: c,
			custom: u,
			loadAsync: y,
			scriptLocation: v,
			scriptSource: d,
			secureApi: w,
			cleanup: x,
			uj: E !== void 0 ? E : !1
		}).then(this.handleOnLoad, this.handleError).catch(this.handleError), this.apiScriptRequested = !0;
	}
	renderCaptcha(e) {
		let { onReady: n } = this.props, { isApiReady: r } = this.state, i = this.captchaId;
		if (!r || i) return;
		let a = Object.assign({
			"open-callback": this.handleOpen,
			"close-callback": this.handleClose,
			"error-callback": this.handleError,
			"chalexpired-callback": this.handleChallengeExpired,
			"expired-callback": this.handleExpire,
			callback: this.handleSubmit
		}, this.props, {
			hl: this.props.hl || this.props.languageOverride,
			languageOverride: void 0
		}), h = this._hcaptcha.render(this.ref.current, a);
		this.captchaId = h, this.setState({ isRemoved: !1 }, () => {
			e && e(), n && n(), this._onReady && this._onReady(h);
		});
	}
	resetCaptcha() {
		let e = this._hcaptcha, n = this.captchaId;
		this.isReady() && (e.reset(n), this._cancelPendingExecute("hcaptcha-reset"));
	}
	removeCaptcha(e) {
		let n = this._hcaptcha, r = this.captchaId;
		this._cancelPendingExecute("hcaptcha-removed"), this.isReady() && this.setState({ isRemoved: !0 }, () => {
			this.captchaId = "", n.remove(r), e && e();
		});
	}
	handleOnLoad() {
		this.setState({ isApiReady: !0 }, () => {
			let n = M(T(this.props.scriptLocation));
			this._hcaptcha = n.window.hcaptcha, this.renderCaptcha(() => {
				let { onLoad: r } = this.props;
				r && r();
			});
		});
	}
	handleSubmit(e) {
		let { onVerify: n } = this.props, { isRemoved: r } = this.state, i = this._hcaptcha, a = this.captchaId;
		if (typeof i == "undefined" || r) return;
		let o = i.getResponse(a), h = i.getRespKey(a);
		n && n(o, h);
	}
	handleExpire() {
		let { onExpire: e } = this.props, n = this._hcaptcha, r = this.captchaId;
		this.isReady() && (n.reset(r), e && e());
	}
	handleError(e) {
		let { onError: n } = this.props, r = this._hcaptcha, i = this.captchaId;
		this.isReady() && r.reset(i), n && n(e);
	}
	isReady() {
		let { isApiReady: e, isRemoved: n } = this.state;
		return e && !n;
	}
	_cancelPendingExecute(e) {
		if (!this._pendingExecute) return;
		let n = this._pendingExecute;
		this._pendingExecute = null;
		let r = new Error(e);
		n.reject(r);
	}
	handleOpen() {
		!this.isReady() || !this.props.onOpen || this.props.onOpen();
	}
	handleClose() {
		!this.isReady() || !this.props.onClose || this.props.onClose();
	}
	handleChallengeExpired() {
		!this.isReady() || !this.props.onChalExpired || this.props.onChalExpired();
	}
	execute(e = null) {
		e = typeof e == "object" ? e : null;
		try {
			let n = this._hcaptcha, r = this.captchaId;
			if (e && e.async && this._pendingExecute && this._cancelPendingExecute("hcaptcha-execute-replaced"), !this.isReady()) return e && e.async ? new Promise((a, o) => {
				this._pendingExecute = {
					resolve: a,
					reject: o
				}, this._onReady = (h) => {
					if (this._pendingExecute) try {
						let s = n.execute(h, e);
						s && typeof s.then == "function" ? s.then((c) => {
							this._pendingExecute = null, a(c);
						}).catch((c) => {
							this._pendingExecute = null, o(c);
						}) : (this._pendingExecute = null, o(/* @__PURE__ */ new Error("hcaptcha-execute-no-promise")));
					} catch (s) {
						this._pendingExecute = null, o(s);
					}
				};
			}) : (this._onReady = (a) => {
				n.execute(a, e);
			}, null);
			let i = n.execute(r, e);
			return e && e.async && i && typeof i.then == "function" ? new Promise((a, o) => {
				this._pendingExecute = {
					resolve: a,
					reject: o
				}, i.then((h) => {
					this._pendingExecute = null, a(h);
				}).catch((h) => {
					this._pendingExecute = null, o(h);
				});
			}) : i;
		} catch (n) {
			return e && e.async ? Promise.reject(n) : null;
		}
	}
	close() {
		let e = this._hcaptcha, n = this.captchaId;
		if (this._cancelPendingExecute("hcaptcha-closed"), !!this.isReady()) return e.close(n);
	}
	setData(e) {
		let n = this._hcaptcha, r = this.captchaId;
		this.isReady() && (e && typeof e != "object" && (e = null), n.setData(r, e));
	}
	getResponse() {
		return this._hcaptcha.getResponse(this.captchaId);
	}
	getRespKey() {
		return this._hcaptcha.getRespKey(this.captchaId);
	}
	render() {
		let { elementId: e } = this.state;
		return import_react.createElement("div", {
			ref: this.ref,
			id: e
		});
	}
};
(0, import_react.createContext)();
var re = O;
//#endregion
export { require_react as n, re as t };
