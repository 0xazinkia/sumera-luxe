import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/products.index-BbBqXAeR.js
var $$splitComponentImporter = () => import("./products.index-CoGqHwUF.mjs");
var Route = createFileRoute("/products/")({
	validateSearch: (s) => ({ q: typeof s.q === "string" ? s.q : void 0 }),
	head: () => ({
		meta: [
			{ title: "Shop All Luxury Beauty in Bangladesh — Suméra Luxe" },
			{
				name: "description",
				content: "Shop the full Suméra Luxe collection in Bangladesh — perfume, skincare, makeup, gift sets and bath & body with cash on delivery in Dhaka and nationwide."
			},
			{
				property: "og:title",
				content: "Shop All Luxury Beauty in Bangladesh — Suméra Luxe"
			},
			{
				property: "og:description",
				content: "Luxury perfume, skincare and gifts — cash on delivery across Bangladesh."
			},
			{
				property: "og:locale",
				content: "en_BD"
			},
			{
				property: "og:url",
				content: "https://sumeraluxe.com/products"
			}
		],
		links: [{
			rel: "canonical",
			href: "https://sumeraluxe.com/products"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
