import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.products._id-B-Y4_tCV.js
var $$splitComponentImporter = () => import("./admin.products._id-81czH_G7.mjs");
var Route = createFileRoute("/_authenticated/admin/products/$id")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
//#endregion
export { Route as t };
