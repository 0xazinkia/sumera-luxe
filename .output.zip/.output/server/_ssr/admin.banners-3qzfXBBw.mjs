import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-C1p6U3vi.mjs";
import { n as require_react } from "../_libs/hcaptcha__react-hcaptcha+react.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { i as useQueryClient, n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { a as Upload, g as Plus, k as Image, s as Trash2, v as Pencil } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-CwLzEEob.mjs";
import { i as uploadOptimizedImage, n as isLocalUploadUrl, t as deleteLocalUploads } from "./image-upload-Dmd5qsio.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.banners-3qzfXBBw.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var allBannersQuery = () => ({
	queryKey: ["admin", "banners"],
	queryFn: async () => {
		const { data, error } = await supabase.from("banners").select("*").order("sort_order");
		if (error) throw error;
		return data ?? [];
	}
});
function BannersAdmin() {
	const qc = useQueryClient();
	const items = useQuery(allBannersQuery()).data ?? [];
	const [dialogOpen, setDialogOpen] = (0, import_react.useState)(false);
	const [editingBanner, setEditingBanner] = (0, import_react.useState)(null);
	const [form, setForm] = (0, import_react.useState)({
		slot: "promo",
		image_url: "",
		mobile_image_url: "",
		eyebrow: "",
		title: "",
		subtitle: "",
		cta_label: "",
		cta_href: "",
		is_active: true,
		sort_order: items.length + 1
	});
	const [pendingImageFile, setPendingImageFile] = (0, import_react.useState)(null);
	const [pendingMobileImageFile, setPendingMobileImageFile] = (0, import_react.useState)(null);
	const [resetDesktopImage, setResetDesktopImage] = (0, import_react.useState)(false);
	const [resetMobileImage, setResetMobileImage] = (0, import_react.useState)(false);
	const [saving, setSaving] = (0, import_react.useState)(false);
	const refresh = () => qc.invalidateQueries({ queryKey: ["admin", "banners"] }).then(() => qc.invalidateQueries({ queryKey: ["banners"] }));
	const openCreateDialog = () => {
		setEditingBanner(null);
		setForm({
			slot: "promo",
			image_url: "",
			mobile_image_url: "",
			eyebrow: "",
			title: "",
			subtitle: "",
			cta_label: "",
			cta_href: "",
			is_active: true,
			sort_order: items.length + 1
		});
		setPendingImageFile(null);
		setPendingMobileImageFile(null);
		setResetDesktopImage(false);
		setResetMobileImage(false);
		setDialogOpen(true);
	};
	const openEditDialog = (banner) => {
		setEditingBanner(banner);
		setForm({
			slot: banner.slot,
			image_url: banner.image_url,
			mobile_image_url: banner.mobile_image_url ?? "",
			eyebrow: banner.eyebrow ?? "",
			title: banner.title ?? "",
			subtitle: banner.subtitle ?? "",
			cta_label: banner.cta_label ?? "",
			cta_href: banner.cta_href ?? "",
			sort_order: banner.sort_order,
			is_active: banner.is_active
		});
		setPendingImageFile(null);
		setPendingMobileImageFile(null);
		setResetDesktopImage(false);
		setResetMobileImage(false);
		setDialogOpen(true);
	};
	const closeDialog = () => {
		setDialogOpen(false);
		setEditingBanner(null);
		setPendingImageFile(null);
		setPendingMobileImageFile(null);
	};
	const handleImagePick = (event) => {
		const file = event.target.files?.[0];
		if (!file) return;
		setPendingImageFile(file);
		setResetDesktopImage(false);
		toast.success("Image selected — it will be saved when you click Save");
		event.target.value = "";
	};
	const handleMobileImagePick = (event) => {
		const file = event.target.files?.[0];
		if (!file) return;
		setPendingMobileImageFile(file);
		setResetMobileImage(false);
		toast.success("Mobile image selected — it will be saved when you click Save");
		event.target.value = "";
	};
	const save = async () => {
		if (!form.slot?.trim()) return toast.error("Slot required");
		const oldDesktopUrl = editingBanner?.image_url;
		const oldMobileUrl = editingBanner?.mobile_image_url;
		const deleteOldUrls = [];
		let imageUrl = form.image_url?.trim() || null;
		let mobileImageUrl = form.mobile_image_url?.trim() || null;
		if (pendingImageFile) {
			setSaving(true);
			try {
				const result = await uploadOptimizedImage(pendingImageFile, {
					folder: "banners",
					prefix: `${form.slot.trim()}-desktop`
				});
				imageUrl = result.url;
				if (isLocalUploadUrl(oldDesktopUrl) && oldDesktopUrl !== result.url) deleteOldUrls.push(oldDesktopUrl);
			} finally {
				setSaving(false);
			}
		}
		if (pendingMobileImageFile) {
			setSaving(true);
			try {
				const result = await uploadOptimizedImage(pendingMobileImageFile, {
					folder: "banners",
					prefix: `${form.slot.trim()}-mobile`
				});
				mobileImageUrl = result.url;
				if (isLocalUploadUrl(oldMobileUrl) && oldMobileUrl !== result.url) deleteOldUrls.push(oldMobileUrl);
			} finally {
				setSaving(false);
			}
		}
		if (resetDesktopImage && isLocalUploadUrl(oldDesktopUrl) && oldDesktopUrl !== imageUrl) deleteOldUrls.push(oldDesktopUrl);
		if (resetMobileImage && isLocalUploadUrl(oldMobileUrl) && oldMobileUrl !== mobileImageUrl) deleteOldUrls.push(oldMobileUrl);
		if (!imageUrl) return toast.error("Image required");
		const payload = {
			slot: form.slot.trim(),
			image_url: imageUrl,
			mobile_image_url: mobileImageUrl,
			eyebrow: form.eyebrow?.trim() || null,
			title: form.title?.trim() || null,
			subtitle: form.subtitle?.trim() || null,
			cta_label: form.cta_label?.trim() || null,
			cta_href: form.cta_href?.trim() || null,
			sort_order: Number(form.sort_order) || 0,
			is_active: !!form.is_active
		};
		if (editingBanner) {
			const { error } = await supabase.from("banners").update(payload).eq("id", editingBanner.id);
			if (error) return toast.error(error.message);
			toast.success("Banner updated");
		} else {
			const { error } = await supabase.from("banners").insert(payload);
			if (error) return toast.error(error.message);
			toast.success("Banner added");
		}
		if (deleteOldUrls.length) deleteLocalUploads(deleteOldUrls).catch(() => {
			console.warn("Failed to delete old local banner image(s)", deleteOldUrls);
		});
		setPendingImageFile(null);
		setPendingMobileImageFile(null);
		closeDialog();
		refresh();
	};
	const remove = async (s) => {
		if (!confirm("Delete banner?")) return;
		const { error } = await supabase.from("banners").delete().eq("id", s.id);
		if (error) return toast.error(error.message);
		const localUrls = [s.image_url, s.mobile_image_url].filter(isLocalUploadUrl);
		if (localUrls.length) deleteLocalUploads(localUrls).catch(() => {
			console.warn("Failed to delete local banner images", localUrls);
		});
		refresh();
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-serif text-3xl",
					children: "Promotional Banners"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-xs text-muted-foreground",
					children: "Common slots: home-promo, home-secondary"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: openCreateDialog,
					className: "inline-flex items-center gap-2 bg-foreground px-4 py-2 text-xs uppercase tracking-[0.25em] text-background",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3" }), " Add Banner"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto border border-border",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "bg-muted",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "text-left",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2",
									children: "Banner"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2",
									children: "Slot"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2",
									children: "Order"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2",
									children: "Status"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2 text-right",
									children: "Actions"
								})
							]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [items.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-t border-border",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3",
									children: [s.image_url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: s.image_url,
										alt: "",
										className: "h-10 w-10 rounded object-cover"
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex h-10 w-10 items-center justify-center rounded bg-muted text-muted-foreground",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Image, { className: "size-4" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-medium",
										children: s.title || "Untitled"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs text-muted-foreground",
										children: s.eyebrow || "—"
									})] })]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-2 text-muted-foreground",
								children: s.slot
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-2",
								children: s.sort_order
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-2",
								children: s.is_active ? "Active" : "Inactive"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-end gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: () => openEditDialog(s),
										className: "inline-flex items-center gap-1 border border-border px-3 py-1 text-xs",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-3" }), " Edit"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => remove(s),
										className: "inline-flex items-center gap-1 border border-destructive/40 px-3 py-1 text-xs text-destructive",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3" })
									})]
								})
							})
						]
					}, s.id)), items.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						colSpan: 5,
						className: "px-3 py-8 text-center text-muted-foreground",
						children: "No banners yet."
					}) })] })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: dialogOpen,
				onOpenChange: (open) => open ? setDialogOpen(true) : closeDialog(),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-w-2xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: editingBanner ? "Edit Banner" : "New Banner" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Manage the banner content and save when you are ready." })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-4 sm:grid-cols-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Slot",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: I,
										value: form.slot ?? "",
										onChange: (e) => setForm((p) => ({
											...p,
											slot: e.target.value
										}))
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Image (Required, 1200x380)",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												id: "banner-image-input",
												type: "file",
												accept: "image/*",
												className: "hidden",
												onChange: handleImagePick
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: () => document.getElementById("banner-image-input")?.click(),
												className: "inline-flex items-center gap-1 bg-foreground px-3 py-2 text-xs uppercase tracking-[0.2em] text-background",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-3" }), " Pick file"]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: () => {
													setPendingImageFile(null);
													setForm((p) => ({
														...p,
														image_url: ""
													}));
													setResetDesktopImage(true);
													toast.success("Image cleared — it will be removed when you click Save");
												},
												className: "inline-flex items-center gap-1 border border-border px-3 py-2 text-xs uppercase tracking-[0.2em]",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3" }), " Clear"]
											}),
											pendingImageFile && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs text-muted-foreground",
												children: "New image selected — it will be saved with the banner."
											}),
											form.image_url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
												src: form.image_url,
												alt: "Banner preview",
												className: "h-24 w-full rounded object-cover"
											}) : null
										]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Mobile Image (Optional, 700x550)",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												id: "banner-mobile-image-input",
												type: "file",
												accept: "image/*",
												className: "hidden",
												onChange: handleMobileImagePick
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: () => document.getElementById("banner-mobile-image-input")?.click(),
												className: "inline-flex items-center gap-1 border border-border px-3 py-2 text-xs uppercase tracking-[0.2em]",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-3" }), " Pick file"]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: () => {
													setPendingMobileImageFile(null);
													setForm((p) => ({
														...p,
														mobile_image_url: ""
													}));
													setResetMobileImage(true);
													toast.success("Mobile image cleared — it will be removed when you click Save");
												},
												className: "inline-flex items-center gap-1 border border-border px-3 py-2 text-xs uppercase tracking-[0.2em]",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3" }), " Clear"]
											}),
											pendingMobileImageFile && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs text-muted-foreground",
												children: "New mobile image selected — it will be saved with the banner."
											}),
											form.mobile_image_url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
												src: form.mobile_image_url,
												alt: "Banner mobile preview",
												className: "h-24 w-full rounded object-cover"
											}) : null
										]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Eyebrow (Optional)",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: I,
										value: form.eyebrow ?? "",
										onChange: (e) => setForm((p) => ({
											...p,
											eyebrow: e.target.value
										}))
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Title (Optional)",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: I,
										value: form.title ?? "",
										onChange: (e) => setForm((p) => ({
											...p,
											title: e.target.value
										}))
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Subtitle (Optional)",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: I,
										value: form.subtitle ?? "",
										onChange: (e) => setForm((p) => ({
											...p,
											subtitle: e.target.value
										}))
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "CTA Label (Optional)",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: I,
										value: form.cta_label ?? "",
										onChange: (e) => setForm((p) => ({
											...p,
											cta_label: e.target.value
										}))
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "CTA Link (Optional)",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: I,
										value: form.cta_href ?? "",
										onChange: (e) => setForm((p) => ({
											...p,
											cta_href: e.target.value
										}))
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Order",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "number",
										className: I,
										value: form.sort_order ?? 0,
										onChange: (e) => setForm((p) => ({
											...p,
											sort_order: Number(e.target.value) || 0
										}))
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "flex items-center gap-2 text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "checkbox",
										checked: !!form.is_active,
										onChange: (e) => setForm((p) => ({
											...p,
											is_active: e.target.checked
										}))
									}), "Active"]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, {
							className: "sm:justify-end",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: closeDialog,
								className: "border border-border px-4 py-2 text-xs uppercase tracking-[0.25em]",
								children: "Cancel"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: save,
								disabled: saving,
								className: "bg-foreground px-4 py-2 text-xs uppercase tracking-[0.25em] text-background disabled:opacity-50",
								children: saving ? "Saving…" : "Save"
							})]
						})
					]
				})
			})
		]
	});
}
var I = "w-full border border-border bg-background px-3 py-2 text-sm outline-none focus:border-foreground";
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-1 text-[10px] uppercase tracking-[0.25em] text-muted-foreground",
			children: label
		}), children]
	});
}
//#endregion
export { BannersAdmin as component };
