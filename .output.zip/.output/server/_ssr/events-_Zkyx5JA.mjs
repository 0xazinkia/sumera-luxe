//#region node_modules/.nitro/vite/services/ssr/assets/events-_Zkyx5JA.js
function buildProductItemPayload(product, price, quantity = 1, variantLabel, brandName) {
	return {
		item_id: product.id,
		item_name: product.name,
		item_brand: brandName ?? "Suméra Luxe",
		item_category: product.category?.name ?? void 0,
		item_variant: variantLabel ?? void 0,
		price,
		quantity
	};
}
function buildViewItemPayload(product, price, brandName, pageLocation) {
	return {
		page_location: pageLocation,
		items: [buildProductItemPayload(product, price, 1, void 0, brandName)],
		value: price
	};
}
function buildAddToCartPayload(product, price, quantity, variantLabel, brandName, pageLocation) {
	return {
		page_location: pageLocation,
		items: [buildProductItemPayload(product, price, quantity, variantLabel, brandName)],
		value: price * quantity
	};
}
function buildCheckoutPayload(items, subtotal, delivery, discountAmount, brandName, pageLocation) {
	return {
		page_location: pageLocation,
		items: items.map((item) => ({
			item_id: item.productId,
			item_name: item.name,
			item_brand: brandName ?? "Suméra Luxe",
			item_category: void 0,
			item_variant: item.variantLabel ?? void 0,
			price: item.unitPrice,
			quantity: item.quantity
		})),
		value: Math.max(0, subtotal - discountAmount) + delivery,
		shipping: delivery
	};
}
function buildShippingInfoPayload(district, area, delivery, items, subtotal, discountAmount, brandName, pageLocation) {
	return {
		page_location: pageLocation,
		items: items.map((item) => ({
			item_id: item.productId,
			item_name: item.name,
			item_brand: brandName ?? "Suméra Luxe",
			item_category: void 0,
			item_variant: item.variantLabel ?? void 0,
			price: item.unitPrice,
			quantity: item.quantity
		})),
		value: Math.max(0, subtotal - discountAmount) + delivery,
		shipping: delivery,
		shipping_tier: area === "inside" ? "Inside Dhaka" : "Outside Dhaka",
		custom_data: {
			district,
			delivery_area: area
		}
	};
}
function buildPurchasePayload(orderNumber, total, items, brandName, pageLocation) {
	return {
		page_location: pageLocation,
		items: items.map((item) => ({
			item_id: item.productId,
			item_name: item.name,
			item_brand: brandName ?? "Suméra Luxe",
			item_category: void 0,
			item_variant: item.variantLabel ?? void 0,
			price: item.unitPrice,
			quantity: item.quantity
		})),
		value: total,
		transaction_id: orderNumber || void 0,
		affiliation: brandName ?? "Suméra Luxe"
	};
}
//#endregion
export { buildViewItemPayload as a, buildShippingInfoPayload as i, buildCheckoutPayload as n, buildPurchasePayload as r, buildAddToCartPayload as t };
