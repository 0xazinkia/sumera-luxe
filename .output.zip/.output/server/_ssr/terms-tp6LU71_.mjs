import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as useSiteSettings } from "./hooks-BIqWSPKp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/terms-tp6LU71_.js
var import_jsx_runtime = require_jsx_runtime();
function TermsPage() {
	const s = useSiteSettings();
	const brand = s?.brand_name ?? "Suméra Luxe";
	const email = s?.contact_email ?? "hello@sumeraluxe.com";
	const wa = s?.whatsapp_display ?? "+880 1322-126233";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mx-auto max-w-3xl px-4 py-14 md:px-8 md:py-20",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-[11px] uppercase tracking-[0.35em] text-gold",
					children: "Legal"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 font-serif text-4xl md:text-5xl",
					children: "Terms & Conditions"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "gold-rule mt-4" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-xs text-muted-foreground",
					children: "Last updated: 26 July 2026"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-10 space-y-8 text-[15px] leading-[1.85] text-foreground/85",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					"Welcome to ",
					brand,
					". By browsing our website or placing an order with us, you agree to the following terms. These terms are governed by the laws of the People's Republic of Bangladesh."
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
					title: "1. About us",
					children: [brand, " is a luxury beauty house based in Dhaka, Bangladesh, offering perfumes, skincare, makeup and gifting exclusively to customers within Bangladesh."]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
					title: "2. Orders and acceptance",
					children: "Placing an order through our website or WhatsApp is an offer to buy. An order is only confirmed once our team verifies it by phone or WhatsApp. We reserve the right to refuse or cancel any order — for example if the product is out of stock, the delivery address cannot be verified, or the order appears fraudulent."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
					title: "3. Pricing and payment",
					children: "All prices are shown in Bangladeshi Taka (BDT) and are inclusive of applicable VAT. We currently accept Cash on Delivery only. Delivery charges (Inside Dhaka / Outside Dhaka) are shown at checkout and added to your order total."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
					title: "4. Product information",
					children: "We take care to describe products accurately, but colour, scent and packaging can vary slightly from what is shown on screen. Fragrance is personal — how a perfume performs may vary by skin chemistry and climate."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
					title: "5. Delivery",
					children: [
						"We deliver anywhere in Bangladesh. Estimated delivery is 1–2 working days inside Dhaka and 3–5 working days outside Dhaka. Full details are in our ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "/shipping-returns",
							className: "text-gold underline",
							children: "Shipping & Returns"
						}),
						" policy."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
					title: "6. Returns and refunds",
					children: [
						"Because beauty products are personal-care items, returns are limited to damaged, defective or incorrect items. Please see our",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "/shipping-returns",
							className: "text-gold underline",
							children: " Shipping & Returns "
						}),
						"policy for the full process and eligibility."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
					title: "7. Intellectual property",
					children: [
						"All content on this website — including brand name, logo, photography, product descriptions and design — is the property of",
						" ",
						brand,
						" and may not be copied, reproduced or used for commercial purposes without written permission."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
					title: "8. User conduct",
					children: "You agree not to misuse the website, attempt to gain unauthorised access, or place fraudulent orders. We may block or refuse service to any customer who abuses our team, couriers or policies."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
					title: "9. Limitation of liability",
					children: [brand, " is not liable for any indirect, incidental or consequential loss arising from use of the website or products. Our maximum liability for any order is limited to the amount paid for that order."]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
					title: "10. Governing law",
					children: "These terms are governed by the laws of Bangladesh. Any dispute shall be subject to the exclusive jurisdiction of the courts of Dhaka."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
					title: "11. Contact",
					children: [
						"Questions? Email ",
						email,
						" or WhatsApp ",
						wa,
						"."
					]
				})
			]
		})]
	});
}
function Section({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
		className: "font-serif text-xl",
		children: title
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-2",
		children
	})] });
}
//#endregion
export { TermsPage as component };
