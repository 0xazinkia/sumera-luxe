import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/hcaptcha__react-hcaptcha+react.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/cart-CreAwi5h.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Ctx = (0, import_react.createContext)(null);
var STORAGE = "sumera_cart_v2";
function CartProvider({ children }) {
	const [items, setItems] = (0, import_react.useState)([]);
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		try {
			const raw = localStorage.getItem(STORAGE);
			if (raw) setItems(JSON.parse(raw));
		} catch {}
		setHydrated(true);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!hydrated) return;
		try {
			localStorage.setItem(STORAGE, JSON.stringify(items));
		} catch {}
	}, [items, hydrated]);
	const value = (0, import_react.useMemo)(() => {
		const subtotal = items.reduce((s, l) => s + l.unitPrice * l.quantity, 0);
		const count = items.reduce((s, l) => s + l.quantity, 0);
		return {
			items,
			subtotal,
			count,
			add: (input) => {
				setItems((prev) => {
					const qty = input.quantity ?? 1;
					const idx = prev.findIndex((p) => p.productId === input.productId && p.variantId === input.variantId);
					if (idx >= 0) {
						const next = [...prev];
						next[idx] = {
							...next[idx],
							quantity: next[idx].quantity + qty
						};
						return next;
					}
					return [...prev, {
						...input,
						quantity: qty
					}];
				});
			},
			remove: (productId, variantId) => setItems((prev) => prev.filter((p) => !(p.productId === productId && p.variantId === variantId))),
			setQty: (productId, variantId, quantity) => setItems((prev) => prev.map((p) => p.productId === productId && p.variantId === variantId ? {
				...p,
				quantity: Math.max(1, quantity)
			} : p).filter((p) => p.quantity > 0)),
			clear: () => setItems([])
		};
	}, [items]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ctx.Provider, {
		value,
		children
	});
}
function useCart() {
	const ctx = (0, import_react.useContext)(Ctx);
	if (!ctx) throw new Error("useCart must be used inside <CartProvider>");
	return ctx;
}
//#endregion
export { useCart as n, CartProvider as t };
