import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-C1p6U3vi.mjs";
import { n as require_react } from "../_libs/hcaptcha__react-hcaptcha+react.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as useSiteSettings } from "./hooks-BIqWSPKp.mjs";
import { E as LoaderCircle, b as PackageSearch } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/track-jHpdtM31.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var STATUS_STEPS = [
	"pending",
	"confirmed",
	"shipped",
	"delivered"
];
var STATUS_LABELS = {
	pending: "Order Placed",
	confirmed: "Confirmed",
	shipped: "Shipped",
	delivered: "Delivered",
	cancelled: "Cancelled"
};
function TrackPage() {
	const currency = useSiteSettings()?.currency_symbol ?? "Tk. ";
	const [phone, setPhone] = (0, import_react.useState)("");
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const [orders, setOrders] = (0, import_react.useState)(null);
	async function onSubmit(e) {
		e.preventDefault();
		setError(null);
		setOrders(null);
		if (phone.replace(/\D/g, "").length < 6) {
			setError("Please enter a valid phone number.");
			return;
		}
		setLoading(true);
		const { data, error } = await supabase.rpc("track_orders_by_phone", { _phone: phone });
		setLoading(false);
		if (error) {
			setError(error.message);
			return;
		}
		setOrders(data ?? []);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-3xl px-4 py-14 md:px-8 md:py-20",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[11px] uppercase tracking-[0.35em] text-gold",
						children: "Order Status"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 font-serif text-4xl",
						children: "Track Your Order"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "gold-rule mt-4" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mx-auto mt-4 max-w-md text-sm text-muted-foreground",
						children: "Enter the phone number you used at checkout to see your orders."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit,
				className: "mx-auto mt-10 flex max-w-lg gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						htmlFor: "track-phone",
						className: "sr-only",
						children: "Phone number"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "track-phone",
						name: "phone",
						autoComplete: "tel",
						value: phone,
						onChange: (e) => setPhone(e.target.value),
						placeholder: "Phone number (e.g. 01322126233)",
						className: "flex-1 border border-border bg-background px-4 py-3 text-sm outline-none focus:border-foreground",
						inputMode: "tel"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "submit",
						disabled: loading,
						className: "inline-flex items-center gap-2 bg-foreground px-5 py-3 text-xs uppercase tracking-[0.25em] text-background hover:bg-foreground/85 disabled:opacity-60",
						children: [loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PackageSearch, { className: "size-4" }), "Track"]
					})
				]
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 text-center text-sm text-destructive",
				children: error
			}),
			orders && orders.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-10 text-center text-sm text-muted-foreground",
				children: "No orders found for that phone number."
			}),
			orders && orders.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-10 space-y-6",
				children: orders.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrderCard, {
					order: o,
					currency
				}, o.id))
			})
		]
	});
}
function OrderCard({ order, currency }) {
	const cancelled = order.status === "cancelled";
	const currentIndex = STATUS_STEPS.indexOf(order.status);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "border border-border bg-card p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-wrap items-start justify-between gap-3 border-b border-border pb-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[11px] uppercase tracking-[0.3em] text-muted-foreground",
						children: "Order"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-serif text-xl",
						children: order.order_number
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-1 text-xs text-muted-foreground",
						children: new Date(order.created_at).toLocaleString()
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: `rounded-full px-3 py-1 text-[10px] uppercase tracking-[0.25em] ${cancelled ? "bg-destructive/10 text-destructive" : "bg-gold/15 text-gold"}`,
					children: STATUS_LABELS[order.status] ?? order.status
				})]
			}),
			!cancelled && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "mt-5 grid grid-cols-4 gap-2",
				children: STATUS_STEPS.map((step, i) => {
					const done = i <= currentIndex;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex flex-col items-center gap-2 text-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `grid h-8 w-8 place-items-center rounded-full border text-xs ${done ? "border-gold bg-gold text-primary-foreground" : "border-border text-muted-foreground"}`,
							children: i + 1
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `text-[10px] uppercase tracking-[0.2em] ${done ? "text-foreground" : "text-muted-foreground"}`,
							children: STATUS_LABELS[step]
						})]
					}, step);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 divide-y divide-border",
				children: order.items.map((it, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-3 py-3",
					children: [
						it.image && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: it.image,
							alt: it.name,
							className: "h-14 w-14 rounded-sm object-cover"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex-1 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-medium",
									children: it.name
								}),
								it.variant && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs text-muted-foreground",
									children: it.variant
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-xs text-muted-foreground",
									children: [
										"Qty ",
										it.quantity,
										" × ",
										currency,
										Number(it.unit_price).toLocaleString()
									]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-sm font-medium",
							children: [currency, (Number(it.unit_price) * it.quantity).toLocaleString()]
						})
					]
				}, i))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "mt-4 space-y-1 border-t border-border pt-4 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Subtotal" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", { children: [currency, Number(order.subtotal).toLocaleString()] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Delivery" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", { children: [currency, Number(order.delivery_fee).toLocaleString()] })]
					}),
					Number(order.discount_amount) > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Discount" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", { children: [
							"−",
							currency,
							Number(order.discount_amount).toLocaleString()
						] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between border-t border-border pt-2 font-serif text-lg",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Total" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", { children: [currency, Number(order.total).toLocaleString()] })]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 text-xs text-muted-foreground",
				children: [
					"Ships to ",
					order.customer_name,
					" · ",
					order.address,
					", ",
					order.city
				]
			})
		]
	});
}
//#endregion
export { TrackPage as component };
