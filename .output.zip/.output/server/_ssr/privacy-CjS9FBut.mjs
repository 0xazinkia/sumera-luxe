import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as useSiteSettings } from "./hooks-BIqWSPKp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/privacy-CjS9FBut.js
var import_jsx_runtime = require_jsx_runtime();
function PrivacyPage() {
	const s = useSiteSettings();
	const brand = s?.brand_name ?? "Suméra Luxe";
	const email = s?.contact_email ?? "hello@sumeraluxe.com";
	const wa = s?.whatsapp_display ?? "+880 1322-126233";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mx-auto max-w-3xl px-4 py-14 md:px-8 md:py-20",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-[11px] uppercase tracking-[0.35em] text-gold",
					children: "Legal"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 font-serif text-4xl md:text-5xl",
					children: "Privacy Policy"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "gold-rule mt-4" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-xs text-muted-foreground",
					children: "Last updated: 26 July 2026"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "prose-invert mt-10 space-y-8 text-[15px] leading-[1.85] text-foreground/85",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [brand, " (\"we\", \"us\", \"our\") respects your privacy. This policy explains what personal information we collect from customers in Bangladesh, how we use it and the choices you have. By using sumeraluxe.com or ordering from us, you agree to this policy."] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
					title: "1. Information we collect",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "ml-5 list-disc space-y-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Name, phone number and delivery address you provide at checkout." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Order details, product preferences and purchase history." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Messages you send us over WhatsApp, email or Facebook." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Basic device and usage data, such as page views and location, which help us keep the site working properly." })
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
					title: "2. How we use your information",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "ml-5 list-disc space-y-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "To confirm, pack and deliver your order anywhere in Bangladesh." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "To contact you about your order via phone, SMS or WhatsApp." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "To provide customer care, handle returns and answer questions." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "To improve our website, product mix and service quality." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "To send you offers or new arrivals — only if you have opted in." })
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
					title: "3. Sharing your information",
					children: "We do not sell your personal data. We share the minimum details required with our delivery partners (courier services operating inside and outside Dhaka) so your order can reach you, and with service providers that host our website or send messages on our behalf. All partners are required to keep your data confidential."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
					title: "4. Cash on Delivery",
					children: "For cash-on-delivery orders we do not collect or store any card, bank or mobile financial account details. Payment is handled in person with our courier at the time of delivery."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
					title: "5. Cookies and data usage",
					children: "We use cookies to keep the site functioning smoothly and to improve the shopping experience. You can disable cookies in your browser at any time; some parts of the site may not work as well without them."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
					title: "6. Data retention",
					children: "We keep order and customer data for as long as needed to fulfil your order, provide after-sales care and meet our legal and tax obligations under Bangladesh law."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
					title: "7. Your rights",
					children: [
						"You may ask us to view, correct or delete the personal data we hold about you, or to stop marketing messages, by contacting us at ",
						email,
						" or WhatsApp ",
						wa,
						"."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
					title: "8. Children",
					children: "Our products and site are intended for customers aged 18 and above. We do not knowingly collect data from minors."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
					title: "9. Updates to this policy",
					children: "We may update this policy from time to time. The latest version will always be available on this page with the updated date above."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
					title: "10. Contact us",
					children: [
						brand,
						", Dhaka, Bangladesh. Email: ",
						email,
						". WhatsApp: ",
						wa,
						"."
					]
				})
			]
		})]
	});
}
function Section({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
		className: "font-serif text-xl",
		children: title
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-2",
		children
	})] });
}
//#endregion
export { PrivacyPage as component };
