import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-C1p6U3vi.mjs";
import { n as require_react } from "../_libs/hcaptcha__react-hcaptcha+react.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { i as UserPlus } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.team-ys2-tDMC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function TeamAdmin() {
	const [team, setTeam] = (0, import_react.useState)([]);
	const [email, setEmail] = (0, import_react.useState)("");
	const [role, setRole] = (0, import_react.useState)("staff");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const load = async () => {
		const { data, error } = await supabase.rpc("list_team");
		if (error) return toast.error(error.message);
		setTeam(data ?? []);
	};
	(0, import_react.useEffect)(() => {
		load();
	}, []);
	const change = async (targetEmail, targetRole, grant) => {
		setBusy(true);
		const { error } = await supabase.rpc("set_role_by_email", {
			_email: targetEmail,
			_role: targetRole,
			_grant: grant
		});
		setBusy(false);
		if (error) return toast.error(error.message);
		toast.success(grant ? "Role granted" : "Role removed");
		setEmail("");
		load();
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-serif text-3xl",
				children: "Team & Roles"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "Admins manage everything. Staff can only view and update orders."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end gap-3 border border-border bg-card p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mb-1 text-[10px] uppercase tracking-[0.25em] text-muted-foreground",
							children: "Account Email"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "w-64 border border-border bg-background px-3 py-2 text-sm",
							value: email,
							onChange: (e) => setEmail(e.target.value),
							placeholder: "person@example.com"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mb-1 text-[10px] uppercase tracking-[0.25em] text-muted-foreground",
							children: "Role"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: "border border-border bg-background px-3 py-2 text-sm",
							value: role,
							onChange: (e) => setRole(e.target.value),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "staff",
								children: "Staff"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "admin",
								children: "Admin"
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						disabled: busy || !email,
						onClick: () => change(email, role, true),
						className: "inline-flex items-center gap-2 bg-foreground px-5 py-2.5 text-xs uppercase tracking-[0.25em] text-background disabled:opacity-50",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { className: "size-3" }), " Grant role"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "The person must have signed up at /auth first."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full border-collapse text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-b border-border text-left",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "py-2 pr-3",
							children: "Email"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "py-2 pr-3",
							children: "Role"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {})
					]
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [team.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-b border-border/60",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "py-2 pr-3",
							children: m.email
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "py-2 pr-3 capitalize",
							children: m.role
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "py-2 pr-3 text-right",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => change(m.email, m.role, false),
								className: "text-xs text-destructive underline",
								children: "Remove"
							})
						})
					]
				}, `${m.user_id}_${m.role}`)), team.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					colSpan: 3,
					className: "py-10 text-center text-muted-foreground",
					children: "No team members yet."
				}) })] })]
			})
		]
	});
}
//#endregion
export { TeamAdmin as component };
