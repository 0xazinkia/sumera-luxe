import { P as notFound, m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/products._slug-DUpJVIAX.js
var $$splitNotFoundComponentImporter = () => import("./products._slug-B9-rz_yQ.mjs");
var $$splitComponentImporter = () => import("./products._slug-C73F_NB2.mjs");
var Route = createFileRoute("/products/$slug")({
	loader: async ({ params, context }) => {
		const product = await context.queryClient.ensureQueryData({
			queryKey: ["product", params.slug],
			queryFn: async () => {
				const { productBySlugQuery } = await import("./queries-CN01OqZx.mjs").then((n) => n.l).then((n) => n.l);
				return productBySlugQuery(params.slug).queryFn(void 0);
			}
		});
		if (!product) throw notFound();
		return { product };
	},
	head: ({ loaderData }) => {
		if (!loaderData) return { meta: [{ title: "Product — Suméra Luxe" }, {
			name: "robots",
			content: "noindex"
		}] };
		const { product } = loaderData;
		const brandName = product.brand_name?.trim() || "Suméra Luxe";
		const desc = product.description ?? `${product.name} at ${brandName} Bangladesh — curated luxury beauty with cash on delivery in Dhaka and nationwide.`;
		const image = product.images[0]?.url;
		const url = `https://sumeraluxe.com/products/${product.slug}`;
		const price = Number(product.discount_price ?? product.base_price);
		return {
			meta: [
				{ title: `${product.name} — Buy in Bangladesh | Suméra Luxe` },
				{
					name: "description",
					content: desc
				},
				{
					property: "og:title",
					content: `${product.name} — Buy in Bangladesh | Suméra Luxe`
				},
				{
					property: "og:description",
					content: desc
				},
				{
					property: "og:locale",
					content: "en_BD"
				},
				{
					property: "product:price:amount",
					content: price.toFixed(2)
				},
				{
					property: "product:price:currency",
					content: "BDT"
				},
				{
					property: "og:url",
					content: url
				},
				{
					property: "og:type",
					content: "product"
				},
				...image ? [{
					property: "og:image",
					content: image
				}, {
					name: "twitter:image",
					content: image
				}] : []
			],
			links: [{
				rel: "canonical",
				href: url
			}],
			scripts: [{
				type: "application/ld+json",
				children: JSON.stringify({
					"@context": "https://schema.org",
					"@type": "Product",
					name: product.name,
					description: desc,
					...image ? { image: [image] } : {},
					brand: {
						"@type": "Brand",
						name: brandName
					},
					offers: {
						"@type": "Offer",
						url,
						priceCurrency: "BDT",
						price: price.toFixed(2),
						areaServed: {
							"@type": "Country",
							name: "Bangladesh"
						},
						eligibleRegion: {
							"@type": "Country",
							name: "Bangladesh"
						},
						availability: (product.stock ?? 0) > 0 ? "https://schema.org/InStock" : "https://schema.org/OutOfStock"
					}
				})
			}, {
				type: "application/ld+json",
				children: JSON.stringify({
					"@context": "https://schema.org",
					"@type": "BreadcrumbList",
					itemListElement: [{
						"@type": "ListItem",
						position: 1,
						item: {
							"@id": "https://sumeraluxe.com/",
							name: "Home"
						}
					}, ...product.category ? [{
						"@type": "ListItem",
						position: 2,
						item: {
							"@id": `https://sumeraluxe.com/category/${product.category.slug}`,
							name: product.category.name
						}
					}, {
						"@type": "ListItem",
						position: 3,
						item: {
							"@id": url,
							name: product.name
						}
					}] : [{
						"@type": "ListItem",
						position: 2,
						item: {
							"@id": url,
							name: product.name
						}
					}]]
				})
			}]
		};
	},
	component: lazyRouteComponent($$splitComponentImporter, "component"),
	notFoundComponent: lazyRouteComponent($$splitNotFoundComponentImporter, "notFoundComponent")
});
//#endregion
export { Route as t };
