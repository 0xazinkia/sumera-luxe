import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-C1p6U3vi.mjs";
import { n as require_react } from "../_libs/hcaptcha__react-hcaptcha+react.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { i as useQueryClient, n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { c as productsQuery } from "./queries-CN01OqZx.mjs";
import { _ as useNavigate, g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { N as Copy, g as Plus, m as Search, s as Trash2, v as Pencil } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as isLocalUploadUrl, t as deleteLocalUploads } from "./image-upload-Dmd5qsio.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.products.index-BjOQMJAN.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ProductsAdmin() {
	const qc = useQueryClient();
	const nav = useNavigate();
	const products = useQuery(productsQuery()).data ?? [];
	const [search, setSearch] = (0, import_react.useState)("");
	const [category, setCategory] = (0, import_react.useState)("all");
	const categories = (0, import_react.useMemo)(() => {
		return products.map((p) => p.category?.name).filter(Boolean).filter((name, index, arr) => arr.indexOf(name) === index).sort((a, b) => a.localeCompare(b));
	}, [products]);
	const filteredProducts = (0, import_react.useMemo)(() => {
		const q = search.trim().toLowerCase();
		return products.filter((p) => {
			const matchesCategory = category === "all" || p.category?.name === category;
			const matchesSearch = !q || p.name?.toLowerCase().includes(q);
			return matchesCategory && matchesSearch;
		});
	}, [
		products,
		search,
		category
	]);
	const remove = async (id, name) => {
		if (!confirm(`Delete "${name}"? This removes its variants and images.`)) return;
		const product = products.find((p) => p.id === id);
		const localUrls = [
			product?.size_chart_url,
			...(product?.images ?? []).map((img) => img.url),
			...(product?.variants ?? []).map((variant) => variant.image_url || "")
		].filter(isLocalUploadUrl);
		const { error } = await supabase.from("products").delete().eq("id", id);
		if (error) return toast.error(error.message);
		if (localUrls.length) deleteLocalUploads(localUrls).catch(() => {
			console.warn("Failed to delete local product uploads", localUrls);
		});
		toast.success("Deleted");
		qc.invalidateQueries({ queryKey: ["products"] });
	};
	const copyProductLink = async (slug) => {
		const url = `${window.location.origin}/products/${slug}`;
		try {
			if (navigator.clipboard?.writeText) {
				await navigator.clipboard.writeText(url);
				toast.success("Product link copied");
				return;
			}
		} catch {}
		try {
			const textArea = document.createElement("textarea");
			textArea.value = url;
			textArea.setAttribute("readonly", "");
			textArea.style.position = "fixed";
			textArea.style.top = "-9999px";
			document.body.appendChild(textArea);
			textArea.select();
			document.execCommand("copy");
			document.body.removeChild(textArea);
			toast.success("Product link copied");
		} catch {
			toast.error("Could not copy product link");
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-serif text-3xl",
					children: "Products"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => nav({
						to: "/admin/products/$id",
						params: { id: "new" }
					}),
					className: "inline-flex items-center gap-2 bg-foreground px-4 py-2 text-xs uppercase tracking-[0.25em] text-background",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3" }), " New Product"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-3 rounded-lg border border-border bg-card p-4 sm:flex-row sm:items-center sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative w-full sm:max-w-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: search,
						onChange: (e) => setSearch(e.target.value),
						placeholder: "Search by product name",
						className: "w-full rounded border border-border bg-background py-2 pl-9 pr-3 text-sm outline-none focus:border-foreground"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						htmlFor: "category-filter",
						className: "text-sm text-muted-foreground",
						children: "Category"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						id: "category-filter",
						value: category,
						onChange: (e) => setCategory(e.target.value),
						className: "rounded border border-border bg-background px-3 py-2 text-sm outline-none focus:border-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "all",
							children: "All categories"
						}), categories.map((name) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: name,
							children: name
						}, name))]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto border border-border",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "bg-muted",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "text-left",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2",
									children: "Product"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2",
									children: "Category"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2",
									children: "Price"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2",
									children: "Stock"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2",
									children: "Flags"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2 text-right",
									children: "Actions"
								})
							]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [filteredProducts.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-t border-border",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3",
									children: [p.images[0] && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: p.images[0].url,
										alt: "",
										className: "h-10 w-10 rounded object-cover"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-medium",
										children: p.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-xs text-muted-foreground",
										children: ["/", p.slug]
									})] })]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-2 text-muted-foreground",
								children: p.category?.name ?? "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "px-3 py-2",
								children: ["Tk. ", Number(p.discount_price ?? p.base_price).toLocaleString()]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-2",
								children: p.stock
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-2 text-xs text-muted-foreground",
								children: [p.is_featured && "Featured", p.is_new && "New"].filter(Boolean).join(", ") || "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-end gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											onClick: () => copyProductLink(p.slug),
											className: "inline-flex items-center gap-1 border border-border px-3 py-1 text-xs",
											title: "Copy product link",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-3" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
											to: "/admin/products/$id",
											params: { id: p.id },
											className: "inline-flex items-center gap-1 border border-border px-3 py-1 text-xs",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-3" }), " Edit"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											onClick: () => remove(p.id, p.name),
											className: "inline-flex items-center gap-1 border border-destructive/40 px-3 py-1 text-xs text-destructive",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3" })
										})
									]
								})
							})
						]
					}, p.id)), filteredProducts.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						colSpan: 6,
						className: "px-3 py-8 text-center text-muted-foreground",
						children: "No products match your filters."
					}) })] })]
				})
			})
		]
	});
}
//#endregion
export { ProductsAdmin as component };
