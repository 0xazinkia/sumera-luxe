import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/hcaptcha__react-hcaptcha+react.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { _ as useNavigate, v as useSearch } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-access-DzdDcSmf.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AdminAccessValidator() {
	const navigate = useNavigate();
	const { key } = useSearch({ from: "/admin-access" });
	(0, import_react.useEffect)(() => {
		const validateAndSetCookie = async () => {
			const adminSecretKey = "12111014";
			if (!key) {
				toast.error("Access key required");
				setTimeout(() => navigate({ to: "/" }), 2e3);
				return;
			}
			if (String(key).trim() !== String(adminSecretKey).trim().replace(/^"|"$/g, "")) {
				toast.error(`Invalid access key`);
				setTimeout(() => navigate({ to: "/" }), 2e3);
				return;
			}
			const cookieSecure = window.location.hostname !== "localhost" && !window.location.hostname.startsWith("192.168") ? "; secure" : "";
			document.cookie = `admin_authorized=true; path=/; samesite=strict${cookieSecure}; max-age=2592000`;
			toast.success("Access granted. Redirecting…");
			setTimeout(() => {
				navigate({ to: "/auth" });
			}, 1500);
		};
		validateAndSetCookie();
	}, [key, navigate]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "text-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-semibold",
				children: "Validating access…"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-muted-foreground",
				children: "Please wait"
			})]
		})
	});
}
//#endregion
export { AdminAccessValidator as component };
