import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-C1p6U3vi.mjs";
import { n as require_react } from "../_libs/hcaptcha__react-hcaptcha+react.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { d as validateDiscountCode, u as siteSettingsQuery } from "./queries-CN01OqZx.mjs";
import { _ as useNavigate, g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as useCart } from "./cart-CreAwi5h.mjs";
import { i as trackAddShippingInfo, t as consumePendingBeginCheckoutIntent } from "./helpers-BVzN2yBE.mjs";
import { i as buildShippingInfoPayload, n as buildCheckoutPayload } from "./events-_Zkyx5JA.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/checkout-DEF5KkKr.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var bangladeshDistricts = [
	"Bagerhat",
	"Bandarban",
	"Barguna",
	"Barisal",
	"Bhola",
	"Bogra",
	"Brahmanbaria",
	"Chandpur",
	"Chapainawabganj",
	"Chattogram",
	"Chuadanga",
	"Comilla",
	"Cox's Bazar",
	"Dhaka",
	"Dinajpur",
	"Faridpur",
	"Feni",
	"Gaibandha",
	"Gazipur",
	"Gopalganj",
	"Habiganj",
	"Jamalpur",
	"Jashore",
	"Jhalokati",
	"Jhenaidah",
	"Joypurhat",
	"Khagrachhari",
	"Khulna",
	"Kishoreganj",
	"Kurigram",
	"Kushtia",
	"Lakshmipur",
	"Lalmonirhat",
	"Madaripur",
	"Magura",
	"Manikganj",
	"Meherpur",
	"Moulvibazar",
	"Munshiganj",
	"Mymensingh",
	"Naogaon",
	"Narail",
	"Narayanganj",
	"Narsingdi",
	"Natore",
	"Nawabganj",
	"Netrokona",
	"Nilphamari",
	"Noakhali",
	"Pabna",
	"Panchagarh",
	"Patuakhali",
	"Pirojpur",
	"Rajbari",
	"Rajshahi",
	"Rangamati",
	"Rangpur",
	"Satkhira",
	"Shariatpur",
	"Sherpur",
	"Sirajganj",
	"Sunamganj",
	"Sylhet",
	"Tangail",
	"Thakurgaon"
];
function Checkout() {
	const { items, subtotal, clear } = useCart();
	const settingsQuery = useQuery(siteSettingsQuery());
	const settings = settingsQuery.data ?? null;
	const isSettingsLoading = settingsQuery.isPending || settingsQuery.isFetching;
	const currency = settings?.currency_symbol ?? "Tk. ";
	const insideFee = Number(settings?.delivery_inside_dhaka ?? 60);
	const outsideFee = Number(settings?.delivery_outside_dhaka ?? 120);
	const navigate = useNavigate();
	const [area, setArea] = (0, import_react.useState)("inside");
	const delivery = area === "inside" ? insideFee : outsideFee;
	const getAreaForDistrict = (district) => {
		const normalized = district.trim().toLowerCase();
		return [
			"dhaka",
			"narayanganj",
			"gazipur"
		].includes(normalized) ? "inside" : "outside";
	};
	const [discount, setDiscount] = (0, import_react.useState)(null);
	const [codeInput, setCodeInput] = (0, import_react.useState)("");
	const [codeMsg, setCodeMsg] = (0, import_react.useState)(null);
	const [checkingCode, setCheckingCode] = (0, import_react.useState)(false);
	const discountAmount = discount?.amount ?? 0;
	const total = Math.max(0, subtotal - discountAmount) + delivery;
	const [form, setForm] = (0, import_react.useState)({
		name: "",
		phone: "",
		district: "",
		address: ""
	});
	const [submitting, setSubmitting] = (0, import_react.useState)(false);
	const shippingSignatureRef = (0, import_react.useRef)(null);
	const beginCheckoutConsumedRef = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		if (!form.district) {
			setArea("inside");
			return;
		}
		setArea(getAreaForDistrict(form.district));
	}, [form.district]);
	(0, import_react.useEffect)(() => {
		if (beginCheckoutConsumedRef.current || items.length === 0) return;
		beginCheckoutConsumedRef.current = true;
		consumePendingBeginCheckoutIntent(buildCheckoutPayload(items, subtotal, delivery, discountAmount, settings?.brand_name ?? null, typeof window !== "undefined" ? window.location.href : void 0));
	}, [
		items,
		subtotal,
		delivery,
		discountAmount,
		settings?.brand_name
	]);
	(0, import_react.useEffect)(() => {
		if (items.length === 0 || !form.district) return;
		const signature = `${form.district}|${area}|${delivery}`;
		if (shippingSignatureRef.current === signature) return;
		shippingSignatureRef.current = signature;
		trackAddShippingInfo(buildShippingInfoPayload(form.district, area, delivery, items, subtotal, discountAmount, settings?.brand_name ?? null, typeof window !== "undefined" ? window.location.href : void 0));
	}, [
		area,
		delivery,
		discountAmount,
		form.district,
		items,
		settings?.brand_name,
		subtotal
	]);
	if (isSettingsLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-6xl px-4 py-14 md:px-8 md:py-20",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-4 text-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto h-3 w-24 animate-pulse rounded-full bg-muted/70" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto h-8 w-2/3 animate-pulse rounded bg-muted/70" })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-12 grid gap-10 lg:grid-cols-[1fr_380px]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-4",
				children: Array.from({ length: 3 }).map((_, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-24 animate-pulse rounded-sm bg-muted/60" }, index))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-80 animate-pulse rounded-sm bg-muted/60" })]
		})]
	});
	const applyCode = async () => {
		setCheckingCode(true);
		const res = await validateDiscountCode(codeInput, subtotal);
		setCheckingCode(false);
		if (!res.ok) {
			setDiscount(null);
			setCodeMsg(res.reason);
			return;
		}
		setDiscount({
			code: res.code.code,
			amount: res.amount
		});
		setCodeMsg(null);
		toast.success(`Code ${res.code.code} applied`);
	};
	if (items.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-3xl px-4 py-24 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-serif text-3xl",
			children: "Your bag is empty"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/products",
			search: { q: void 0 },
			className: "mt-6 inline-block underline",
			children: "Continue shopping"
		})]
	});
	const onChange = (k) => (e) => setForm((f) => ({
		...f,
		[k]: e.target.value
	}));
	const submit = async (e) => {
		e.preventDefault();
		setSubmitting(true);
		const { data, error } = await supabase.rpc("place_order", {
			_order: {
				customer_name: form.name,
				phone: form.phone,
				address: form.address,
				city: form.district,
				area: area === "inside" ? "inside_dhaka" : "outside_dhaka",
				discount_code: discount?.code ?? null
			},
			_items: items.map((l) => ({
				product_id: l.productId,
				variant_id: l.variantId ?? null,
				product_name: l.name,
				variant_label: l.variantLabel ?? null,
				quantity: l.quantity,
				image_url: l.image
			}))
		});
		if (error) {
			console.error(error);
			toast.error(error.message || "Could not place order. Please try again or use WhatsApp.");
			setSubmitting(false);
			return;
		}
		const row = Array.isArray(data) ? data[0] : data;
		const orderNumber = row?.order_number ?? "";
		const serverTotal = Number(row?.total ?? total);
		if (typeof window !== "undefined") {
			window.sessionStorage.setItem("sumera_tracking_last_purchase", JSON.stringify({
				orderNumber,
				total: serverTotal,
				items: items.map((item) => ({
					productId: item.productId,
					name: item.name,
					variantLabel: item.variantLabel,
					unitPrice: item.unitPrice,
					quantity: item.quantity
				}))
			}));
			window.sessionStorage.setItem("sumera_tracking_pending_purchase", JSON.stringify({
				orderNumber,
				total: serverTotal,
				items: items.map((item) => ({
					productId: item.productId,
					name: item.name,
					variantLabel: item.variantLabel,
					unitPrice: item.unitPrice,
					quantity: item.quantity
				}))
			}));
		}
		clear();
		navigate({
			to: "/order-success",
			search: {
				total: serverTotal,
				order: orderNumber
			}
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-6xl px-4 py-14 md:px-8 md:py-20",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-[11px] uppercase tracking-[0.35em] text-gold",
					children: "Almost There"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 font-serif text-4xl",
					children: "Checkout"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "gold-rule mt-4" })
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: submit,
			className: "mt-12 grid gap-10 lg:grid-cols-[1fr_380px]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-xl",
						children: "Customer Information"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 grid gap-4 md:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "block",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									htmlFor: "co-name",
									className: "text-xs uppercase tracking-[0.2em] text-muted-foreground",
									children: "Full Name"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									id: "co-name",
									name: "name",
									autoComplete: "name",
									required: true,
									value: form.name,
									onChange: onChange("name"),
									className: "mt-1 w-full border border-border bg-background px-3 py-2.5"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "block",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									htmlFor: "co-phone",
									className: "text-xs uppercase tracking-[0.2em] text-muted-foreground",
									children: "Phone Number"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									id: "co-phone",
									name: "phone",
									autoComplete: "tel",
									required: true,
									type: "tel",
									value: form.phone,
									onChange: onChange("phone"),
									className: "mt-1 w-full border border-border bg-background px-3 py-2.5"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "block md:col-span-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									htmlFor: "co-district",
									className: "text-xs uppercase tracking-[0.2em] text-muted-foreground",
									children: "District"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-1",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										id: "co-district",
										name: "district",
										required: true,
										value: form.district,
										onChange: (e) => setForm((f) => ({
											...f,
											district: e.target.value
										})),
										className: "w-full rounded-md border border-border bg-background px-3 py-2.5 text-sm shadow-sm transition focus:border-foreground focus:outline-none focus:ring-2 focus:ring-gold/20",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "",
											disabled: true,
											children: "Select district"
										}), bangladeshDistricts.map((district) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: district,
											children: district
										}, district))]
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "block md:col-span-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									htmlFor: "co-address",
									className: "text-xs uppercase tracking-[0.2em] text-muted-foreground",
									children: "Full Address"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									id: "co-address",
									name: "address",
									autoComplete: "street-address",
									required: true,
									value: form.address,
									onChange: onChange("address"),
									rows: 3,
									className: "mt-1 w-full border border-border bg-background px-3 py-2.5"
								})]
							})
						]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-xl",
						children: "Delivery Area"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 rounded-lg border border-border bg-muted p-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm font-medium",
								children: area === "inside" ? "Inside Dhaka" : "Outside Dhaka"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-muted-foreground",
								children: "Selected automatically from your district."
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-sm font-medium",
								children: [currency, delivery.toLocaleString()]
							})]
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-xl",
						children: "Payment"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 border border-foreground bg-muted p-4 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-medium",
							children: "Cash on Delivery"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground",
							children: "Pay in cash when your order is delivered."
						})]
					})] })
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "h-fit border border-border bg-card p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-xl",
						children: "Your Order"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 space-y-3 text-sm",
						children: items.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: l.image,
									alt: "",
									className: "h-14 w-14 rounded-sm object-cover"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-sm",
											children: l.name
										}),
										l.variantLabel && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-xs text-muted-foreground",
											children: l.variantLabel
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-xs text-muted-foreground",
											children: ["Qty ", l.quantity]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-sm",
									children: [currency, (l.unitPrice * l.quantity).toLocaleString()]
								})
							]
						}, `${l.productId}_${l.variantId ?? ""}`))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 space-y-1.5 border-t border-border pt-4 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted-foreground",
									children: "Subtotal"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [currency, subtotal.toLocaleString()] })]
							}),
							discount && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between text-gold",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									"Discount (",
									discount.code,
									")"
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									"−",
									currency,
									discountAmount.toLocaleString()
								] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted-foreground",
									children: "Delivery"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [currency, delivery.toLocaleString()] })]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 border-t border-border pt-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[10px] uppercase tracking-[0.25em] text-muted-foreground",
								children: "Discount Code"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										htmlFor: "co-discount",
										className: "sr-only",
										children: "Discount code"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										id: "co-discount",
										name: "discount",
										value: codeInput,
										onChange: (e) => setCodeInput(e.target.value),
										placeholder: "Enter code",
										className: "w-full border border-border bg-background px-3 py-2 text-sm uppercase"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: applyCode,
										disabled: checkingCode,
										className: "shrink-0 border border-foreground px-4 text-xs uppercase tracking-[0.2em] disabled:opacity-50",
										children: checkingCode ? "…" : "Apply"
									})
								]
							}),
							codeMsg && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-xs text-destructive",
								children: codeMsg
							}),
							discount && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									setDiscount(null);
									setCodeInput("");
								},
								className: "mt-2 text-xs text-muted-foreground underline",
								children: "Remove code"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex justify-between border-t border-border pt-3 font-serif text-lg",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Total" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [currency, total.toLocaleString()] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						disabled: submitting,
						className: "mt-6 inline-flex w-full items-center justify-center bg-foreground px-6 py-3 text-xs uppercase tracking-[0.25em] text-background hover:bg-foreground/85 disabled:opacity-50",
						children: submitting ? "Placing…" : "Place Order · COD"
					})
				]
			})]
		})]
	});
}
//#endregion
export { Checkout as component };
