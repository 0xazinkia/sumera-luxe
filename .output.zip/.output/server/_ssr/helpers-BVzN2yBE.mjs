import { t as supabase } from "./client-C1p6U3vi.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/helpers-BVzN2yBE.js
function createEventId(prefix = "evt") {
	if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") return `${prefix}_${crypto.randomUUID()}`;
	return `${prefix}_${Date.now()}_${Math.random().toString(16).slice(2)}`;
}
function createPurchaseEventId(transactionId) {
	const normalized = transactionId?.trim();
	return normalized ? normalized : createEventId("purchase");
}
var isDevelopment = typeof window !== "undefined" && window.location.hostname === "localhost";
function logTrackingEvent(eventName, payload) {
	if (!isDevelopment) return;
	console.groupCollapsed(`[tracking] ${eventName}`);
	console.info(payload);
	console.groupEnd();
}
var EVENT_NAME_MAP = {
	view_item: "ViewContent",
	add_to_cart: "AddToCart",
	begin_checkout: "InitiateCheckout",
	purchase: "Purchase"
};
var RECENT_DISPATCH_WINDOW_MS = 1500;
var recentDispatchSignatures = /* @__PURE__ */ new Map();
function isDuplicateDispatch(signature) {
	const now = Date.now();
	const lastSeen = recentDispatchSignatures.get(signature);
	for (const [key, timestamp] of recentDispatchSignatures) if (now - timestamp > RECENT_DISPATCH_WINDOW_MS) recentDispatchSignatures.delete(key);
	recentDispatchSignatures.set(signature, now);
	return lastSeen !== void 0 && now - lastSeen <= RECENT_DISPATCH_WINDOW_MS;
}
function getCookie$1(name) {
	if (typeof document === "undefined") return null;
	const match = document.cookie.split(";").map((entry) => entry.trim()).find((entry) => entry.startsWith(`${name}=`));
	return match ? decodeURIComponent(match.split("=")[1] ?? "") : null;
}
function dispatchMetaCapiEvent(eventName, eventId, payload, userData = {}) {
	const metaEventName = EVENT_NAME_MAP[eventName];
	if (!metaEventName || typeof window === "undefined") return;
	if (isDuplicateDispatch(`${metaEventName}:${payload.transaction_id ?? ""}:${(payload.content_ids ?? []).join(",")}:${payload.value ?? ""}`)) return;
	const body = {
		event_name: metaEventName,
		event_id: eventId,
		event_time: Math.floor(Date.now() / 1e3),
		event_source_url: payload.event_source_url ?? window.location.href,
		user_data: {
			email: userData.email ?? void 0,
			phone: userData.phone ?? void 0,
			fbp: getCookie$1("_fbp"),
			fbc: getCookie$1("_fbc")
		},
		custom_data: {
			currency: payload.currency,
			value: payload.value,
			content_type: payload.content_type,
			content_ids: payload.content_ids,
			contents: payload.contents,
			num_items: payload.num_items,
			order_id: payload.transaction_id ?? void 0,
			transaction_id: payload.transaction_id ?? void 0
		}
	};
	supabase.functions.invoke("meta-capi", { body }).catch(() => {});
}
function getPageLocation() {
	if (typeof window === "undefined") return "";
	return window.location.href;
}
function getPageTitle() {
	if (typeof window === "undefined") return "";
	return document.title;
}
function getSessionId() {
	if (typeof window === "undefined") return null;
	try {
		const existing = window.sessionStorage.getItem("sumera_tracking_session_id");
		if (existing) return existing;
		const id = createEventId("session");
		window.sessionStorage.setItem("sumera_tracking_session_id", id);
		return id;
	} catch {
		return null;
	}
}
function getUserId() {
	if (typeof window === "undefined") return null;
	try {
		return window.localStorage.getItem("sumera_tracking_user_id");
	} catch {
		return null;
	}
}
function getCookie(name) {
	if (typeof document === "undefined") return null;
	const value = document.cookie.split(";").map((entry) => entry.trim()).find((entry) => entry.startsWith(`${name}=`));
	if (!value) return null;
	return decodeURIComponent(value.split("=")[1] ?? "");
}
function getFbp() {
	return getCookie("_fbp");
}
function getFbc() {
	const cookieValue = getCookie("_fbc");
	if (cookieValue) return cookieValue;
	if (typeof window === "undefined") return null;
	try {
		const fbclid = new URL(window.location.href).searchParams.get("fbclid");
		if (fbclid) {
			const synthesized = `fb.1.${Date.now()}.${fbclid}`;
			window.sessionStorage.setItem("sumera_tracking_fbc_fallback", synthesized);
			return synthesized;
		}
		return window.sessionStorage.getItem("sumera_tracking_fbc_fallback");
	} catch {
		return null;
	}
}
function getClientUserAgent() {
	if (typeof navigator === "undefined") return void 0;
	return navigator.userAgent;
}
function getItemsValue(items) {
	return items.reduce((value, item) => value + item.price * item.quantity, 0);
}
function initializeTracking() {
	if (typeof window === "undefined") return;
	if (!Array.isArray(window.dataLayer)) window.dataLayer = [];
}
function pushDataLayer(eventName, payload = {}) {
	if (typeof window === "undefined") return null;
	initializeTracking();
	const eventTime = payload.timestamp ?? (/* @__PURE__ */ new Date()).toISOString();
	const items = payload.items ?? [];
	const value = typeof payload.value === "number" ? payload.value : getItemsValue(items);
	const currency = payload.currency ?? "BDT";
	const contentIds = payload.content_ids ?? items.map((item) => item.item_id);
	const contents = payload.contents ?? items.map((item) => ({
		id: item.item_id,
		quantity: item.quantity
	}));
	const numItems = payload.num_items ?? items.reduce((sum, item) => sum + item.quantity, 0);
	const event = {
		event: eventName,
		event_id: payload.event_id ?? (eventName === "purchase" ? createPurchaseEventId(payload.transaction_id) : createEventId()),
		timestamp: eventTime,
		page_location: payload.page_location ?? getPageLocation(),
		page_title: payload.page_title ?? getPageTitle(),
		user_id: payload.user_id ?? getUserId(),
		session_id: payload.session_id ?? getSessionId(),
		event_name: eventName,
		event_time: eventTime,
		action_source: payload.action_source ?? "website",
		event_source_url: payload.event_source_url ?? getPageLocation(),
		client_user_agent: payload.client_user_agent ?? getClientUserAgent(),
		fbp: payload.fbp ?? getFbp(),
		fbc: payload.fbc ?? getFbc(),
		user_data: payload.user_data ?? {},
		custom_data: payload.custom_data ?? {},
		ecommerce: {
			currency,
			value,
			shipping: payload.shipping ?? 0,
			tax: payload.tax ?? 0,
			coupon: payload.coupon ?? null,
			transaction_id: payload.transaction_id ?? null,
			items
		},
		currency,
		value,
		transaction_id: payload.transaction_id ?? null,
		items,
		content_ids: contentIds,
		contents,
		content_type: payload.content_type ?? (items.length > 0 ? "product" : "product_group"),
		num_items: numItems,
		shipping_tier: payload.shipping_tier,
		payment_type: payload.payment_type
	};
	const dataLayer = window.dataLayer;
	if (!dataLayer) return event;
	dataLayer.push({ ecommerce: null });
	dataLayer.push(event);
	logTrackingEvent(eventName, event);
	dispatchMetaCapiEvent(eventName, event.event_id, {
		...payload,
		event_source_url: event.event_source_url,
		currency,
		value,
		content_ids: contentIds,
		contents,
		content_type: event.content_type,
		num_items: numItems,
		transaction_id: event.transaction_id
	});
	return event;
}
var BEGIN_CHECKOUT_INTENT_STORAGE_KEY = "sumera_tracking_begin_checkout_intent";
function getBeginCheckoutIntentState() {
	if (typeof window === "undefined") return null;
	try {
		const raw = window.sessionStorage.getItem(BEGIN_CHECKOUT_INTENT_STORAGE_KEY);
		if (!raw) return null;
		const parsed = JSON.parse(raw);
		return parsed && typeof parsed.journeyId === "string" ? parsed : null;
	} catch {
		return null;
	}
}
function setBeginCheckoutIntentState(state) {
	if (typeof window === "undefined") return;
	try {
		if (!state) {
			window.sessionStorage.removeItem(BEGIN_CHECKOUT_INTENT_STORAGE_KEY);
			return;
		}
		window.sessionStorage.setItem(BEGIN_CHECKOUT_INTENT_STORAGE_KEY, JSON.stringify(state));
	} catch {}
}
function requestBeginCheckoutIntent() {
	if (typeof window === "undefined") return false;
	const existing = getBeginCheckoutIntentState();
	if (existing && !existing.fired) return false;
	setBeginCheckoutIntentState({
		journeyId: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
		fired: false
	});
	return true;
}
function consumePendingBeginCheckoutIntent(payload = {}) {
	if (typeof window === "undefined") return false;
	const existing = getBeginCheckoutIntentState();
	if (!existing || existing.fired) return false;
	setBeginCheckoutIntentState({
		...existing,
		fired: true
	});
	return trackBeginCheckout(payload);
}
function trackEvent(eventName, payload = {}) {
	return pushDataLayer(eventName, payload);
}
function trackPageView(payload = {}) {
	return trackEvent("page_view", payload);
}
function trackViewItem(payload = {}) {
	return trackEvent("view_item", payload);
}
function trackAddToCart(payload = {}) {
	return trackEvent("add_to_cart", payload);
}
function trackBeginCheckout(payload = {}) {
	return trackEvent("begin_checkout", payload);
}
function trackAddShippingInfo(payload = {}) {
	return trackEvent("add_shipping_info", payload);
}
function trackPurchase(payload = {}) {
	return trackEvent("purchase", payload);
}
//#endregion
export { trackAddToCart as a, trackViewItem as c, trackAddShippingInfo as i, initializeTracking as n, trackPageView as o, requestBeginCheckoutIntent as r, trackPurchase as s, consumePendingBeginCheckoutIntent as t };
