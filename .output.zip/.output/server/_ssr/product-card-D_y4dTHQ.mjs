import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { u as siteSettingsQuery } from "./queries-CN01OqZx.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/product-card-D_y4dTHQ.js
var import_jsx_runtime = require_jsx_runtime();
function ProductCard({ product }) {
	const settingsQuery = useQuery(siteSettingsQuery());
	const settings = settingsQuery.data ?? null;
	const isSettingsLoading = settingsQuery.isPending || settingsQuery.isFetching;
	const currency = settings?.currency_symbol ?? "Tk. ";
	const firstVariant = product.variants[0];
	const base = Number(product.base_price);
	const discount = product.discount_price == null ? null : Number(product.discount_price);
	const variantPrice = firstVariant ? Number(firstVariant.price) : base;
	const variantDiscount = firstVariant?.discount_price == null ? null : Number(firstVariant.discount_price);
	const isVariantProduct = product.variants?.length > 0;
	const price = isVariantProduct ? variantDiscount ?? variantPrice : discount ?? base;
	const compare = isVariantProduct ? variantPrice : base;
	const hasDiscount = price < compare;
	const off = hasDiscount ? Math.round((compare - price) / compare * 100) : 0;
	const firstImage = product.images[0]?.url ?? firstVariant?.image_url ?? "";
	if (isSettingsLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "group block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "relative overflow-hidden rounded-xl bg-muted",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "aspect-square w-full animate-pulse bg-muted/70" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3 space-y-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto h-4 w-3/4 animate-pulse rounded bg-muted/70" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto h-4 w-1/2 animate-pulse rounded bg-muted/50" })]
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/products/$slug",
		params: { slug: product.slug },
		className: "group block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative overflow-hidden rounded-xl bg-muted",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: firstImage,
					alt: product.name,
					loading: "lazy",
					className: "aspect-square w-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
				}),
				hasDiscount && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "absolute left-3 top-3 rounded-full bg-foreground px-2.5 py-1 text-[10px] font-medium uppercase tracking-wider text-background",
					children: [
						"−",
						off,
						"%"
					]
				}),
				product.stock === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "absolute right-3 top-3 rounded-full bg-destructive px-2.5 py-1 text-[10px] font-medium uppercase tracking-wider text-destructive-foreground",
					children: "Sold out"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "pointer-events-none absolute inset-0 hidden items-end justify-center bg-gradient-to-t from-black/50 to-transparent p-4 opacity-0 transition-opacity duration-300 group-hover:opacity-100 md:flex",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "rounded-full bg-background px-4 py-2 text-xs uppercase tracking-[0.2em] text-foreground",
						children: "View Product"
					})
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3 text-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-serif text-base leading-tight",
				children: product.name
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-1 flex items-baseline justify-center gap-2 text-sm",
				children: [hasDiscount && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-muted-foreground line-through",
					children: [currency, base.toLocaleString()]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "font-medium text-foreground",
					children: [currency, price.toLocaleString()]
				})]
			})]
		})]
	});
}
//#endregion
export { ProductCard as t };
