import { promises } from "node:fs";
import path from "node:path";
//#region node_modules/.nitro/vite/services/ssr/index.js
var lastCapturedError;
var TTL_MS = 5e3;
function record(error) {
	lastCapturedError = {
		error,
		at: Date.now()
	};
}
var CAUSE_DEPTH_LIMIT = 5;
var DESCRIPTION_LENGTH_LIMIT = 8e3;
function describeError(error) {
	const parts = [];
	let current = error;
	for (let depth = 0; depth < CAUSE_DEPTH_LIMIT && current != null; depth++) {
		if (!(current instanceof Error)) {
			parts.push(typeof current === "string" ? current : safeStringify(current));
			break;
		}
		const label = depth === 0 ? "" : "caused by: ";
		const status = describeStatus(current);
		parts.push(`${label}${current.stack ?? `${current.name}: ${current.message}`}${status}`);
		current = current.cause;
	}
	return parts.join("\n").slice(0, DESCRIPTION_LENGTH_LIMIT);
}
function describeStatus(error) {
	const { status, statusCode } = error;
	const value = status ?? statusCode;
	return typeof value === "number" ? ` (status ${value})` : "";
}
function safeStringify(value) {
	try {
		return JSON.stringify(value) ?? String(value);
	} catch {
		return String(value);
	}
}
function isErrorLike(value) {
	return value instanceof Error;
}
var originalConsoleError = console.error.bind(console);
console.error = (...args) => {
	originalConsoleError(...args.map((arg) => {
		if (!isErrorLike(arg)) return arg;
		record(arg);
		return describeError(arg);
	}));
};
if (typeof globalThis.addEventListener === "function") {
	globalThis.addEventListener("error", (event) => record(event.error ?? event));
	globalThis.addEventListener("unhandledrejection", (event) => record(event.reason));
}
function consumeLastCapturedError() {
	if (!lastCapturedError) return void 0;
	if (Date.now() - lastCapturedError.at > TTL_MS) {
		lastCapturedError = void 0;
		return;
	}
	const { error } = lastCapturedError;
	lastCapturedError = void 0;
	return error;
}
function renderErrorPage() {
	return `<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <title>This page didn't load</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <style>
      body { font: 15px/1.5 system-ui, -apple-system, sans-serif; background: #fafafa; color: #111; display: grid; place-items: center; min-height: 100vh; margin: 0; padding: 1.5rem; }
      .card { max-width: 28rem; width: 100%; text-align: center; padding: 2rem; }
      h1 { font-size: 1.25rem; margin: 0 0 0.5rem; }
      p { color: #4b5563; margin: 0 0 1.5rem; }
      .actions { display: flex; gap: 0.5rem; justify-content: center; flex-wrap: wrap; }
      a, button { padding: 0.5rem 1rem; border-radius: 0.375rem; font: inherit; cursor: pointer; text-decoration: none; border: 1px solid transparent; }
      .primary { background: #111; color: #fff; }
      .secondary { background: #fff; color: #111; border-color: #d1d5db; }
    </style>
  </head>
  <body>
    <div class="card">
      <h1>This page didn't load</h1>
      <p>Something went wrong on our end. You can try refreshing or head back home.</p>
      <div class="actions">
        <button class="primary" onclick="location.reload()">Try again</button>
        <a class="secondary" href="/">Go home</a>
      </div>
    </div>
  </body>
</html>`;
}
var serverEntryPromise;
async function getServerEntry() {
	if (!serverEntryPromise) serverEntryPromise = import("./server-CJkdav59.mjs").then((m) => m.default ?? m);
	return serverEntryPromise;
}
async function normalizeCatastrophicSsrResponse(response) {
	if (response.status < 500) return response;
	if (!(response.headers.get("content-type") ?? "").includes("application/json")) return response;
	const body = await response.clone().text();
	if (!isH3SwallowedErrorBody(body)) return response;
	console.error(consumeLastCapturedError() ?? /* @__PURE__ */ new Error(`h3 swallowed SSR error: ${body}`));
	return new Response(renderErrorPage(), {
		status: 500,
		headers: { "content-type": "text/html; charset=utf-8" }
	});
}
function isH3SwallowedErrorBody(body) {
	try {
		const payload = JSON.parse(body);
		return payload.unhandled === true && payload.message === "HTTPError";
	} catch {
		return false;
	}
}
function getCacheControlHeader(pathname, contentType) {
	const ext = path.extname(pathname).toLowerCase();
	if (pathname === "/sitemap.xml") return "public, max-age=3600, stale-while-revalidate=86400";
	if ([
		".js",
		".mjs",
		".cjs",
		".css",
		".json"
	].includes(ext)) return "public, max-age=31536000, immutable";
	if ([
		".png",
		".jpg",
		".jpeg",
		".webp",
		".avif",
		".svg"
	].includes(ext)) return "public, max-age=31536000, immutable";
	if ([
		".woff2",
		".woff",
		".ttf",
		".otf",
		".eot"
	].includes(ext)) return "public, max-age=31536000, immutable";
	if ([".ico", ".txt"].includes(ext)) return "public, max-age=604800, stale-while-revalidate=604800";
	if (contentType.startsWith("image/") && ext === "") return "public, max-age=31536000, immutable";
	return null;
}
function sanitizePathSegment(value) {
	return value.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "").slice(0, 60) || "item";
}
async function handleLocalUpload(request) {
	if (new URL(request.url).pathname !== "/api/upload-image" || request.method !== "POST") return null;
	const formData = await request.formData();
	const file = formData.get("file");
	if (!(file instanceof File)) return new Response(JSON.stringify({ error: "No file provided" }), {
		status: 400,
		headers: { "content-type": "application/json" }
	});
	const folder = sanitizePathSegment(String(formData.get("folder") ?? "uploads"));
	const prefix = sanitizePathSegment(String(formData.get("prefix") ?? "image"));
	const originalName = typeof file.name === "string" ? file.name : "file";
	const extension = path.extname(originalName) || ".bin";
	const fileName = `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}${extension}`;
	const uploadDir = path.resolve(process.cwd(), "public", "uploads", folder);
	await promises.mkdir(uploadDir, { recursive: true });
	const filePath = path.join(uploadDir, fileName);
	const buffer = Buffer.from(await file.arrayBuffer());
	await promises.writeFile(filePath, buffer);
	const publicUrl = `/uploads/${folder}/${fileName}`;
	return Response.json({
		url: publicUrl,
		path: publicUrl
	});
}
async function handleLocalDelete(request) {
	if (new URL(request.url).pathname !== "/api/delete-upload" || request.method !== "POST") return null;
	const body = await request.json().catch(() => null);
	const urls = Array.isArray(body?.urls) ? body.urls : body?.url ? [body.url] : [];
	if (!urls.length) return new Response(JSON.stringify({ error: "No urls provided" }), {
		status: 400,
		headers: { "content-type": "application/json" }
	});
	const uploadRoot = path.resolve(process.cwd(), "public", "uploads");
	const results = {
		deleted: [],
		errors: []
	};
	for (const uploadUrl of urls) try {
		const trimmedPath = new URL(uploadUrl, "http://example.com").pathname.replace(/^\/+/, "");
		if (!trimmedPath.startsWith("uploads/")) continue;
		const filePath = path.resolve(process.cwd(), "public", trimmedPath);
		if (!filePath.startsWith(uploadRoot + path.sep) && filePath !== uploadRoot) {
			results.errors.push({
				url: uploadUrl,
				message: "Invalid local upload path"
			});
			continue;
		}
		await promises.unlink(filePath).catch((error) => {
			if (error?.code === "ENOENT") return;
			throw error;
		});
		results.deleted.push(uploadUrl);
	} catch (error) {
		results.errors.push({
			url: uploadUrl,
			message: error?.message ?? "Delete failed"
		});
	}
	return Response.json(results);
}
var server_default = { async fetch(request, env, ctx) {
	try {
		const localUploadResponse = await handleLocalUpload(request);
		if (localUploadResponse) return localUploadResponse;
		const localDeleteResponse = await handleLocalDelete(request);
		if (localDeleteResponse) return localDeleteResponse;
		const normalizedResponse = await normalizeCatastrophicSsrResponse(await (await getServerEntry()).fetch(request, env, ctx));
		const cacheControl = getCacheControlHeader(new URL(request.url).pathname, normalizedResponse.headers.get("content-type") ?? "");
		if (cacheControl && !normalizedResponse.headers.has("cache-control")) normalizedResponse.headers.set("cache-control", cacheControl);
		return normalizedResponse;
	} catch (error) {
		console.error(error);
		return new Response(renderErrorPage(), {
			status: 500,
			headers: { "content-type": "text/html; charset=utf-8" }
		});
	}
} };
//#endregion
export { server_default as default, renderErrorPage as t };
