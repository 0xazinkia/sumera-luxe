//#region node_modules/.nitro/vite/services/ssr/assets/image-upload-Dmd5qsio.js
function sanitizePathSegment(value) {
	return value.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "").slice(0, 60) || "item";
}
function getFileExtension(fileName) {
	const lastDot = fileName.lastIndexOf(".");
	return lastDot > -1 ? fileName.slice(lastDot) : "";
}
function compressImageToWebp(file) {
	return new Promise((resolve, reject) => {
		const objectUrl = URL.createObjectURL(file);
		const image = new Image();
		image.onload = () => {
			const scale = Math.min(1, 1600 / Math.max(image.width, image.height));
			const canvas = document.createElement("canvas");
			const context = canvas.getContext("2d");
			if (!context) {
				URL.revokeObjectURL(objectUrl);
				reject(/* @__PURE__ */ new Error("Unable to create canvas context"));
				return;
			}
			canvas.width = Math.max(1, Math.round(image.width * scale));
			canvas.height = Math.max(1, Math.round(image.height * scale));
			context.imageSmoothingEnabled = true;
			context.imageSmoothingQuality = "high";
			context.drawImage(image, 0, 0, canvas.width, canvas.height);
			canvas.toBlob((blob) => {
				try {
					if (!blob) {
						reject(/* @__PURE__ */ new Error("Unable to encode image as WebP"));
						return;
					}
					resolve(blob);
				} finally {
					URL.revokeObjectURL(objectUrl);
				}
			}, "image/webp", .95);
		};
		image.onerror = () => {
			URL.revokeObjectURL(objectUrl);
			reject(/* @__PURE__ */ new Error("Unable to read image"));
		};
		image.src = objectUrl;
	});
}
async function uploadFile(file, options) {
	const folder = sanitizePathSegment(options.folder);
	const prefix = sanitizePathSegment(options.prefix ?? "file");
	const safeName = `${prefix}${getFileExtension(file.name || "") || ".bin"}`;
	const formData = new FormData();
	formData.append("file", file, safeName);
	formData.append("folder", folder);
	formData.append("prefix", prefix);
	const response = await fetch("/api/upload-image", {
		method: "POST",
		body: formData
	});
	const payload = await response.json().catch(() => null);
	if (!response.ok || !payload?.url) throw new Error(payload?.error ?? "Upload failed");
	return {
		url: payload.url,
		path: payload.path
	};
}
async function uploadOptimizedImage(file, options) {
	const blob = await compressImageToWebp(file);
	return uploadFile(new File([blob], `${sanitizePathSegment(options.prefix ?? "image")}.webp`, { type: "image/webp" }), options);
}
function isLocalUploadUrl(url) {
	return typeof url === "string" && url.startsWith("/uploads/");
}
async function deleteLocalUploads(urls) {
	if (!urls.length) return {
		deleted: [],
		errors: []
	};
	const response = await fetch("/api/delete-upload", {
		method: "POST",
		headers: { "content-type": "application/json" },
		body: JSON.stringify({ urls })
	});
	const payload = await response.json().catch(() => null);
	if (!response.ok) throw new Error(payload?.error ?? "Failed to delete local uploads");
	return payload;
}
//#endregion
export { uploadOptimizedImage as i, isLocalUploadUrl as n, uploadFile as r, deleteLocalUploads as t };
