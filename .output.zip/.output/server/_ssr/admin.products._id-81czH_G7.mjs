import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-C1p6U3vi.mjs";
import { n as require_react } from "../_libs/hcaptcha__react-hcaptcha+react.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { i as useQueryClient, n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { c as productsQuery, n as categoriesQuery } from "./queries-CN01OqZx.mjs";
import { _ as useNavigate, g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { B as ArrowDown, R as ArrowUp, a as Upload, g as Plus, h as Save, s as Trash2, v as Pencil, z as ArrowLeft } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-CwLzEEob.mjs";
import { i as uploadOptimizedImage, n as isLocalUploadUrl, r as uploadFile, t as deleteLocalUploads } from "./image-upload-Dmd5qsio.mjs";
import { t as Route } from "./admin.products._id-B-Y4_tCV.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.products._id-81czH_G7.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function slugify(s) {
	return s.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
}
var emptyProduct = {
	name: "",
	slug: "",
	brand_name: "",
	description: "",
	video_url: "",
	size_chart_url: null,
	base_price: 0,
	discount_price: null,
	stock: 0,
	is_featured: false,
	is_new: false,
	sort_order: 0,
	category_id: null,
	images: [],
	variants: []
};
function ProductEditor() {
	const { id } = Route.useParams();
	const isNew = id === "new";
	const qc = useQueryClient();
	const nav = useNavigate();
	const categories = useQuery(categoriesQuery()).data ?? [];
	const productsData = useQuery(productsQuery()).data ?? [];
	const existing = !isNew ? productsData.find((p) => p.id === id) : void 0;
	const [form, setForm] = (0, import_react.useState)(emptyProduct);
	const [images, setImages] = (0, import_react.useState)([]);
	const [variants, setVariants] = (0, import_react.useState)([]);
	const [productMode, setProductMode] = (0, import_react.useState)("single");
	const [variantDialogOpen, setVariantDialogOpen] = (0, import_react.useState)(false);
	const [editingVariantIndex, setEditingVariantIndex] = (0, import_react.useState)(null);
	const [variantForm, setVariantForm] = (0, import_react.useState)({
		color: "",
		size: "",
		price: 0,
		discount_price: null,
		image_url: "",
		stock: 0
	});
	const [saving, setSaving] = (0, import_react.useState)(false);
	const [uploadingImage, setUploadingImage] = (0, import_react.useState)(false);
	const [pendingProductImageFiles, setPendingProductImageFiles] = (0, import_react.useState)(/* @__PURE__ */ new Map());
	const [pendingSizeChartFile, setPendingSizeChartFile] = (0, import_react.useState)(null);
	const lastVariantColorRef = (0, import_react.useRef)(null);
	const immediateUploadedVariantUrls = (0, import_react.useRef)(/* @__PURE__ */ new Set());
	const latestVariantsRef = (0, import_react.useRef)([]);
	const isVariantExisting = !isNew && (existing?.variants?.length ?? 0) > 0;
	(0, import_react.useEffect)(() => {
		if (existing) {
			const nextVariants = existing.variants ?? [];
			setForm(existing);
			setImages(existing.images);
			setVariants(nextVariants);
			latestVariantsRef.current = nextVariants;
			setProductMode((existing.variants?.length ?? 0) > 0 ? "variant" : "single");
		} else {
			setForm(emptyProduct);
			setImages([]);
			setVariants([]);
			latestVariantsRef.current = [];
			setProductMode("single");
		}
	}, [existing?.id, isNew]);
	(0, import_react.useEffect)(() => {
		latestVariantsRef.current = variants;
	}, [variants]);
	const set = (k, v) => setForm((p) => ({
		...p,
		[k]: v
	}));
	const emptyVariantForm = () => ({
		color: "",
		size: "",
		price: 0,
		discount_price: null,
		image_url: "",
		stock: 0
	});
	const openAddVariantDialog = () => {
		setEditingVariantIndex(null);
		const lastVariant = variants[variants.length - 1];
		lastVariantColorRef.current = lastVariant?.color ?? null;
		setVariantForm(lastVariant ? {
			color: lastVariant.color ?? "",
			size: "",
			price: lastVariant.price ?? 0,
			discount_price: lastVariant.discount_price ?? null,
			image_url: lastVariant.image_url ?? "",
			stock: lastVariant.stock ?? 0
		} : emptyVariantForm());
		setVariantDialogOpen(true);
	};
	const openEditVariantDialog = (index) => {
		setEditingVariantIndex(index);
		setVariantForm(variants[index] ?? emptyVariantForm());
		setVariantDialogOpen(true);
	};
	const closeVariantDialog = () => {
		setVariantDialogOpen(false);
		setEditingVariantIndex(null);
	};
	const getVariantDraft = (draftForm = variantForm, currentVariants = variants) => {
		const cleaned = {
			color: draftForm.color?.trim(),
			size: draftForm.size?.trim() || null,
			price: Number(draftForm.price) || 0,
			discount_price: draftForm.discount_price != null && draftForm.discount_price !== "" ? Number(draftForm.discount_price) : null,
			image_url: draftForm.image_url?.trim() || null,
			stock: Number(draftForm.stock) || 0,
			sort_order: editingVariantIndex != null ? currentVariants[editingVariantIndex]?.sort_order ?? editingVariantIndex : currentVariants.length
		};
		return editingVariantIndex != null ? currentVariants.map((v, i) => i === editingVariantIndex ? {
			...currentVariants[i],
			...cleaned
		} : v) : [...currentVariants, cleaned];
	};
	const getActiveVariants = (draftForm) => {
		const baseVariants = latestVariantsRef.current.length ? latestVariantsRef.current : variants;
		if (draftForm && variantDialogOpen && draftForm.color?.trim()) {
			const nextVariants = getVariantDraft(draftForm, baseVariants);
			latestVariantsRef.current = nextVariants;
			setVariants(nextVariants);
			return nextVariants;
		}
		return baseVariants;
	};
	const saveVariant = () => {
		if (!variantForm.color?.trim()) return toast.error("Color is required");
		getActiveVariants(variantForm);
		closeVariantDialog();
	};
	const removeVariant = (index) => {
		const removedVariant = variants[index];
		const nextVariants = variants.filter((_, j) => j !== index);
		latestVariantsRef.current = nextVariants;
		setVariants(nextVariants);
		if (removedVariant?.image_url && isLocalUploadUrl(removedVariant.image_url)) {
			immediateUploadedVariantUrls.current.delete(removedVariant.image_url);
			immediateUploadedVariantUrls.current.add(removedVariant.image_url);
		}
	};
	const handleProductModeChange = (mode) => {
		if (mode === "single" && isVariantExisting) {
			toast.error("Cannot switch to single product while editing a product with variants");
			return;
		}
		setProductMode(mode);
		if (mode === "single") setVariants([]);
	};
	const moveImage = (from, to) => {
		if (to < 0 || to >= images.length) return;
		const next = [...images];
		const [moved] = next.splice(from, 1);
		next.splice(to, 0, moved);
		setImages(next.map((img, idx) => ({
			...img,
			sort_order: idx
		})));
	};
	const handleImagePick = async (event, target, index) => {
		const file = event.target.files?.[0];
		if (!file) return;
		event.target.value = "";
		if (target === "variant") {
			setUploadingImage(true);
			try {
				const result = await uploadOptimizedImage(file, {
					folder: "variant-images",
					prefix: variantForm.color || "variant"
				});
				setVariantForm((prev) => ({
					...prev,
					image_url: result.url
				}));
				immediateUploadedVariantUrls.current.add(result.url);
				toast.success("Image uploaded");
			} catch (e) {
				toast.error(e.message ?? "Failed to upload image");
			} finally {
				setUploadingImage(false);
			}
		} else if (index != null) {
			setPendingProductImageFiles((prev) => new Map(prev).set(index, file));
			toast.success("Image selected — it will be saved when you click Save");
		}
	};
	const handleSizeChartPick = (event) => {
		const file = event.target.files?.[0];
		if (!file) return;
		setPendingSizeChartFile(file);
		toast.success("Size chart selected — it will be saved when you click Save");
		event.target.value = "";
	};
	const save = async () => {
		if (!form.name?.trim()) return toast.error("Name required");
		if (!form.brand_name?.trim()) return toast.error("Brand name required");
		const slug = form.slug || slugify(form.name);
		let uploadedSizeChartUrl = form.size_chart_url?.toString().trim() ? form.size_chart_url.toString().trim() : null;
		if (pendingSizeChartFile) {
			setUploadingImage(true);
			try {
				uploadedSizeChartUrl = (await uploadFile(pendingSizeChartFile, {
					folder: "size-charts",
					prefix: slug
				})).url;
			} finally {
				setUploadingImage(false);
			}
		}
		const payload = {
			name: form.name.trim(),
			slug,
			brand_name: form.brand_name.trim(),
			description: form.description || null,
			video_url: form.video_url?.toString().trim() ? form.video_url.toString().trim() : null,
			size_chart_url: uploadedSizeChartUrl,
			category_id: form.category_id || null,
			base_price: Number(form.base_price) || 0,
			discount_price: form.discount_price != null && form.discount_price !== "" ? Number(form.discount_price) : null,
			stock: Number(form.stock) || 0,
			is_featured: !!form.is_featured,
			is_new: !!form.is_new,
			sort_order: Number(form.sort_order) || 0
		};
		const currentVariants = getActiveVariants(variantDialogOpen ? variantForm : void 0);
		if (productMode === "variant") {
			const firstVariant = currentVariants.find((v) => v.color) ?? currentVariants[0];
			payload.base_price = Number(firstVariant?.price) || 0;
			payload.discount_price = firstVariant?.discount_price != null && firstVariant?.discount_price !== "" ? Number(firstVariant?.discount_price) : null;
			payload.stock = currentVariants.reduce((s, v) => s + (Number(v.stock) || 0), 0);
		}
		const oldLocalUrls = /* @__PURE__ */ new Set();
		if (!isNew && existing) {
			existing.images.forEach((img) => {
				if (isLocalUploadUrl(img.url)) oldLocalUrls.add(img.url);
			});
			if (isLocalUploadUrl(existing.size_chart_url)) oldLocalUrls.add(existing.size_chart_url);
			existing.variants.forEach((variant) => {
				if (isLocalUploadUrl(variant.image_url)) oldLocalUrls.add(variant.image_url);
			});
		}
		setSaving(true);
		try {
			let productId = form.id;
			if (isNew) {
				const { data, error } = await supabase.from("products").insert(payload).select("id").single();
				if (error) throw error;
				productId = data.id;
			} else {
				const { error } = await supabase.from("products").update(payload).eq("id", productId);
				if (error) throw error;
			}
			if (!productId) throw new Error("Missing product id");
			const uploadedImages = await Promise.all(images.map(async (img, idx) => {
				const pendingFile = pendingProductImageFiles.get(idx);
				if (!pendingFile) return {
					url: img.url ?? null,
					alt: img.alt || null,
					sort_order: img.sort_order ?? idx
				};
				return {
					url: (await uploadOptimizedImage(pendingFile, {
						folder: "product-images",
						prefix: form.slug || slugify(form.name || "product")
					})).url,
					alt: img.alt || null,
					sort_order: img.sort_order ?? idx
				};
			}));
			const uploadedVariantImages = productMode === "variant" ? currentVariants.map((variant, idx) => ({
				...variant,
				image_url: variant.image_url ?? null,
				sort_order: variant.sort_order ?? idx
			})) : [];
			await supabase.from("product_images").delete().eq("product_id", productId);
			const imgRows = productMode === "variant" ? uploadedVariantImages.filter((v) => v.image_url).map((v, idx) => ({
				product_id: productId,
				url: v.image_url,
				alt: null,
				sort_order: idx
			})) : uploadedImages.filter((i) => i.url).map((i, idx) => ({
				product_id: productId,
				url: i.url,
				alt: i.alt || null,
				sort_order: i.sort_order ?? idx
			}));
			if (imgRows.length) {
				const { error } = await supabase.from("product_images").insert(imgRows);
				if (error) throw error;
			}
			await supabase.from("product_variants").delete().eq("product_id", productId);
			const varRows = uploadedVariantImages.filter((v) => v.color).map((v, idx) => ({
				product_id: productId,
				color: v.color,
				size: v.size || null,
				price: Number(v.price) || 0,
				discount_price: v.discount_price != null && v.discount_price !== "" ? Number(v.discount_price) : null,
				image_url: v.image_url || null,
				stock: Number(v.stock) || 0,
				sort_order: v.sort_order ?? idx
			}));
			if (varRows.length) {
				const { error } = await supabase.from("product_variants").insert(varRows);
				if (error) throw error;
			}
			const retainedUrls = /* @__PURE__ */ new Set([
				...uploadedImages.filter((i) => i.url).map((i) => i.url),
				...uploadedVariantImages.filter((v) => v.image_url).map((v) => v.image_url),
				...uploadedSizeChartUrl ? [uploadedSizeChartUrl] : []
			]);
			const urlsToDelete = Array.from(oldLocalUrls).filter((url) => !retainedUrls.has(url));
			const orphanedImmediate = Array.from(immediateUploadedVariantUrls.current).filter((u) => !retainedUrls.has(u));
			const allUrlsToDelete = [...urlsToDelete, ...orphanedImmediate];
			if (allUrlsToDelete.length) deleteLocalUploads(allUrlsToDelete).catch(() => {
				console.warn("Failed to delete old local product uploads", allUrlsToDelete);
			});
			immediateUploadedVariantUrls.current = /* @__PURE__ */ new Set();
			setPendingProductImageFiles(/* @__PURE__ */ new Map());
			setPendingSizeChartFile(null);
			toast.success(isNew ? "Product created" : "Product saved");
			qc.invalidateQueries({ queryKey: ["products"] });
			qc.invalidateQueries({ queryKey: ["product"] });
			if (isNew) nav({
				to: "/admin/products/$id",
				params: { id: productId }
			});
		} catch (e) {
			toast.error(e.message ?? "Failed to save");
		} finally {
			setSaving(false);
		}
	};
	if (!isNew && !existing) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "p-10 text-center text-muted-foreground",
		children: "Loading…"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex items-center justify-between",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/admin/products",
					className: "inline-flex items-center gap-1 text-xs uppercase tracking-[0.25em] text-muted-foreground hover:text-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-3" }), " Back to products"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 font-serif text-3xl",
					children: isNew ? "New Product" : form.name
				})] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "border border-border bg-card p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-3 text-sm uppercase tracking-[0.25em] text-gold",
					children: "Product Type"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 md:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: `flex cursor-pointer items-start gap-3 rounded border p-4 transition ${productMode === "single" ? "border-foreground bg-foreground/5" : "border-border"} ${isVariantExisting ? "opacity-60 cursor-not-allowed" : ""}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "radio",
							name: "productType",
							checked: productMode === "single",
							onChange: () => handleProductModeChange("single"),
							className: "mt-1",
							disabled: isVariantExisting
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block font-medium",
							children: "Single product"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1 block text-sm text-muted-foreground",
							children: "One price and stock entry for the whole product."
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: `flex cursor-pointer items-start gap-3 rounded border p-4 transition ${productMode === "variant" ? "border-foreground bg-foreground/5" : "border-border"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "radio",
							name: "productType",
							checked: productMode === "variant",
							onChange: () => handleProductModeChange("variant"),
							className: "mt-1"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block font-medium",
							children: "Variant product"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1 block text-sm text-muted-foreground",
							children: "Set separate options like size or color with their own price and stock."
						})] })]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "border border-border bg-card p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-3 text-sm uppercase tracking-[0.25em] text-gold",
					children: "Details"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 md:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
							label: "Name",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: I,
								value: form.name ?? "",
								onChange: (e) => set("name", e.target.value),
								onBlur: () => {
									if (!form.slug && form.name) set("slug", slugify(form.name));
								}
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
							label: "Slug",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: I,
								value: form.slug ?? "",
								onChange: (e) => set("slug", e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
							label: "Category",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: I,
								value: form.category_id ?? "",
								onChange: (e) => set("category_id", e.target.value || null),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: "— None —"
								}), categories.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: c.id,
									children: c.name
								}, c.id))]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
							label: "Brand Name",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								required: true,
								className: I,
								value: form.brand_name ?? "",
								onChange: (e) => set("brand_name", e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
							label: "Sort Order",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "number",
								className: I,
								value: form.sort_order ?? 0,
								onChange: (e) => set("sort_order", Number(e.target.value))
							})
						}),
						productMode === "single" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
								label: "Base Price (Tk. )",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "number",
									className: I,
									value: form.base_price ?? 0,
									onChange: (e) => set("base_price", Number(e.target.value))
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
								label: "Discount Price (Tk. , optional)",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "number",
									className: I,
									value: form.discount_price ?? "",
									onChange: (e) => set("discount_price", e.target.value === "" ? null : Number(e.target.value))
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
								label: "Stock",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "number",
									className: I,
									value: form.stock ?? 0,
									onChange: (e) => set("stock", Number(e.target.value))
								})
							})
						] }) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-end gap-6 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "checkbox",
									checked: !!form.is_featured,
									onChange: (e) => set("is_featured", e.target.checked)
								}), " Featured"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "checkbox",
									checked: !!form.is_new,
									onChange: (e) => set("is_new", e.target.checked)
								}), " New"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
							label: "Video Link (YouTube)",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: I,
								placeholder: "https://www.youtube.com/watch?v=...",
								value: form.video_url ?? "",
								onChange: (e) => set("video_url", e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
							label: "Size Chart (optional)",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										id: "size-chart-input",
										type: "file",
										accept: "image/*,.pdf,.doc,.docx",
										className: "hidden",
										onChange: handleSizeChartPick
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => document.getElementById("size-chart-input")?.click(),
											className: "inline-flex items-center gap-1 bg-foreground px-3 py-2 text-xs uppercase tracking-[0.2em] text-background",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-3" }), " Pick file"]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => {
												set("size_chart_url", null);
												setPendingSizeChartFile(null);
												toast.success("Size chart cleared — it will be removed when you click Save");
											},
											className: "inline-flex items-center gap-1 border border-border px-3 py-2 text-xs uppercase tracking-[0.2em]",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3" }), " Clear"]
										})]
									}),
									pendingSizeChartFile && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted-foreground",
										children: "New size chart selected — it will be saved with the product."
									}),
									form.size_chart_url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href: form.size_chart_url,
										target: "_blank",
										rel: "noreferrer",
										className: "text-xs text-muted-foreground underline",
										children: "Current size chart"
									}) : null
								]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "md:col-span-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
								label: "Description",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									className: I + " min-h-32",
									value: form.description ?? "",
									onChange: (e) => set("description", e.target.value)
								})
							})
						})
					]
				})]
			}),
			productMode === "single" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "border border-border bg-card p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm uppercase tracking-[0.25em] text-gold",
						children: "Images"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => setImages([...images, {
							url: "",
							alt: "",
							sort_order: images.length
						}]),
						className: "inline-flex items-center gap-1 text-xs uppercase tracking-[0.2em] text-muted-foreground hover:text-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3" }), " Add image"]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [
						images.map((img, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-3 md:grid-cols-[80px_1fr_1fr_auto]",
							children: [
								img.url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: img.url,
									alt: "",
									className: "h-16 w-16 rounded object-cover"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-16 w-16 rounded bg-muted" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												id: `product-image-${i}`,
												type: "file",
												accept: "image/*",
												className: "hidden",
												onChange: (e) => handleImagePick(e, "product", i)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: () => document.getElementById(`product-image-${i}`)?.click(),
												className: "inline-flex items-center gap-1 bg-foreground px-3 py-2 text-xs uppercase tracking-[0.2em] text-background",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-3" }), " Pick file"]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: () => {
													setImages(images.map((x, j) => j === i ? {
														...x,
														url: ""
													} : x));
													setPendingProductImageFiles((prev) => {
														const m = new Map(prev);
														m.delete(i);
														return m;
													});
													toast.success("Image cleared — it will be removed when you click Save");
												},
												className: "inline-flex items-center gap-1 border border-border px-3 py-2 text-xs uppercase tracking-[0.2em]",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3" }), " Clear"]
											}),
											uploadingImage && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs text-muted-foreground",
												children: "Saving image…"
											}),
											pendingProductImageFiles.has(i) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs text-muted-foreground",
												children: "New image selected — it will be saved with the product."
											})
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
										label: "URL",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											className: I,
											value: img.url ?? "",
											onChange: (e) => setImages(images.map((x, j) => j === i ? {
												...x,
												url: e.target.value
											} : x))
										})
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
									label: "Alt",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: I,
										value: img.alt ?? "",
										onChange: (e) => setImages(images.map((x, j) => j === i ? {
											...x,
											alt: e.target.value
										} : x))
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-end gap-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											title: "Move up",
											disabled: i === 0,
											onClick: () => moveImage(i, i - 1),
											className: "border border-border px-2 py-2 text-xs disabled:opacity-30",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUp, { className: "size-3" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											title: "Move down",
											disabled: i === images.length - 1,
											onClick: () => moveImage(i, i + 1),
											className: "border border-border px-2 py-2 text-xs disabled:opacity-30",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDown, { className: "size-3" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => setImages(images.filter((_, j) => j !== i).map((x, idx) => ({
												...x,
												sort_order: idx
											}))),
											className: "inline-flex items-center gap-1 border border-destructive/40 px-3 py-2 text-xs text-destructive",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3" })
										})
									]
								})
							]
						}, i)),
						images.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: "No images. Add one above."
						}),
						images.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: "First image is the main product photo — use the arrows to reorder."
						})
					]
				})]
			}),
			productMode === "variant" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "border border-border bg-card p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm uppercase tracking-[0.25em] text-gold",
						children: "Variants"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "Manage each option using the list below, then save the product."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: openAddVariantDialog,
						className: "inline-flex items-center gap-1 text-xs uppercase tracking-[0.2em] text-muted-foreground hover:text-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3" }), " Add variant"]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-x-auto rounded border border-border bg-background",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "bg-muted",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "text-left",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2",
										children: "Color"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2",
										children: "Size"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2",
										children: "Price"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2",
										children: "Discount"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2",
										children: "Stock"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2 text-right",
										children: "Actions"
									})
								]
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: variants.length > 0 ? variants.map((variant, index) => ({
							variant,
							index
						})).sort((a, b) => {
							const colorA = (a.variant.color ?? "").toLowerCase();
							const colorB = (b.variant.color ?? "").toLowerCase();
							if (colorA !== colorB) return colorA.localeCompare(colorB);
							const sizeA = (a.variant.size ?? "").toLowerCase();
							const sizeB = (b.variant.size ?? "").toLowerCase();
							if (sizeA !== sizeB) return sizeA.localeCompare(sizeB);
							return (a.variant.sort_order ?? a.index) - (b.variant.sort_order ?? b.index);
						}).map(({ variant: v, index }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-t border-border",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2",
									children: v.color || "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2",
									children: v.size || "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									className: "px-3 py-2",
									children: ["Tk. ", Number(v.price ?? 0).toLocaleString()]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2",
									children: v.discount_price != null ? `Tk. ${Number(v.discount_price).toLocaleString()}` : "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2",
									children: Number(v.stock ?? 0)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2 text-right",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-end gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											onClick: () => openEditVariantDialog(index),
											className: "inline-flex items-center gap-1 border border-border px-3 py-1 text-xs",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-3" }), " Edit"]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											onClick: () => removeVariant(index),
											className: "inline-flex items-center gap-1 border border-destructive/40 px-3 py-1 text-xs text-destructive",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3" })
										})]
									})
								})
							]
						}, index)) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							colSpan: 6,
							className: "px-3 py-8 text-center text-muted-foreground",
							children: "No variants yet — add one to start."
						}) }) })]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: variantDialogOpen,
				onOpenChange: (open) => open ? setVariantDialogOpen(true) : closeVariantDialog(),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-w-2xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: editingVariantIndex != null ? "Edit Variant" : "New Variant" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Provide the variant option, price and stock, then save." })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-4 md:grid-cols-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
									label: "Color",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: I,
										value: variantForm.color ?? "",
										onChange: (e) => {
											const nextColor = e.target.value;
											const shouldClearImage = editingVariantIndex == null && nextColor.trim() !== (lastVariantColorRef.current ?? "").trim();
											setVariantForm((prev) => ({
												...prev,
												color: nextColor,
												image_url: shouldClearImage ? "" : prev.image_url
											}));
										}
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
									label: "Size",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: I,
										value: variantForm.size ?? "",
										onChange: (e) => setVariantForm((prev) => ({
											...prev,
											size: e.target.value
										}))
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
									label: "Price (Tk. )",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "number",
										className: I,
										value: variantForm.price ?? 0,
										onChange: (e) => setVariantForm((prev) => ({
											...prev,
											price: Number(e.target.value)
										}))
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
									label: "Discount",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "number",
										className: I,
										value: variantForm.discount_price ?? "",
										onChange: (e) => setVariantForm((prev) => ({
											...prev,
											discount_price: e.target.value === "" ? null : Number(e.target.value)
										}))
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
									label: "Image",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												id: "variant-image-input",
												type: "file",
												accept: "image/*",
												className: "hidden",
												onChange: (e) => handleImagePick(e, "variant")
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
													type: "button",
													onClick: () => document.getElementById("variant-image-input")?.click(),
													className: "inline-flex items-center gap-1 bg-foreground px-3 py-2 text-xs uppercase tracking-[0.2em] text-background",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-3" }), " Pick file"]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
													type: "button",
													onClick: () => {
														setVariantForm((prev) => ({
															...prev,
															image_url: ""
														}));
														toast.success("Variant image cleared — it will be removed when you click Save");
													},
													className: "inline-flex items-center gap-1 border border-border px-3 py-2 text-xs uppercase tracking-[0.2em]",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3" }), " Clear"]
												})]
											}),
											uploadingImage && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs text-muted-foreground",
												children: "Uploading image…"
											}),
											variantForm.image_url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
												src: variantForm.image_url,
												alt: "Variant preview",
												className: "h-20 w-full rounded object-cover"
											}) : null
										]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
									label: "Stock",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "number",
										className: I,
										value: variantForm.stock ?? 0,
										onChange: (e) => setVariantForm((prev) => ({
											...prev,
											stock: Number(e.target.value)
										}))
									})
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, {
							className: "sm:justify-end",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: closeVariantDialog,
								className: "border border-border px-4 py-2 text-xs uppercase tracking-[0.25em]",
								children: "Cancel"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: saveVariant,
								className: "bg-foreground px-4 py-2 text-xs uppercase tracking-[0.25em] text-background",
								children: "Save"
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 flex justify-end",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					disabled: saving,
					onClick: save,
					className: "inline-flex items-center gap-2 bg-foreground px-6 py-3 text-xs uppercase tracking-[0.25em] text-background disabled:opacity-50",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "size-3" }),
						" ",
						saving ? "Saving…" : "Save"
					]
				})
			})
		]
	});
}
var I = "w-full border border-border bg-background px-3 py-2 text-sm";
function F({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-1 text-[10px] uppercase tracking-[0.25em] text-muted-foreground",
			children: label
		}), children]
	});
}
//#endregion
export { ProductEditor as component };
