import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/hcaptcha__react-hcaptcha+react.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { c as productsQuery, n as categoriesQuery } from "./queries-CN01OqZx.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as ProductCard } from "./product-card-D_y4dTHQ.mjs";
import { t as Route } from "./products.index-BbBqXAeR.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/products.index-CoGqHwUF.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function productPrice(p) {
	return p.discount_price ?? p.base_price;
}
function ProductsPage() {
	const { q: searchQ } = Route.useSearch();
	const categories = useQuery(categoriesQuery()).data ?? [];
	const products = useQuery(productsQuery()).data ?? [];
	const [filter, setFilter] = (0, import_react.useState)("all");
	const [sort, setSort] = (0, import_react.useState)("featured");
	let items = filter === "all" ? products : products.filter((p) => p.category?.slug === filter);
	if (searchQ) {
		const needle = searchQ.toLowerCase();
		items = items.filter((p) => p.name.toLowerCase().includes(needle) || (p.description ?? "").toLowerCase().includes(needle) || (p.category?.name ?? "").toLowerCase().includes(needle));
	}
	items = [...items].sort((a, b) => {
		if (sort === "price-asc") return productPrice(a) - productPrice(b);
		if (sort === "price-desc") return productPrice(b) - productPrice(a);
		if (sort === "newest") return +new Date(b.updated_at) - +new Date(a.updated_at);
		return Number(!!b.is_featured) - Number(!!a.is_featured);
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-7xl px-4 py-14 md:px-8 md:py-20",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[11px] uppercase tracking-[0.35em] text-gold",
						children: "Shop All"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 font-serif text-4xl md:text-5xl",
						children: searchQ ? `Search: “${searchQ}”` : "The Collection"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "gold-rule mt-4" })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-10 flex flex-wrap items-center justify-between gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setFilter("all"),
							className: `px-3 py-1.5 text-xs uppercase tracking-[0.2em] border ${filter === "all" ? "border-foreground bg-foreground text-background" : "border-border hover:border-foreground"}`,
							children: "All"
						}), categories.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setFilter(c.slug),
							className: `px-3 py-1.5 text-xs uppercase tracking-[0.2em] border ${filter === c.slug ? "border-foreground bg-foreground text-background" : "border-border hover:border-foreground"}`,
							children: c.name
						}, c.slug))]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						htmlFor: "products-sort",
						className: "sr-only",
						children: "Sort products"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						id: "products-sort",
						value: sort,
						onChange: (e) => setSort(e.target.value),
						className: "border border-border bg-background px-3 py-2 text-xs uppercase tracking-[0.15em]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "featured",
								children: "Sort: Featured"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "newest",
								children: "Newest"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "price-asc",
								children: "Price: Low to High"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "price-desc",
								children: "Price: High to Low"
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-10 grid grid-cols-2 gap-4 md:grid-cols-4 md:gap-8",
				children: items.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCard, { product: p }, p.id))
			}),
			items.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-16 text-center text-muted-foreground",
				children: ["No products yet in this category. ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/products",
					search: { q: void 0 },
					className: "underline",
					children: "View all"
				})]
			})
		]
	});
}
//#endregion
export { ProductsPage as component };
