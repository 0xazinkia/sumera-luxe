import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-C1p6U3vi.mjs";
import { n as require_react } from "../_libs/hcaptcha__react-hcaptcha+react.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as X, s as Trash2 } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.orders-Dw21RyD3.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var STATUSES = [
	"pending",
	"confirmed",
	"shipped",
	"delivered",
	"cancelled"
];
var money = (n) => `Tk. ${Number(n ?? 0).toLocaleString()}`;
var cap = (s) => s.charAt(0).toUpperCase() + s.slice(1);
var areaLabel = (a) => a?.startsWith("inside") ? "Inside Dhaka" : a?.startsWith("outside") ? "Outside Dhaka" : a ?? "—";
function OrdersPage() {
	const [orders, setOrders] = (0, import_react.useState)([]);
	const [filter, setFilter] = (0, import_react.useState)("all");
	const [monthFilter, setMonthFilter] = (0, import_react.useState)("all");
	const [open, setOpen] = (0, import_react.useState)(null);
	const [items, setItems] = (0, import_react.useState)(null);
	const load = async () => {
		const { data, error } = await supabase.from("orders").select("*").order("created_at", { ascending: false });
		if (error) toast.error(error.message);
		setOrders(data ?? []);
	};
	(0, import_react.useEffect)(() => {
		load();
	}, []);
	const setStatus = async (id, status) => {
		const { error } = await supabase.from("orders").update({ status }).eq("id", id);
		if (error) return toast.error(error.message);
		setOrders((prev) => prev.map((o) => o.id === id ? {
			...o,
			status
		} : o));
		setOpen((o) => o && o.id === id ? {
			...o,
			status
		} : o);
	};
	const view = async (order) => {
		setOpen(order);
		setItems(null);
		const { data, error } = await supabase.from("order_items").select("*").eq("order_id", order.id);
		if (error) toast.error(error.message);
		setItems(data ?? []);
	};
	const remove = async (id, orderNumber) => {
		if (!confirm(`Delete order ${orderNumber}?`)) return;
		const { error } = await supabase.from("orders").delete().eq("id", id);
		if (error) return toast.error(error.message);
		setOrders((prev) => prev.filter((o) => o.id !== id));
		if (open?.id === id) setOpen(null);
		toast.success("Order deleted");
	};
	const removeMonth = async () => {
		if (monthFilter === "all") {
			toast.error("Select a month first");
			return;
		}
		const monthLabel = (/* @__PURE__ */ new Date(`${monthFilter}-01`)).toLocaleDateString(void 0, {
			month: "long",
			year: "numeric"
		});
		if (!confirm(`Delete all orders from ${monthLabel}?`)) return;
		const [year, month] = monthFilter.split("-").map(Number);
		const start = new Date(Date.UTC(year, month - 1, 1)).toISOString();
		const end = new Date(Date.UTC(year, month, 1)).toISOString();
		const { error } = await supabase.from("orders").delete().gte("created_at", start).lt("created_at", end);
		if (error) return toast.error(error.message);
		setOrders((prev) => prev.filter((o) => new Date(o.created_at).toISOString().slice(0, 7) !== monthFilter));
		if (open && new Date(open.created_at).toISOString().slice(0, 7) === monthFilter) setOpen(null);
		toast.success(`Deleted orders from ${monthLabel}`);
	};
	const monthOptions = Array.from(new Set(orders.map((o) => new Date(o.created_at).toISOString().slice(0, 7)))).sort().reverse();
	const filteredByMonth = monthFilter === "all" ? orders : orders.filter((o) => new Date(o.created_at).toISOString().slice(0, 7) === monthFilter);
	const shown = filter === "all" ? filteredByMonth : filteredByMonth.filter((o) => o.status === filter);
	const counts = (s) => s === "all" ? filteredByMonth.length : filteredByMonth.filter((o) => o.status === s).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-serif text-4xl",
					children: "Orders"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "flex flex-wrap items-center gap-1 rounded-full border border-border bg-card p-1",
					children: ["all", ...STATUSES].map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => setFilter(s),
						className: `rounded-full px-3.5 py-1.5 text-xs transition-colors ${filter === s ? "bg-gold/15 text-gold" : "text-muted-foreground hover:text-foreground"}`,
						children: [
							s === "all" ? "All" : cap(s),
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "opacity-60",
								children: counts(s)
							})
						]
					}, s))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-3 rounded-lg border border-border bg-card p-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-sm text-muted-foreground",
						children: "Month"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: monthFilter,
						onChange: (e) => setMonthFilter(e.target.value),
						className: "rounded-md border border-border bg-background px-3 py-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "all",
							children: "All months"
						}), monthOptions.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: m,
							children: (/* @__PURE__ */ new Date(`${m}-01`)).toLocaleDateString(void 0, {
								month: "long",
								year: "numeric"
							})
						}, m))]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: removeMonth,
					className: "inline-flex items-center gap-2 rounded-md border border-destructive/40 px-3 py-2 text-sm text-destructive",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" }), " Delete selected month"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto rounded-lg border border-border bg-card",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full border-collapse text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-b border-border bg-muted/40 text-left text-[11px] uppercase tracking-[0.18em] text-muted-foreground",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-5 py-4 font-normal",
								children: "Order"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-5 py-4 font-normal",
								children: "Customer"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-5 py-4 font-normal",
								children: "Phone"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-5 py-4 font-normal",
								children: "Total"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-5 py-4 font-normal",
								children: "Status"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-5 py-4 font-normal",
								children: "Date"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-5 py-4 font-normal text-right",
								children: "Details"
							})
						]
					}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [shown.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-b border-border/60 last:border-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-5 py-4 font-mono text-xs",
								children: o.order_number
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-5 py-4",
								children: o.customer_name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-5 py-4",
								children: o.phone
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-5 py-4 font-medium",
								children: money(o.total)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-5 py-4",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									value: o.status,
									onChange: (e) => setStatus(o.id, e.target.value),
									className: "rounded-md border border-border bg-background px-2 py-1 text-xs",
									children: STATUSES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: s,
										children: cap(s)
									}, s))
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-5 py-4 text-xs text-muted-foreground",
								children: new Date(o.created_at).toLocaleDateString()
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-5 py-4 text-right",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-end gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => view(o),
										className: "text-sm text-gold hover:underline",
										children: "View"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => remove(o.id, o.order_number),
										className: "inline-flex items-center gap-1 text-sm text-destructive hover:underline",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
									})]
								})
							})
						]
					}, o.id)), shown.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						colSpan: 7,
						className: "py-12 text-center text-muted-foreground",
						children: "No orders here."
					}) })] })]
				})
			}),
			open && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-foreground/40 p-4 sm:p-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full max-w-2xl rounded-lg border border-border bg-card shadow-xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between border-b border-border px-6 py-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-serif text-2xl",
							children: "Order details"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setOpen(null),
							"aria-label": "Close",
							className: "text-muted-foreground hover:text-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-6 px-6 py-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-x-6 gap-y-4 text-sm",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "Order #",
										value: open.order_number,
										mono: true
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "Status",
										value: cap(open.status)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "Customer",
										value: open.customer_name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "Phone",
										value: open.phone
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "Area",
										value: areaLabel(open.area ?? open.delivery_area)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "Date",
										value: new Date(open.created_at).toLocaleString()
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Address" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2 rounded-md bg-muted/50 px-4 py-3 text-sm",
								children: [open.address, open.city ? `, ${open.city}` : ""]
							})] }),
							open.notes && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Notes" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 rounded-md bg-muted/50 px-4 py-3 text-sm",
								children: open.notes
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Items" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
								className: "mt-2 space-y-2",
								children: [
									items === null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
										className: "text-sm text-muted-foreground",
										children: "Loading…"
									}),
									items?.map((it) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex items-center gap-4 rounded-md border border-border p-3",
										children: [
											it.image_url && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
												src: it.image_url,
												alt: it.product_name,
												className: "size-14 shrink-0 rounded object-cover",
												loading: "lazy"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "min-w-0 flex-1",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "text-sm",
														children: it.product_name
													}),
													it.variant_label && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "text-xs text-muted-foreground",
														children: it.variant_label
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
														className: "text-xs text-muted-foreground",
														children: [
															"Qty ",
															it.quantity,
															" × ",
															money(it.unit_price)
														]
													})
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-medium",
												children: money(it.line_total)
											})
										]
									}, it.id)),
									items?.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
										className: "text-sm text-muted-foreground",
										children: "No items recorded."
									})
								]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5 rounded-md bg-muted/50 px-4 py-4 text-sm",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
										label: "Subtotal",
										value: money(open.subtotal)
									}),
									Number(open.discount_amount ?? 0) > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
										label: `Discount${open.discount_code ? ` (${open.discount_code})` : ""}`,
										value: `−${money(open.discount_amount)}`
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
										label: "Delivery",
										value: money(open.delivery_fee)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between border-t border-border pt-2 text-base",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-medium",
											children: "Total"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-serif text-xl text-gold",
											children: money(open.total)
										})]
									})
								]
							})
						]
					})]
				})
			})
		]
	});
}
function Label({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "text-[11px] uppercase tracking-[0.18em] text-muted-foreground",
		children
	});
}
function Field({ label, value, mono }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: `mt-1 ${mono ? "font-mono text-xs" : ""}`,
		children: value || "—"
	})] });
}
function Row({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-between",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: value })]
	});
}
//#endregion
export { OrdersPage as component };
