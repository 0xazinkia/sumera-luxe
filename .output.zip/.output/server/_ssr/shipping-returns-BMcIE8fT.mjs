import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as useSiteSettings } from "./hooks-BIqWSPKp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/shipping-returns-BMcIE8fT.js
var import_jsx_runtime = require_jsx_runtime();
function ShippingReturnsPage() {
	const s = useSiteSettings();
	const inside = s?.delivery_inside_dhaka ?? 60;
	const outside = s?.delivery_outside_dhaka ?? 120;
	const wa = s?.whatsapp_display ?? "+880 1322-126233";
	const email = s?.contact_email ?? "hello@sumeraluxe.com";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mx-auto max-w-3xl px-4 py-14 md:px-8 md:py-20",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[11px] uppercase tracking-[0.35em] text-gold",
						children: "Customer Care"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 font-serif text-4xl md:text-5xl",
						children: "Shipping & Returns"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "gold-rule mt-4" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mx-auto mt-6 max-w-2xl text-sm leading-relaxed text-muted-foreground",
						children: "Every Suméra Luxe order is packed by hand in Dhaka and delivered across Bangladesh with cash on delivery."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-10 grid gap-4 md:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg border border-border/60 bg-cream/40 p-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11px] uppercase tracking-[0.25em] text-gold",
							children: "Inside Dhaka"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 font-serif text-2xl",
							children: ["Tk. ", inside]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted-foreground",
							children: "1–2 working days after order confirmation."
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg border border-border/60 bg-cream/40 p-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11px] uppercase tracking-[0.25em] text-gold",
							children: "Outside Dhaka"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 font-serif text-2xl",
							children: ["Tk. ", outside]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted-foreground",
							children: "3–5 working days anywhere in Bangladesh."
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-12 space-y-8 text-[15px] leading-[1.85] text-foreground/85",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
						title: "Order confirmation",
						children: "Once you place an order our team will call or WhatsApp you to confirm your name, address and items. Your order is dispatched only after this confirmation."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
						title: "Delivery partners",
						children: [
							"We work with trusted courier partners across Bangladesh — including Dhaka city, all divisional cities and upazila-level delivery. A tracking update is shared with you over WhatsApp once your parcel is dispatched. You can also track any order from our ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "/track",
								className: "text-gold underline",
								children: "Track Order"
							}),
							" page using the phone number used at checkout."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
						title: "Cash on Delivery",
						children: "Payment is collected in cash by our courier at the time of delivery. Please have the exact amount ready. We do not currently accept online, card or mobile financial services payments."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
						title: "Return & refund policy",
						children: [
							"Because beauty and personal-care products are hygiene-sensitive, we accept returns only in the following cases:",
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
								className: "mt-3 ml-5 list-disc space-y-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "The product arrived damaged or leaking." }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "You received the wrong item or variant." }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "The product is expired or defective at the time of delivery." })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-3",
								children: [
									"To raise a return, contact us on WhatsApp ",
									wa,
									" within 24 hours of delivery with clear photos of the parcel and product. Once approved, we will arrange a replacement or a full refund. Used or opened items outside the cases above are not eligible for return."
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
						title: "Order cancellation",
						children: "You can cancel your order free of charge any time before it is dispatched. Please message us on WhatsApp as soon as possible so we can stop the shipment."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
						title: "Failed or refused deliveries",
						children: "If a confirmed order is refused at the door or cannot be delivered after multiple attempts, we may pause cash-on-delivery for future orders from that number. Please only confirm orders you intend to receive."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
						title: "Need help?",
						children: [
							"Our customer care team is available 7 days a week. WhatsApp ",
							wa,
							" or email ",
							email,
							"."
						]
					})
				]
			})
		]
	});
}
function Section({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
		className: "font-serif text-xl",
		children: title
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-2",
		children
	})] });
}
//#endregion
export { ShippingReturnsPage as component };
