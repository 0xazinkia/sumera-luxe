import { n as __exportAll$1 } from "../_runtime.mjs";
import { t as supabase } from "./client-C1p6U3vi.mjs";
import { t as queryOptions } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/queries-CN01OqZx.js
var queries_CN01OqZx_exports = /* @__PURE__ */ __exportAll$1({
	a: () => heroSlidesQuery,
	c: () => productsQuery,
	d: () => validateDiscountCode,
	f: () => whatsappHrefFor,
	i: () => discountCodesQuery,
	l: () => queries_exports,
	n: () => categoriesQuery,
	o: () => productBySlugQuery,
	r: () => categoryBySlugQuery,
	s: () => productEnquiryMessage,
	t: () => bannersQuery,
	u: () => siteSettingsQuery
});
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var queries_exports = /* @__PURE__ */ __exportAll({
	bannersQuery: () => bannersQuery,
	categoriesQuery: () => categoriesQuery,
	categoryBySlugQuery: () => categoryBySlugQuery,
	discountCodesQuery: () => discountCodesQuery,
	heroSlidesQuery: () => heroSlidesQuery,
	productBySlugQuery: () => productBySlugQuery,
	productEnquiryMessage: () => productEnquiryMessage,
	productsQuery: () => productsQuery,
	siteSettingsQuery: () => siteSettingsQuery,
	validateDiscountCode: () => validateDiscountCode,
	whatsappHrefFor: () => whatsappHrefFor
});
var PRODUCT_SELECT = "*, images:product_images(*), variants:product_variants(*), category:categories(slug,name)";
function sortProduct(p) {
	return {
		...p,
		images: (p.images ?? []).slice().sort((a, b) => a.sort_order - b.sort_order),
		variants: (p.variants ?? []).slice().sort((a, b) => a.sort_order - b.sort_order)
	};
}
var categoriesQuery = () => queryOptions({
	queryKey: ["categories"],
	queryFn: async () => {
		const { data, error } = await supabase.from("categories").select("*").order("sort_order", { ascending: true });
		if (error) throw error;
		return data ?? [];
	},
	staleTime: 6e4
});
var productsQuery = () => queryOptions({
	queryKey: ["products"],
	queryFn: async () => {
		const { data, error } = await supabase.from("products").select(PRODUCT_SELECT).order("sort_order", { ascending: true });
		if (error) throw error;
		return (data ?? []).map(sortProduct);
	},
	staleTime: 3e4
});
var productBySlugQuery = (slug) => queryOptions({
	queryKey: ["product", slug],
	queryFn: async () => {
		const { data, error } = await supabase.from("products").select(PRODUCT_SELECT).eq("slug", slug).maybeSingle();
		if (error) throw error;
		return data ? sortProduct(data) : null;
	}
});
var categoryBySlugQuery = (slug) => queryOptions({
	queryKey: ["category", slug],
	queryFn: async () => {
		const { data, error } = await supabase.from("categories").select("*").eq("slug", slug).maybeSingle();
		if (error) throw error;
		return data ?? null;
	}
});
var heroSlidesQuery = () => queryOptions({
	queryKey: ["hero-slides"],
	queryFn: async () => {
		const { data, error } = await supabase.from("hero_slides").select("*").eq("is_active", true).order("sort_order", { ascending: true });
		if (error) throw error;
		return data ?? [];
	},
	staleTime: 6e4
});
var bannersQuery = () => queryOptions({
	queryKey: ["banners"],
	queryFn: async () => {
		const { data, error } = await supabase.from("banners").select("*").eq("is_active", true).order("sort_order", { ascending: true });
		if (error) throw error;
		return data ?? [];
	},
	staleTime: 6e4
});
var siteSettingsQuery = () => queryOptions({
	queryKey: ["site-settings"],
	queryFn: async () => {
		const { data, error } = await supabase.from("site_settings").select("*").eq("id", 1).maybeSingle();
		if (error) throw error;
		return data ?? null;
	},
	staleTime: 6e4
});
function whatsappHrefFor(number, message) {
	return `https://wa.me/${number}?text=${encodeURIComponent(message)}`;
}
var discountCodesQuery = () => queryOptions({
	queryKey: ["discount-codes"],
	queryFn: async () => {
		const { data, error } = await supabase.from("discount_codes").select("*").order("created_at", { ascending: false });
		if (error) throw error;
		return data ?? [];
	}
});
async function validateDiscountCode(raw, subtotal) {
	const code = raw.trim();
	if (!code) return {
		ok: false,
		reason: "Enter a code."
	};
	const { data, error } = await supabase.from("discount_codes").select("*").ilike("code", code).eq("is_active", true).maybeSingle();
	if (error) return {
		ok: false,
		reason: "Could not check that code."
	};
	const dc = data;
	if (!dc) return {
		ok: false,
		reason: "Invalid code."
	};
	if (dc.expires_at && new Date(dc.expires_at) < /* @__PURE__ */ new Date()) return {
		ok: false,
		reason: "This code has expired."
	};
	if (dc.max_uses != null && dc.used_count >= dc.max_uses) return {
		ok: false,
		reason: "This code has reached its usage limit."
	};
	if (subtotal < Number(dc.min_subtotal)) return {
		ok: false,
		reason: `Minimum order of ${Number(dc.min_subtotal)} required.`
	};
	return {
		ok: true,
		code: dc,
		amount: dc.type === "percent" ? Math.round(subtotal * Number(dc.value) / 100) : Math.min(Number(dc.value), subtotal)
	};
}
function productEnquiryMessage(brand, name, url) {
	return `Hello ${brand},\n\nI want to know about this product.\n\nProduct Name:\n${name}\n\nProduct Link:\n${url}\n\nPlease provide more information.`;
}
//#endregion
export { heroSlidesQuery as a, productsQuery as c, validateDiscountCode as d, whatsappHrefFor as f, discountCodesQuery as i, queries_CN01OqZx_exports as l, categoriesQuery as n, productBySlugQuery as o, categoryBySlugQuery as r, productEnquiryMessage as s, bannersQuery as t, siteSettingsQuery as u };
