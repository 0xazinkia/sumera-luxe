import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/hcaptcha__react-hcaptcha+react.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { a as heroSlidesQuery, c as productsQuery, n as categoriesQuery } from "./queries-CN01OqZx.mjs";
import { t as useBannerBySlot } from "./hooks-BIqWSPKp.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { F as ChevronRight, I as ChevronLeft } from "../_libs/lucide-react.mjs";
import { t as ProductCard } from "./product-card-D_y4dTHQ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Dx64SO-2.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var BENGALI_RE$1 = /[\u0980-\u09FF]/;
var containsBengali$1 = (value) => typeof value === "string" && BENGALI_RE$1.test(value);
function HeroSlider() {
	const heroQuery = useQuery(heroSlidesQuery());
	const allSlides = heroQuery.data ?? [];
	const isLoading = heroQuery.isPending || heroQuery.isFetching;
	const [i, setI] = (0, import_react.useState)(0);
	const [isMobile, setIsMobile] = (0, import_react.useState)(false);
	const [mobileRatio, setMobileRatio] = (0, import_react.useState)(null);
	const slideImageRefs = (0, import_react.useRef)([]);
	(0, import_react.useEffect)(() => {
		const update = () => setIsMobile(window.innerWidth < 768);
		update();
		window.addEventListener("resize", update);
		return () => window.removeEventListener("resize", update);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!isMobile) {
			setMobileRatio(null);
			return;
		}
		const activeImage = slideImageRefs.current[i];
		if (activeImage?.complete && activeImage.naturalWidth && activeImage.naturalHeight) setMobileRatio(activeImage.naturalWidth / activeImage.naturalHeight);
	}, [
		i,
		isMobile,
		allSlides.length
	]);
	const slides = isMobile ? allSlides : allSlides.filter((s) => s.image_url);
	(0, import_react.useEffect)(() => {
		if (slides.length <= 1) return;
		const id = setInterval(() => setI((v) => (v + 1) % slides.length), 6e3);
		return () => clearInterval(id);
	}, [slides.length]);
	(0, import_react.useEffect)(() => {
		if (i >= slides.length) setI(0);
	}, [i, slides.length]);
	const go = (delta) => setI((v) => (v + delta + slides.length) % slides.length);
	if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "relative overflow-hidden",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative mx-auto max-w-[1600px] aspect-[3/1] min-h-[380px] md:min-h-[460px]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 animate-pulse bg-[linear-gradient(90deg,rgba(255,255,255,0.08)_0%,rgba(255,255,255,0.18)_50%,rgba(255,255,255,0.08)_100%)]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 flex items-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto w-full max-w-7xl px-6 md:px-12",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "max-w-xl space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-4 w-24 rounded-full bg-muted/70" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-10 w-3/4 rounded bg-muted/70" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-4 w-full rounded bg-muted/50" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-4 w-2/3 rounded bg-muted/50" })
						]
					})
				})
			})]
		})
	});
	if (slides.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "relative overflow-hidden",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "relative mx-auto flex max-w-[1600px] items-center justify-center aspect-[3/1] min-h-[380px] bg-muted/50 md:min-h-[460px]",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] uppercase tracking-[0.35em] text-gold",
					children: "New arrivals"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 font-serif text-3xl text-foreground md:text-4xl",
					children: "Discover the latest collection"
				})]
			})
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative overflow-hidden",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "relative mx-auto max-w-[1600px] sm:aspect-[3/1] min-h-[380px] md:min-h-[460px]",
			style: isMobile && mobileRatio ? {
				aspectRatio: mobileRatio,
				minHeight: 0
			} : void 0,
			children: slides.map((s, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				"aria-hidden": idx !== i,
				className: `absolute inset-0 transition-opacity duration-1000 ease-out ${idx === i ? "opacity-100" : "opacity-0"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					ref: (node) => {
						slideImageRefs.current[idx] = node;
					},
					src: isMobile ? s.mobile_image_url ?? s.image_url : s.image_url,
					alt: s.title?.trim() || s.eyebrow?.trim() || s.subtitle?.trim() || "Hero slide",
					className: `h-full w-full ${isMobile && s.mobile_image_url ? "object-contain" : "object-cover"}`,
					loading: idx === 0 ? "eager" : "lazy",
					onLoad: (e) => {
						if (idx !== i || !isMobile || !s.mobile_image_url) return;
						const img = e.currentTarget;
						if (img.naturalWidth && img.naturalHeight) setMobileRatio(img.naturalWidth / img.naturalHeight);
					}
				}), (s.eyebrow || s.title || s.subtitle || s.cta_label) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-r from-background/85 via-background/40 to-transparent" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute inset-0 flex items-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mx-auto w-full max-w-7xl px-6 md:px-12",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "max-w-xl",
							children: [
								s.eyebrow && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: `${containsBengali$1(s.eyebrow) ? "text-base tracking-normal" : "text-base uppercase tracking-[0.35em]"} pb-4 text-gold ${containsBengali$1(s.eyebrow) ? "bangla-font" : ""}`,
									children: s.eyebrow
								}),
								s.title?.trim() ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
									className: `font-serif font-bold text-4xl leading-[1.05] text-foreground md:text-6xl ${containsBengali$1(s.title) ? "bangla-font" : ""}`,
									children: s.title
								}) : null,
								s.subtitle && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: `mt-5 max-w-md text-sm text-muted-foreground md:text-base ${containsBengali$1(s.subtitle) ? "bangla-font" : ""}`,
									children: s.subtitle
								}),
								s.cta_label && s.cta_href && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-8 flex items-center gap-4",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: s.cta_href,
										className: `inline-flex items-center gap-2 bg-foreground px-7 py-4 text-sm text-background transition hover:bg-foreground/85 ${containsBengali$1(s.cta_label) ? "bangla-font" : "uppercase tracking-[0.25em]"}`,
										children: s.cta_label
									})
								})
							]
						})
					})
				})] })]
			}, s.id ?? idx))
		}), slides.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: () => go(-1),
				"aria-label": "Previous",
				className: "absolute left-3 top-1/2 -translate-y-1/2 rounded-full bg-background/70 p-2 text-foreground shadow hover:bg-background",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: () => go(1),
				"aria-label": "Next",
				className: "absolute right-3 top-1/2 -translate-y-1/2 rounded-full bg-background/70 p-2 text-foreground shadow hover:bg-background",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-5" })
			}),
			!isMobile && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute bottom-5 left-1/2 flex -translate-x-1/2 gap-1.5",
				children: slides.map((_, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setI(idx),
					"aria-label": `Slide ${idx + 1}`,
					className: `h-1 rounded-full transition-all ${idx === i ? "w-8 bg-foreground" : "w-4 bg-foreground/30"}`
				}, idx))
			})
		] })]
	});
}
var BENGALI_RE = /[\u0980-\u09FF]/;
var containsBengali = (value) => typeof value === "string" && BENGALI_RE.test(value);
function SectionHeading({ eyebrow, title, viewAll }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-8 flex items-end justify-between gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [eyebrow && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-[11px] uppercase tracking-[0.35em] text-gold",
			children: eyebrow
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mt-1 font-serif text-3xl md:text-4xl",
			children: title
		})] }), viewAll && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: viewAll.to,
			params: viewAll.params,
			className: "whitespace-nowrap border-b border-foreground pb-0.5 text-xs uppercase tracking-[0.25em] hover:text-gold hover:border-gold",
			children: "View All"
		})]
	});
}
function CategoryBlock({ category, products }) {
	const items = products.filter((p) => p.category?.slug === category.slug).slice(0, 8);
	if (items.length === 0) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-7xl px-4 py-10 md:px-8 md:py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
			eyebrow: "The Collection",
			title: category.name,
			viewAll: {
				to: "/category/$slug",
				params: { slug: category.slug }
			}
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-2 gap-4 md:grid-cols-4 md:gap-8",
			children: items.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCard, { product: p }, p.id))
		})]
	});
}
function Index() {
	const categoriesQueryResult = useQuery(categoriesQuery());
	const productsQueryResult = useQuery(productsQuery());
	const categories = categoriesQueryResult.data ?? [];
	const products = productsQueryResult.data ?? [];
	const isLoading = categoriesQueryResult.isPending || productsQueryResult.isPending;
	const promo = useBannerBySlot("promo");
	const [isMobile, setIsMobile] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const update = () => setIsMobile(window.innerWidth < 768);
		update();
		window.addEventListener("resize", update);
		return () => window.removeEventListener("resize", update);
	}, []);
	const cats = categories.slice(0, 5);
	const [first, second, ...rest] = cats;
	const hasPromoContent = Boolean(promo?.eyebrow || promo?.title || promo?.subtitle || promo?.cta_label);
	const promoImage = isMobile && promo?.mobile_image_url ? promo.mobile_image_url : promo?.image_url;
	if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroSlider, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-7xl px-4 py-10 md:px-8 md:py-14",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "text-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto h-3 w-24 animate-pulse rounded-full bg-muted/70" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto mt-4 h-8 w-2/3 animate-pulse rounded bg-muted/70" })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-12 grid grid-cols-2 gap-4 md:grid-cols-5 md:gap-6",
			children: Array.from({ length: 5 }).map((_, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "aspect-square animate-pulse rounded-sm bg-muted/70" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto h-4 w-2/3 animate-pulse rounded bg-muted/50" })]
			}, index))
		})]
	})] });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroSlider, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-7xl px-4 py-10 md:px-8 md:py-14",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11px] uppercase tracking-[0.35em] text-gold",
							children: "Shop by Category"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-2 font-serif text-3xl md:text-4xl",
							children: "A curated house of beauty"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "gold-rule mt-4" })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-12 grid grid-cols-2 gap-4 md:grid-cols-5 md:gap-6",
					children: cats.map((c, idx) => {
						const count = products.filter((p) => p.category?.slug === c.slug).length;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/category/$slug",
							params: { slug: c.slug },
							className: `group block ${idx === 4 ? "hidden md:block" : ""}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "overflow-hidden rounded-xl bg-muted",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: c.image_url ?? "",
									alt: `${c.name} collection`,
									loading: "lazy",
									className: "aspect-square w-full object-cover transition-transform duration-700 group-hover:scale-105"
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 text-center",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-serif text-lg",
									children: c.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-xs text-muted-foreground",
									children: [count, " items"]
								})]
							})]
						}, c.slug);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-10 text-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/products",
						className: "inline-block border-b border-foreground pb-0.5 text-xs uppercase tracking-[0.25em] hover:text-gold hover:border-gold",
						children: "View All Categories"
					})
				})
			]
		}),
		first && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CategoryBlock, {
			category: first,
			products
		}),
		second && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CategoryBlock, {
			category: second,
			products
		}),
		promoImage && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "mx-auto max-w-[1600px] px-4 py-8 md:px-8 md:py-10",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative overflow-hidden rounded-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: promoImage,
					alt: promo?.title ?? "Luxury beauty edit",
					loading: "lazy",
					className: "h-64 w-full object-cover md:h-80"
				}), hasPromoContent ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-r from-black/45 to-black/10" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute inset-0 flex items-center px-8 md:px-16",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: `max-w-lg text-background ${containsBengali(promo?.eyebrow) || containsBengali(promo?.title) || containsBengali(promo?.cta_label) ? "bangla-font" : ""}`,
						children: [
							promo?.eyebrow ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: `${containsBengali(promo?.eyebrow) ? "text-base tracking-normal" : "text-base uppercase tracking-[0.35em]"} pb-4 text-gold-soft`,
								children: promo.eyebrow
							}) : null,
							promo?.title?.trim() ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: `mt-2 font-serif text-3xl leading-tight md:text-4xl ${containsBengali(promo?.title) ? "bangla-font" : ""}`,
								children: promo.title
							}) : null,
							promo?.subtitle?.trim() ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: `mt-3 max-w-md text-sm text-background/90 md:text-base ${containsBengali(promo?.subtitle) ? "bangla-font" : ""}`,
								children: promo.subtitle
							}) : null,
							promo?.cta_label?.trim() ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: typeof promo?.cta_href === "string" && promo.cta_href.trim() ? promo.cta_href : "/products",
								className: `mt-6 inline-flex items-center bg-background px-7 py-4 text-sm text-foreground hover:bg-gold hover:text-primary-foreground ${containsBengali(promo?.cta_label) ? "bangla-font" : "uppercase"}`,
								children: promo.cta_label
							}) : null
						]
					})
				})] }) : null]
			})
		}),
		rest.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CategoryBlock, {
			category: c,
			products
		}, c.slug))
	] });
}
//#endregion
export { Index as component };
