import { i as __toESM } from "../_runtime.mjs";
import { t as createClient } from "../_libs/supabase__supabase-js.mjs";
import { t as supabase } from "./client-C1p6U3vi.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { n as require_react } from "../_libs/hcaptcha__react-hcaptcha+react.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as useQuery, r as QueryClientProvider } from "../_libs/tanstack__react-query.mjs";
import { u as siteSettingsQuery } from "./queries-CN01OqZx.mjs";
import { n as useSiteSettings } from "./hooks-BIqWSPKp.mjs";
import { _ as useNavigate, c as HeadContent, d as createRouter, f as Outlet, g as Link, h as createRootRouteWithContext, j as redirect, l as useRouterState, m as createFileRoute, p as lazyRouteComponent, s as Scripts, y as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { A as House, D as LayoutGrid, S as Menu, b as PackageSearch, d as ShoppingBag, j as Facebook, m as Search, n as X, w as Mail, x as MessageCircle } from "../_libs/lucide-react.mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
import { t as Route$26 } from "./admin.products._id-B-Y4_tCV.mjs";
import { n as useCart, t as CartProvider } from "./cart-CreAwi5h.mjs";
import { n as initializeTracking, o as trackPageView } from "./helpers-BVzN2yBE.mjs";
import { t as Route$27 } from "./category._slug-C_fhD6L2.mjs";
import { t as Route$28 } from "./order-success-BfI7xvSA.mjs";
import { t as Route$29 } from "./products._slug-DUpJVIAX.mjs";
import { t as Route$30 } from "./products.index-BbBqXAeR.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-a5mih3-K.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var styles_default = "/assets/styles-023XbdU-.css";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
	const message = error instanceof Response ? `Response ${error.status}${error.url ? ` at ${error.url}` : ""}` : error instanceof Error ? error.message : String(error);
	window.__lovableReportRuntimeError?.({
		message,
		stack: error instanceof Error ? error.stack : void 0,
		filename: window.location.pathname
	});
}
var SITE_FALLBACK = {
	name: "Suméra Luxe",
	tagline: "Beauty · Skincare · Gift Items",
	whatsappNumber: "8801322126233",
	whatsappDisplay: "+880 1322-126233",
	facebookUrl: "https://facebook.com/",
	email: "hello@sumeraluxe.com",
	currency: "Tk. ",
	deliveryInsideDhaka: 60,
	deliveryOutsideDhaka: 120
};
var whatsappHref = (message, number = SITE_FALLBACK.whatsappNumber) => `https://wa.me/${number}?text=${encodeURIComponent(message)}`;
function SiteHeader() {
	const { count } = useCart();
	const settingsQuery = useQuery(siteSettingsQuery());
	const settings = settingsQuery.data ?? null;
	const isSettingsLoading = settingsQuery.isPending || settingsQuery.isFetching;
	const [open, setOpen] = (0, import_react.useState)(false);
	const [searchOpen, setSearchOpen] = (0, import_react.useState)(false);
	const [q, setQ] = (0, import_react.useState)("");
	const inputRef = (0, import_react.useRef)(null);
	const navigate = useNavigate();
	(0, import_react.useEffect)(() => {
		if (searchOpen) inputRef.current?.focus();
	}, [searchOpen]);
	const submitSearch = (e) => {
		e?.preventDefault();
		const term = q.trim();
		if (!term) return;
		navigate({
			to: "/products",
			search: { q: term }
		});
		setSearchOpen(false);
		setOpen(false);
	};
	const brand = settings?.brand_name ?? "Suméra Luxe";
	const tagline = settings?.brand_tagline ?? "Beauty · Skincare · Gifts";
	const waNumber = settings?.whatsapp_number ?? "8801322126233";
	const waDisplay = settings?.whatsapp_display ?? "+880 1322-126233";
	if (isSettingsLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
		className: "sticky top-0 z-40 border-b border-border/60 bg-background/85 backdrop-blur",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex h-16 max-w-7xl items-center justify-between px-4 md:h-20 md:px-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-10 w-10 animate-pulse rounded-full bg-muted" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "hidden items-center gap-8 md:flex",
					children: Array.from({ length: 4 }).map((_, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-4 w-16 animate-pulse rounded bg-muted" }, index))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-8 w-24 animate-pulse rounded bg-muted" })
			]
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "sticky top-0 z-40 border-b border-border/60 bg-background/85 backdrop-blur",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex h-16 max-w-7xl items-center justify-between px-4 md:h-20 md:px-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "md:hidden text-foreground",
						onClick: () => setOpen((o) => !o),
						"aria-label": "Toggle menu",
						children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-6" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-6" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/",
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/sumera_luxe_logo.png",
							alt: brand,
							className: "h-10 w-10 rounded-full object-cover md:h-12 md:w-12"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-serif text-base leading-none tracking-wide md:text-2xl",
							children: brand
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[9px] uppercase tracking-[0.2em] text-gold md:text-[11px]",
							children: tagline
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
						className: "hidden md:flex items-center gap-8 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/",
								className: "hover:text-gold transition-colors",
								children: "Home"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/products",
								search: { q: void 0 },
								className: "hover:text-gold transition-colors",
								children: "Shop"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/categories",
								className: "hover:text-gold transition-colors",
								children: "Categories"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/track",
								className: "hover:text-gold transition-colors",
								children: "Track Order"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 md:gap-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: whatsappHref(`Hello ${brand}, I'd like to know more.`, waNumber),
								target: "_blank",
								rel: "noopener noreferrer",
								className: "hidden md:inline-flex items-center gap-1.5 text-sm text-foreground/80 hover:text-gold",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "hidden lg:inline",
									children: waDisplay
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setSearchOpen((s) => !s),
								className: "hidden md:inline-flex text-foreground/80 hover:text-gold",
								"aria-label": "Search",
								"aria-expanded": searchOpen,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-5" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/cart",
								className: "relative grid size-9 place-items-center rounded-full bg-muted text-foreground hover:bg-gold/10 hover:text-gold",
								"aria-label": "Cart",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingBag, { className: "size-5" }), count > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "absolute -right-1 -top-1 grid h-5 min-w-5 place-items-center rounded-full bg-foreground px-1 text-[10px] font-semibold text-background",
									children: count
								})]
							})
						]
					})
				]
			}),
			searchOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "border-t border-border/60 bg-background",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: submitSearch,
					className: "mx-auto flex max-w-7xl items-center gap-2 px-4 py-3 md:px-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 text-muted-foreground" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							htmlFor: "site-search",
							className: "sr-only",
							children: "Search products"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "site-search",
							ref: inputRef,
							value: q,
							onChange: (e) => setQ(e.target.value),
							placeholder: "Search perfumes, skincare, gifts…",
							className: "flex-1 bg-transparent py-1 text-sm outline-none placeholder:text-muted-foreground"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "submit",
							className: "border border-foreground px-3 py-1.5 text-[11px] uppercase tracking-[0.2em] hover:bg-foreground hover:text-background",
							children: "Search"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setSearchOpen(false),
							"aria-label": "Close search",
							className: "text-muted-foreground hover:text-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
						})
					]
				})
			}),
			open && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "md:hidden border-t border-border/60 bg-background",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-7xl px-4 py-4 flex flex-col gap-3 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							onSubmit: submitSearch,
							className: "flex items-center gap-2 border border-border px-2 py-1.5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 text-muted-foreground" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									htmlFor: "site-search-mobile",
									className: "sr-only",
									children: "Search products"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									id: "site-search-mobile",
									value: q,
									onChange: (e) => setQ(e.target.value),
									placeholder: "Search products…",
									className: "flex-1 bg-transparent py-1 text-sm outline-none placeholder:text-muted-foreground"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							onClick: () => setOpen(false),
							className: "py-1",
							children: "Home"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/products",
							search: { q: void 0 },
							onClick: () => setOpen(false),
							className: "py-1",
							children: "Shop All"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/categories",
							onClick: () => setOpen(false),
							className: "py-1",
							children: "Categories"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/track",
							onClick: () => setOpen(false),
							className: "py-1 inline-flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PackageSearch, { className: "size-4" }), " Track Order"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: whatsappHref(`Hello ${brand}, I'd like to know more.`, waNumber),
							target: "_blank",
							rel: "noopener noreferrer",
							className: "mt-2 inline-flex items-center gap-2 text-gold",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "size-4" }),
								" ",
								waDisplay
							]
						})
					]
				})
			})
		]
	});
}
function SiteFooter() {
	const settingsQuery = useQuery(siteSettingsQuery());
	const settings = settingsQuery.data ?? null;
	const isSettingsLoading = settingsQuery.isPending || settingsQuery.isFetching;
	const brand = settings?.brand_name ?? "Suméra Luxe";
	const tagline = settings?.brand_tagline ?? "Beauty · Skincare · Gifts";
	const email = settings?.contact_email ?? "hello@sumeraluxe.com";
	const facebook = settings?.facebook_url ?? "#";
	const waNumber = settings?.whatsapp_number ?? "8801322126233";
	const waDisplay = settings?.whatsapp_display ?? "+880 1322-126233";
	const about = settings?.about_text ?? "A quiet luxury house for the modern woman — considered fragrances, refined skincare, and gifts made to be remembered.";
	if (isSettingsLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
		className: "mt-24 border-t border-border/60 bg-[color-mix(in_oklab,var(--cream)_92%,var(--gold)_8%)]",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto max-w-7xl px-4 py-14 md:px-8",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-10 md:grid-cols-3",
				children: Array.from({ length: 3 }).map((_, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-5 w-24 animate-pulse rounded bg-muted/70" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-4 w-full animate-pulse rounded bg-muted/50" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-4 w-3/4 animate-pulse rounded bg-muted/50" })
					]
				}, index))
			})
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
		className: "mt-24 border-t border-border/60 bg-[color-mix(in_oklab,var(--cream)_92%,var(--gold)_8%)]",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-4 py-14 pb-24 md:px-8 md:pb-14",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-10 md:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-serif text-2xl",
							children: brand
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-1 text-xs uppercase tracking-[0.25em] text-gold",
							children: tagline
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-sm text-muted-foreground leading-relaxed",
							children: about
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
						className: "font-serif text-lg",
						children: "Company"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-col gap-2 text-sm text-foreground/80",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/about",
								className: "hover:text-gold",
								children: ["About ", brand]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/privacy",
								className: "hover:text-gold",
								children: "Privacy Policy"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/terms",
								className: "hover:text-gold",
								children: "Terms & Conditions"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/shipping-returns",
								className: "hover:text-gold",
								children: "Shipping & Returns"
							})
						]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
						className: "font-serif text-lg",
						children: "Contact"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-col gap-3 text-sm text-foreground/80",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: whatsappHref(`Hello ${brand}, I'd like to know more.`, waNumber),
								target: "_blank",
								rel: "noopener noreferrer",
								className: "inline-flex items-center gap-2 hover:text-gold",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "size-4" }),
									" ",
									waDisplay
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: `mailto:${email}`,
								className: "inline-flex items-center gap-2 hover:text-gold",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "size-4" }),
									" ",
									email
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: facebook,
								target: "_blank",
								rel: "noopener noreferrer",
								className: "inline-flex items-center gap-2 hover:text-gold",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Facebook, { className: "size-4" }), " Facebook"]
							})
						]
					})] })
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-12 hidden flex-col items-center gap-2 border-t border-border/60 pt-6 text-center text-xs text-muted-foreground md:flex",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "gold-rule" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					"© ",
					(/* @__PURE__ */ new Date()).getFullYear(),
					" ",
					brand,
					". All rights reserved."
				] })]
			})]
		})
	});
}
var tabs = [
	{
		to: "/",
		label: "Home",
		icon: House,
		match: (p) => p === "/"
	},
	{
		to: "/categories",
		label: "Categories",
		icon: LayoutGrid,
		match: (p) => p.startsWith("/categories") || p.startsWith("/category")
	},
	{
		to: "/cart",
		label: "Cart",
		icon: ShoppingBag,
		match: (p) => p.startsWith("/cart")
	},
	{
		to: "/track",
		label: "Track",
		icon: PackageSearch,
		match: (p) => p.startsWith("/track")
	}
];
function MobileBottomBar() {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const { count } = useCart();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
		className: "fixed bottom-0 left-0 right-0 z-40 border-t border-border/60 bg-background/95 backdrop-blur md:hidden",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mx-auto grid max-w-md grid-cols-4",
			children: tabs.map(({ to, label, icon: Icon, match }) => {
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to,
					className: `flex flex-col items-center justify-center gap-1 py-2.5 text-[10px] uppercase tracking-[0.2em] ${match(pathname) ? "text-gold" : "text-foreground/70"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "relative",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" }), to === "/cart" && count > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "absolute -right-2 -top-2 grid h-4 min-w-4 place-items-center rounded-full bg-foreground px-1 text-[9px] font-semibold text-background",
							children: count
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label })]
				}) }, to);
			})
		})
	});
}
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Page not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Go home"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Something went wrong on our end. You can try refreshing or head back home."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$25 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "Suméra Luxe Bangladesh — Luxury Perfume, Skincare & Gifts" },
			{
				name: "description",
				content: "Shop luxury perfume, skincare, makeup and gift sets at Suméra Luxe — Bangladesh's quiet-luxury beauty house. Cash on delivery in Dhaka and across Bangladesh."
			},
			{
				name: "author",
				content: "Suméra Luxe"
			},
			{
				name: "keywords",
				content: "luxury perfume Bangladesh, skincare Bangladesh, makeup Dhaka, gift sets Bangladesh, cash on delivery beauty, Suméra Luxe"
			},
			{
				property: "og:title",
				content: "Suméra Luxe Bangladesh — Luxury Perfume, Skincare & Gifts"
			},
			{
				property: "og:description",
				content: "Shop luxury perfume, skincare, makeup and gift sets at Suméra Luxe — Bangladesh's quiet-luxury beauty house. Cash on delivery in Dhaka and across Bangladesh."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				property: "og:locale",
				content: "en_BD"
			},
			{
				property: "og:locale:alternate",
				content: "bn_BD"
			},
			{
				property: "og:site_name",
				content: "Suméra Luxe"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			},
			{
				name: "geo.region",
				content: "BD"
			},
			{
				name: "geo.placename",
				content: "Dhaka, Bangladesh"
			},
			{
				name: "geo.position",
				content: "23.8103;90.4125"
			},
			{
				name: "ICBM",
				content: "23.8103, 90.4125"
			},
			{
				name: "twitter:title",
				content: "Suméra Luxe Bangladesh — Luxury Perfume, Skincare & Gifts"
			},
			{
				name: "twitter:description",
				content: "Shop luxury perfume, skincare, makeup and gift sets at Suméra Luxe — Bangladesh's quiet-luxury beauty house. Cash on delivery in Dhaka and across Bangladesh."
			},
			{
				property: "og:image",
				content: "https://storage.googleapis.com/gpt-engineer-file-uploads/attachments/og-images/b4e784b4-52e2-4f2a-81e0-e90068be5194"
			},
			{
				name: "twitter:image",
				content: "https://storage.googleapis.com/gpt-engineer-file-uploads/attachments/og-images/b4e784b4-52e2-4f2a-81e0-e90068be5194"
			}
		],
		links: [
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700&family=Inter:wght@300;400;500;600&family=Hind+Siliguri:wght@400;500;600;700&display=swap"
			}
		],
		scripts: [{
			type: "application/ld+json",
			children: JSON.stringify({
				"@context": "https://schema.org",
				"@type": "Organization",
				name: "Suméra Luxe",
				url: "https://sumeraluxe.com",
				description: "Bangladesh's quiet-luxury beauty house for fragrance, skincare and gifts, with cash on delivery nationwide.",
				address: {
					"@type": "PostalAddress",
					addressCountry: "BD",
					addressRegion: "Dhaka",
					addressLocality: "Dhaka"
				},
				areaServed: {
					"@type": "Country",
					name: "Bangladesh"
				},
				contactPoint: {
					"@type": "ContactPoint",
					telephone: "+8801322126233",
					contactType: "customer service",
					areaServed: "BD",
					availableLanguage: ["en", "bn"]
				}
			})
		}, {
			type: "application/ld+json",
			children: JSON.stringify({
				"@context": "https://schema.org",
				"@type": "WebSite",
				name: "Suméra Luxe",
				url: "https://sumeraluxe.com",
				inLanguage: ["en-BD", "bn-BD"]
			})
		}]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function isAdminTrackingRoute(pathname) {
	return pathname.startsWith("/admin") || pathname === "/admin-access" || pathname === "/auth";
}
function TrackingRouterObserver() {
	const location = useRouterState({ select: (s) => s.location });
	const lastTrackedPathRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		initializeTracking();
	}, []);
	(0, import_react.useEffect)(() => {
		const pathname = typeof location.pathname === "string" ? location.pathname : String(location.pathname ?? "");
		if (isAdminTrackingRoute(pathname)) return;
		const pathKey = `${pathname}${location.search == null ? "" : typeof location.search === "string" ? location.search : typeof location.search.toString === "function" ? location.search.toString() : ""}`;
		if (lastTrackedPathRef.current === pathKey) return;
		lastTrackedPathRef.current = pathKey;
		trackPageView({
			page_location: typeof window !== "undefined" ? window.location.href : void 0,
			page_title: typeof document !== "undefined" ? document.title : void 0
		});
	}, [location.pathname, location.search]);
	return null;
}
function GtmSnippetInjector() {
	const settings = useSiteSettings();
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const isAdmin = pathname.startsWith("/admin") || pathname === "/admin-access" || pathname === "/auth";
	(0, import_react.useEffect)(() => {
		const removeInjectedNodes = () => {
			document.querySelectorAll("[data-gtm-snippet=\"true\"]").forEach((node) => node.remove());
		};
		if (isAdmin) {
			removeInjectedNodes();
			return removeInjectedNodes;
		}
		removeInjectedNodes();
		const headMarkup = settings?.gtm_head_snippet?.trim();
		const bodyMarkup = settings?.gtm_body_snippet?.trim();
		if (!headMarkup && !bodyMarkup) return removeInjectedNodes;
		if (headMarkup) {
			const fragment = document.createRange().createContextualFragment(headMarkup);
			Array.from(fragment.childNodes).forEach((node) => {
				if (node instanceof Element) node.setAttribute("data-gtm-snippet", "true");
				document.head.appendChild(node);
			});
		}
		if (bodyMarkup) {
			const fragment = document.createRange().createContextualFragment(bodyMarkup);
			Array.from(fragment.childNodes).forEach((node) => {
				if (node instanceof Element) node.setAttribute("data-gtm-snippet", "true");
				document.body.prepend(node);
			});
		}
		return removeInjectedNodes;
	}, [
		isAdmin,
		settings?.gtm_head_snippet,
		settings?.gtm_body_snippet
	]);
	return null;
}
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en-BD",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$25.useRouteContext();
	const isAdmin = useRouterState({ select: (s) => s.location.pathname }).startsWith("/admin");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CartProvider, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, { position: "bottom-right" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrackingRouterObserver, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GtmSnippetInjector, {}),
			isAdmin ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-h-screen flex-col",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
						className: "flex-1 pb-16 md:pb-0",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileBottomBar, {})] })
		] })
	});
}
var $$splitComponentImporter$22 = () => import("./routes-Dx64SO-2.mjs");
var Route$24 = createFileRoute("/")({
	head: () => ({
		meta: [
			{ title: "Suméra Luxe Bangladesh — Luxury Perfume, Skincare & Gifts" },
			{
				name: "description",
				content: "Shop luxury perfume, skincare, makeup and gift sets at Suméra Luxe — Bangladesh's quiet-luxury beauty house. Cash on delivery in Dhaka and across Bangladesh."
			},
			{
				property: "og:title",
				content: "Suméra Luxe Bangladesh — Luxury Perfume, Skincare & Gifts"
			},
			{
				property: "og:description",
				content: "Shop luxury perfume, skincare, makeup and gift sets at Suméra Luxe — Bangladesh's quiet-luxury beauty house. Cash on delivery in Dhaka and across Bangladesh."
			},
			{
				property: "og:locale",
				content: "en_BD"
			},
			{
				property: "og:url",
				content: "https://sumeraluxe.com/"
			}
		],
		links: [{
			rel: "canonical",
			href: "https://sumeraluxe.com/"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$22, "component")
});
var $$splitComponentImporter$21 = () => import("./route-Di7iQBCH.mjs");
var hasAdminCookie$1 = () => {
	return document.cookie.includes("admin_authorized=true");
};
var Route$23 = createFileRoute("/_authenticated")({
	ssr: false,
	beforeLoad: async () => {
		if (!hasAdminCookie$1()) throw redirect({ to: "/" });
		const { data, error } = await supabase.auth.getUser();
		if (error || !data.user) throw redirect({ to: "/auth" });
		return { user: data.user };
	},
	component: lazyRouteComponent($$splitComponentImporter$21, "component")
});
var $$splitComponentImporter$20 = () => import("./about-Bdk8_JzB.mjs");
var URL$4 = "https://sumeraluxe.com/about";
var TITLE$4 = "About Suméra Luxe — Luxury Beauty House in Bangladesh";
var DESC$4 = "Suméra Luxe is a Dhaka-based luxury beauty house curating perfumes, skincare and gifting for the modern Bangladeshi woman. Discover our story, values and craft.";
var Route$22 = createFileRoute("/about")({
	head: () => ({
		meta: [
			{ title: TITLE$4 },
			{
				name: "description",
				content: DESC$4
			},
			{
				name: "keywords",
				content: "about Suméra Luxe, luxury beauty Bangladesh, Dhaka perfume brand, Bangladeshi skincare house"
			},
			{
				property: "og:title",
				content: TITLE$4
			},
			{
				property: "og:description",
				content: DESC$4
			},
			{
				property: "og:url",
				content: URL$4
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				property: "og:locale",
				content: "en_BD"
			}
		],
		links: [{
			rel: "canonical",
			href: URL$4
		}],
		scripts: [{
			type: "application/ld+json",
			children: JSON.stringify({
				"@context": "https://schema.org",
				"@type": "AboutPage",
				name: TITLE$4,
				description: DESC$4,
				url: URL$4,
				inLanguage: "en-BD",
				about: {
					"@type": "Organization",
					name: "Suméra Luxe",
					areaServed: "BD"
				}
			})
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$20, "component")
});
var $$splitComponentImporter$19 = () => import("./admin-access-DzdDcSmf.mjs");
var Route$21 = createFileRoute("/admin-access")({
	validateSearch: (search) => ({ key: search.key || "" }),
	component: lazyRouteComponent($$splitComponentImporter$19, "component")
});
var $$splitComponentImporter$18 = () => import("./auth-s3YWohe7.mjs");
var hasAdminCookie = () => {
	return document.cookie.includes("admin_authorized=true");
};
var Route$20 = createFileRoute("/auth")({
	beforeLoad: async () => {
		if (!hasAdminCookie()) throw redirect({ to: "/" });
	},
	head: () => ({
		meta: [
			{ title: "Sign in — Suméra Luxe" },
			{
				name: "description",
				content: "Sign in to the Suméra Luxe admin dashboard to manage products, orders and settings."
			},
			{
				property: "og:title",
				content: "Sign in — Suméra Luxe"
			},
			{
				property: "og:description",
				content: "Sign in to the Suméra Luxe admin dashboard to manage the store."
			},
			{
				property: "og:url",
				content: "https://sumeraluxe.com/auth"
			},
			{
				name: "robots",
				content: "noindex"
			}
		],
		links: [{
			rel: "canonical",
			href: "https://sumeraluxe.com/auth"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$18, "component")
});
var $$splitComponentImporter$17 = () => import("./cart-BQFpIycN.mjs");
var Route$19 = createFileRoute("/cart")({
	head: () => ({
		meta: [
			{ title: "Your Bag — Suméra Luxe" },
			{
				name: "description",
				content: "Review the pieces in your Suméra Luxe bag before checkout."
			},
			{
				property: "og:title",
				content: "Your Bag — Suméra Luxe"
			},
			{
				property: "og:description",
				content: "Review your bag."
			},
			{
				property: "og:url",
				content: "https://sumeraluxe.com/cart"
			},
			{
				name: "robots",
				content: "noindex"
			}
		],
		links: [{
			rel: "canonical",
			href: "https://sumeraluxe.com/cart"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$17, "component")
});
var $$splitComponentImporter$16 = () => import("./categories-q6UV1Ic8.mjs");
var Route$18 = createFileRoute("/categories")({
	head: () => ({
		meta: [
			{ title: "Luxury Beauty Categories in Bangladesh — Suméra Luxe" },
			{
				name: "description",
				content: "Explore Suméra Luxe collections in Bangladesh — perfume, skincare, makeup, gift sets and bath & body with cash on delivery nationwide."
			},
			{
				property: "og:title",
				content: "Luxury Beauty Categories in Bangladesh — Suméra Luxe"
			},
			{
				property: "og:description",
				content: "Every Suméra Luxe collection — delivered across Bangladesh."
			},
			{
				property: "og:locale",
				content: "en_BD"
			},
			{
				property: "og:url",
				content: "https://sumeraluxe.com/categories"
			}
		],
		links: [{
			rel: "canonical",
			href: "https://sumeraluxe.com/categories"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$16, "component")
});
var $$splitComponentImporter$15 = () => import("./checkout-DEF5KkKr.mjs");
var Route$17 = createFileRoute("/checkout")({
	head: () => ({
		meta: [
			{ title: "Checkout — Suméra Luxe" },
			{
				name: "description",
				content: "Complete your Suméra Luxe order with cash on delivery."
			},
			{
				property: "og:title",
				content: "Checkout — Suméra Luxe"
			},
			{
				property: "og:description",
				content: "Cash on delivery checkout."
			},
			{
				property: "og:url",
				content: "https://sumeraluxe.com/checkout"
			},
			{
				name: "robots",
				content: "noindex"
			}
		],
		links: [{
			rel: "canonical",
			href: "https://sumeraluxe.com/checkout"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$15, "component")
});
var BASE_URL$1 = "https://sumeraluxe.com";
var CURRENCY = "BDT";
var CSV_BOM = "﻿";
function quote(value) {
	if (value == null) return "";
	return `"${String(value).replace(/"/g, "\"\"")}"`;
}
function productUrl(slug) {
	return `${BASE_URL$1}/products/${slug}`;
}
function imageUrl(url) {
	if (!url) return "";
	return url.startsWith("http") ? url : `${BASE_URL$1}${url.startsWith("/") ? "" : "/"}${url}`;
}
function getEffectivePrices(variantPrice, variantDiscountPrice, productBasePrice, productDiscountPrice) {
	const regularPrice = variantPrice ?? productBasePrice;
	const salePrice = variantDiscountPrice ?? productDiscountPrice;
	return {
		price: `${regularPrice.toFixed(2)} ${CURRENCY}`,
		sale_price: salePrice != null && salePrice < regularPrice ? `${salePrice.toFixed(2)} ${CURRENCY}` : ""
	};
}
function normalizeText(value) {
	return value?.trim().replace(/\s+/g, " ") ?? "";
}
var Route$16 = createFileRoute("/fb-feed-12111014.csv")({ server: { handlers: { GET: async () => {
	try {
		const { data: settings, error: settingsError } = await supabase.from("site_settings").select("brand_name").eq("id", 1).maybeSingle();
		const { data: products, error: productsError } = await supabase.from("products").select(`id, slug, name, description, base_price, discount_price, stock, brand_name, category:categories(name), images:product_images(id,url,sort_order), variants:product_variants(id,color,size,price,discount_price,image_url,stock,sort_order), video_url`).order("sort_order", { ascending: true });
		if (settingsError) throw settingsError;
		if (productsError) throw productsError;
		const defaultBrand = settings?.brand_name ?? "Sumera Luxe";
		const rows = [];
		rows.push([
			"id",
			"title",
			"description",
			"availability",
			"condition",
			"price",
			"link",
			"image_link",
			"brand",
			"google_product_category",
			"fb_product_category",
			"quantity_to_sell_on_facebook",
			"sale_price",
			"sale_price_effective_date",
			"item_group_id",
			"gender",
			"color",
			"size",
			"age_group",
			"material",
			"pattern",
			"shipping",
			"shipping_weight",
			"offer_disclaimer",
			"offer_disclaimer_url",
			"video[0].url",
			"video[0].tag[0]",
			"gtin",
			"style[0]"
		].join(","));
		for (const product of products ?? []) {
			if (!product?.slug || !product?.name) continue;
			const categoryName = product?.category?.name ?? "";
			const firstImage = imageUrl((Array.isArray(product.images) ? [...product.images].sort((a, b) => (a.sort_order ?? 0) - (b.sort_order ?? 0)) : [])[0]?.url);
			const variants = Array.isArray(product.variants) ? [...product.variants].sort((a, b) => (a.sort_order ?? 0) - (b.sort_order ?? 0)) : [];
			const addRow = (variant) => {
				const variantImage = imageUrl(variant?.image_url ?? null) || firstImage;
				const stock = variant?.stock ?? product.stock ?? 0;
				const { price, sale_price } = getEffectivePrices(variant?.price ?? null, variant?.discount_price ?? null, product.base_price, product.discount_price);
				const availability = stock > 0 ? "in stock" : "out of stock";
				const productBrand = product.brand_name?.trim() || defaultBrand;
				rows.push([
					quote(variant?.id ?? product.id),
					quote(product.name),
					quote(normalizeText(product.description)),
					quote(availability),
					quote("new"),
					quote(price),
					quote(productUrl(product.slug)),
					quote(variantImage),
					quote(productBrand),
					quote(categoryName),
					quote(categoryName),
					quote(stock),
					quote(sale_price),
					quote(""),
					quote(variant ? product.id : ""),
					quote(""),
					quote(variant?.color ?? ""),
					quote(variant?.size ?? ""),
					quote(""),
					quote(""),
					quote(""),
					quote(""),
					quote(""),
					quote(""),
					quote(""),
					quote(product.video_url ?? ""),
					quote(""),
					quote(""),
					quote("")
				].join(","));
			};
			if (variants.length > 0) for (const variant of variants) addRow(variant);
			else addRow(null);
		}
		return new Response(CSV_BOM + rows.join("\n"), { headers: {
			"Content-Type": "text/csv; charset=utf-8",
			"Cache-Control": "public, max-age=3600"
		} });
	} catch (error) {
		let message;
		if (error instanceof Error) message = error.stack ?? error.message;
		else if (typeof error === "object" && error !== null) try {
			message = JSON.stringify(error, Object.getOwnPropertyNames(error), 2);
		} catch {
			message = String(error);
		}
		else message = String(error);
		console.error("Facebook feed generation error:", error);
		return new Response(`Error generating Facebook feed:\n${message}`, {
			status: 200,
			headers: { "Content-Type": "text/plain; charset=utf-8" }
		});
	}
} } } });
var $$splitComponentImporter$14 = () => import("./privacy-CjS9FBut.mjs");
var URL$3 = "https://sumeraluxe.com/privacy";
var TITLE$3 = "Privacy Policy — Suméra Luxe Bangladesh";
var DESC$3 = "How Suméra Luxe collects, uses and protects the personal information of customers in Bangladesh — including orders, delivery, WhatsApp and marketing.";
var Route$15 = createFileRoute("/privacy")({
	head: () => ({
		meta: [
			{ title: TITLE$3 },
			{
				name: "description",
				content: DESC$3
			},
			{
				property: "og:title",
				content: TITLE$3
			},
			{
				property: "og:description",
				content: DESC$3
			},
			{
				property: "og:url",
				content: URL$3
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				property: "og:locale",
				content: "en_BD"
			}
		],
		links: [{
			rel: "canonical",
			href: URL$3
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$14, "component")
});
var $$splitComponentImporter$13 = () => import("./shipping-returns-BMcIE8fT.mjs");
var URL$2 = "https://sumeraluxe.com/shipping-returns";
var TITLE$2 = "Shipping & Returns — Suméra Luxe Bangladesh";
var DESC$2 = "Delivery charges, timelines and return policy for Suméra Luxe orders inside Dhaka and across Bangladesh — cash on delivery, hand-checked packing and easy support.";
var Route$14 = createFileRoute("/shipping-returns")({
	head: () => ({
		meta: [
			{ title: TITLE$2 },
			{
				name: "description",
				content: DESC$2
			},
			{
				property: "og:title",
				content: TITLE$2
			},
			{
				property: "og:description",
				content: DESC$2
			},
			{
				property: "og:url",
				content: URL$2
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				property: "og:locale",
				content: "en_BD"
			}
		],
		links: [{
			rel: "canonical",
			href: URL$2
		}],
		scripts: [{
			type: "application/ld+json",
			children: JSON.stringify({
				"@context": "https://schema.org",
				"@type": "FAQPage",
				mainEntity: [
					{
						"@type": "Question",
						name: "How much is delivery in Bangladesh?",
						acceptedAnswer: {
							"@type": "Answer",
							text: "Tk. 60 inside Dhaka and Tk. 120 outside Dhaka. Delivery charge is added at checkout and paid on delivery."
						}
					},
					{
						"@type": "Question",
						name: "How long does delivery take?",
						acceptedAnswer: {
							"@type": "Answer",
							text: "1–2 working days inside Dhaka and 3–5 working days for the rest of Bangladesh after your order is confirmed."
						}
					},
					{
						"@type": "Question",
						name: "Can I return a Suméra Luxe order?",
						acceptedAnswer: {
							"@type": "Answer",
							text: "Yes — for damaged, defective or wrong items, contact us within 24 hours of delivery with photos of the parcel and product."
						}
					}
				]
			})
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$13, "component")
});
var BASE_URL = "https://sumeraluxe.com";
var Route$13 = createFileRoute("/sitemap.xml")({ server: { handlers: { GET: async () => {
	const entries = [
		{
			path: "/",
			changefreq: "weekly",
			priority: "1.0"
		},
		{
			path: "/products",
			changefreq: "weekly",
			priority: "0.9"
		},
		{
			path: "/categories",
			changefreq: "weekly",
			priority: "0.8"
		},
		{
			path: "/track",
			changefreq: "monthly",
			priority: "0.4"
		},
		{
			path: "/about",
			changefreq: "monthly",
			priority: "0.5"
		},
		{
			path: "/privacy",
			changefreq: "yearly",
			priority: "0.3"
		},
		{
			path: "/terms",
			changefreq: "yearly",
			priority: "0.3"
		},
		{
			path: "/shipping-returns",
			changefreq: "monthly",
			priority: "0.5"
		},
		{
			path: "/blog/best-perfumes-for-women",
			changefreq: "monthly",
			priority: "0.6"
		}
	];
	try {
		const supa = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_PUBLISHABLE_KEY, { auth: {
			storage: void 0,
			persistSession: false,
			autoRefreshToken: false
		} });
		const [{ data: cats }, { data: prods }] = await Promise.all([supa.from("categories").select("slug, updated_at, image_url").eq("is_active", true), supa.from("products").select("slug, updated_at, image_url").eq("is_active", true)]);
		for (const c of cats ?? []) if (c.slug) entries.push({
			path: `/category/${c.slug}`,
			changefreq: "weekly",
			priority: "0.7",
			lastmod: c.updated_at ?? void 0,
			image: c.image_url ?? void 0
		});
		for (const p of prods ?? []) if (p.slug) entries.push({
			path: `/products/${p.slug}`,
			changefreq: "weekly",
			priority: "0.7",
			lastmod: p.updated_at ?? void 0,
			image: p.image_url ?? void 0
		});
	} catch {}
	const xml = [
		`<?xml version="1.0" encoding="UTF-8"?>`,
		`<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">`,
		...entries.map((e) => [
			`  <url>`,
			`    <loc>${BASE_URL}${e.path}</loc>`,
			e.lastmod ? `    <lastmod>${new Date(e.lastmod).toISOString()}</lastmod>` : null,
			e.changefreq ? `    <changefreq>${e.changefreq}</changefreq>` : null,
			e.priority ? `    <priority>${e.priority}</priority>` : null,
			e.image ? `    <image:image>\n      <image:loc>${e.image.startsWith("/") ? BASE_URL + e.image : e.image}</image:loc>\n    </image:image>` : null,
			`  </url>`
		].filter(Boolean).join("\n")),
		`</urlset>`
	].join("\n");
	return new Response(xml, { headers: {
		"Content-Type": "application/xml",
		"Cache-Control": "public, max-age=3600"
	} });
} } } });
var $$splitComponentImporter$12 = () => import("./terms-tp6LU71_.mjs");
var URL$1 = "https://sumeraluxe.com/terms";
var TITLE$1 = "Terms & Conditions — Suméra Luxe Bangladesh";
var DESC$1 = "The terms that govern orders, pricing, delivery and use of Suméra Luxe by customers in Bangladesh. Please read before placing your order.";
var Route$12 = createFileRoute("/terms")({
	head: () => ({
		meta: [
			{ title: TITLE$1 },
			{
				name: "description",
				content: DESC$1
			},
			{
				property: "og:title",
				content: TITLE$1
			},
			{
				property: "og:description",
				content: DESC$1
			},
			{
				property: "og:url",
				content: URL$1
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				property: "og:locale",
				content: "en_BD"
			}
		],
		links: [{
			rel: "canonical",
			href: URL$1
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$12, "component")
});
var $$splitComponentImporter$11 = () => import("./track-jHpdtM31.mjs");
var Route$11 = createFileRoute("/track")({
	head: () => ({
		meta: [
			{ title: "Track Your Order in Bangladesh — Suméra Luxe" },
			{
				name: "description",
				content: "Track your Suméra Luxe order in Bangladesh using your phone number — see status from Dhaka to nationwide delivery."
			},
			{
				property: "og:title",
				content: "Track Your Order in Bangladesh — Suméra Luxe"
			},
			{
				property: "og:description",
				content: "Look up your Suméra Luxe order status by phone number in Bangladesh."
			},
			{
				property: "og:locale",
				content: "en_BD"
			},
			{
				property: "og:url",
				content: "https://sumeraluxe.com/track"
			},
			{
				name: "robots",
				content: "noindex"
			}
		],
		links: [{
			rel: "canonical",
			href: "https://sumeraluxe.com/track"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$11, "component")
});
var $$splitComponentImporter$10 = () => import("./admin-X3Zmhe2J.mjs");
var Route$10 = createFileRoute("/_authenticated/admin")({ component: lazyRouteComponent($$splitComponentImporter$10, "component") });
var $$splitComponentImporter$9 = () => import("./blog.best-perfumes-for-women-BZwCapZT.mjs");
var URL = "https://sumeraluxe.com/blog/best-perfumes-for-women";
var TITLE = "10 Best Luxury Perfumes for Women in Bangladesh — Suméra Luxe";
var DESC = "An editor's guide to the 10 best luxury perfumes for women in Bangladesh — curated fragrance picks for day, evening, work and gifting, with cash on delivery from Suméra Luxe.";
var Route$9 = createFileRoute("/blog/best-perfumes-for-women")({
	head: () => ({
		meta: [
			{ title: TITLE },
			{
				name: "description",
				content: DESC
			},
			{
				property: "og:title",
				content: TITLE
			},
			{
				property: "og:description",
				content: DESC
			},
			{
				property: "og:url",
				content: URL
			},
			{
				property: "og:type",
				content: "article"
			}
		],
		links: [{
			rel: "canonical",
			href: URL
		}],
		scripts: [{
			type: "application/ld+json",
			children: JSON.stringify({
				"@context": "https://schema.org",
				"@type": "Article",
				headline: "The 10 Best Luxury Perfumes for Women",
				description: DESC,
				author: {
					"@type": "Organization",
					name: "Suméra Luxe"
				},
				publisher: {
					"@type": "Organization",
					name: "Suméra Luxe"
				},
				mainEntityOfPage: URL
			})
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$9, "component")
});
var $$splitComponentImporter$8 = () => import("./admin.index-BfalH-7n.mjs");
var Route$8 = createFileRoute("/_authenticated/admin/")({ component: lazyRouteComponent($$splitComponentImporter$8, "component") });
var $$splitComponentImporter$7 = () => import("./admin.banners-3qzfXBBw.mjs");
var Route$7 = createFileRoute("/_authenticated/admin/banners")({ component: lazyRouteComponent($$splitComponentImporter$7, "component") });
var $$splitComponentImporter$6 = () => import("./admin.categories-Drn7whJZ.mjs");
var Route$6 = createFileRoute("/_authenticated/admin/categories")({ component: lazyRouteComponent($$splitComponentImporter$6, "component") });
var $$splitComponentImporter$5 = () => import("./admin.discounts-DppV4_di.mjs");
var Route$5 = createFileRoute("/_authenticated/admin/discounts")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./admin.hero-slides-FixgMiUS.mjs");
var Route$4 = createFileRoute("/_authenticated/admin/hero-slides")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./admin.orders-Dw21RyD3.mjs");
var Route$3 = createFileRoute("/_authenticated/admin/orders")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./admin.settings-DnQKr-6l.mjs");
var Route$2 = createFileRoute("/_authenticated/admin/settings")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./admin.team-ys2-tDMC.mjs");
var Route$1 = createFileRoute("/_authenticated/admin/team")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./admin.products.index-BjOQMJAN.mjs");
var Route = createFileRoute("/_authenticated/admin/products/")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var IndexRoute = Route$24.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$25
});
var AuthenticatedRouteRoute = Route$23.update({
	id: "/_authenticated",
	getParentRoute: () => Route$25
});
var AboutRoute = Route$22.update({
	id: "/about",
	path: "/about",
	getParentRoute: () => Route$25
});
var AdminAccessRoute = Route$21.update({
	id: "/admin-access",
	path: "/admin-access",
	getParentRoute: () => Route$25
});
var AuthRoute = Route$20.update({
	id: "/auth",
	path: "/auth",
	getParentRoute: () => Route$25
});
var CartRoute = Route$19.update({
	id: "/cart",
	path: "/cart",
	getParentRoute: () => Route$25
});
var CategoriesRoute = Route$18.update({
	id: "/categories",
	path: "/categories",
	getParentRoute: () => Route$25
});
var CheckoutRoute = Route$17.update({
	id: "/checkout",
	path: "/checkout",
	getParentRoute: () => Route$25
});
var FbFeed12111014DotcsvRoute = Route$16.update({
	id: "/fb-feed-12111014.csv",
	path: "/fb-feed-12111014.csv",
	getParentRoute: () => Route$25
});
var OrderSuccessRoute = Route$28.update({
	id: "/order-success",
	path: "/order-success",
	getParentRoute: () => Route$25
});
var PrivacyRoute = Route$15.update({
	id: "/privacy",
	path: "/privacy",
	getParentRoute: () => Route$25
});
var ShippingReturnsRoute = Route$14.update({
	id: "/shipping-returns",
	path: "/shipping-returns",
	getParentRoute: () => Route$25
});
var SitemapDotxmlRoute = Route$13.update({
	id: "/sitemap.xml",
	path: "/sitemap.xml",
	getParentRoute: () => Route$25
});
var TermsRoute = Route$12.update({
	id: "/terms",
	path: "/terms",
	getParentRoute: () => Route$25
});
var TrackRoute = Route$11.update({
	id: "/track",
	path: "/track",
	getParentRoute: () => Route$25
});
var AuthenticatedAdminRoute = Route$10.update({
	id: "/admin",
	path: "/admin",
	getParentRoute: () => AuthenticatedRouteRoute
});
var BlogBestPerfumesForWomenRoute = Route$9.update({
	id: "/blog/best-perfumes-for-women",
	path: "/blog/best-perfumes-for-women",
	getParentRoute: () => Route$25
});
var CategorySlugRoute = Route$27.update({
	id: "/category/$slug",
	path: "/category/$slug",
	getParentRoute: () => Route$25
});
var ProductsIndexRoute = Route$30.update({
	id: "/products/",
	path: "/products/",
	getParentRoute: () => Route$25
});
var ProductsSlugRoute = Route$29.update({
	id: "/products/$slug",
	path: "/products/$slug",
	getParentRoute: () => Route$25
});
var AuthenticatedAdminIndexRoute = Route$8.update({
	id: "/",
	path: "/",
	getParentRoute: () => AuthenticatedAdminRoute
});
var AuthenticatedAdminBannersRoute = Route$7.update({
	id: "/banners",
	path: "/banners",
	getParentRoute: () => AuthenticatedAdminRoute
});
var AuthenticatedAdminCategoriesRoute = Route$6.update({
	id: "/categories",
	path: "/categories",
	getParentRoute: () => AuthenticatedAdminRoute
});
var AuthenticatedAdminDiscountsRoute = Route$5.update({
	id: "/discounts",
	path: "/discounts",
	getParentRoute: () => AuthenticatedAdminRoute
});
var AuthenticatedAdminHeroSlidesRoute = Route$4.update({
	id: "/hero-slides",
	path: "/hero-slides",
	getParentRoute: () => AuthenticatedAdminRoute
});
var AuthenticatedAdminOrdersRoute = Route$3.update({
	id: "/orders",
	path: "/orders",
	getParentRoute: () => AuthenticatedAdminRoute
});
var AuthenticatedAdminSettingsRoute = Route$2.update({
	id: "/settings",
	path: "/settings",
	getParentRoute: () => AuthenticatedAdminRoute
});
var AuthenticatedAdminTeamRoute = Route$1.update({
	id: "/team",
	path: "/team",
	getParentRoute: () => AuthenticatedAdminRoute
});
var AuthenticatedAdminProductsIndexRoute = Route.update({
	id: "/products/",
	path: "/products/",
	getParentRoute: () => AuthenticatedAdminRoute
});
var AuthenticatedAdminRouteChildren = {
	AuthenticatedAdminBannersRoute,
	AuthenticatedAdminCategoriesRoute,
	AuthenticatedAdminDiscountsRoute,
	AuthenticatedAdminHeroSlidesRoute,
	AuthenticatedAdminOrdersRoute,
	AuthenticatedAdminSettingsRoute,
	AuthenticatedAdminTeamRoute,
	AuthenticatedAdminIndexRoute,
	AuthenticatedAdminProductsIdRoute: Route$26.update({
		id: "/products/$id",
		path: "/products/$id",
		getParentRoute: () => AuthenticatedAdminRoute
	}),
	AuthenticatedAdminProductsIndexRoute
};
var AuthenticatedRouteRouteChildren = { AuthenticatedAdminRoute: AuthenticatedAdminRoute._addFileChildren(AuthenticatedAdminRouteChildren) };
var rootRouteChildren = {
	IndexRoute,
	AuthenticatedRouteRoute: AuthenticatedRouteRoute._addFileChildren(AuthenticatedRouteRouteChildren),
	AboutRoute,
	AdminAccessRoute,
	AuthRoute,
	CartRoute,
	CategoriesRoute,
	CheckoutRoute,
	FbFeed12111014DotcsvRoute,
	OrderSuccessRoute,
	PrivacyRoute,
	ShippingReturnsRoute,
	SitemapDotxmlRoute,
	TermsRoute,
	TrackRoute,
	BlogBestPerfumesForWomenRoute,
	CategorySlugRoute,
	ProductsSlugRoute,
	ProductsIndexRoute
};
var routeTree = Route$25._addFileChildren(rootRouteChildren)._addFileTypes();
var getRouter = () => {
	return createRouter({
		routeTree,
		context: { queryClient: new QueryClient() },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { getRouter };
