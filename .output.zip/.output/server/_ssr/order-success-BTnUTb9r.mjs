import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/hcaptcha__react-hcaptcha+react.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { u as siteSettingsQuery } from "./queries-CN01OqZx.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as CircleCheck } from "../_libs/lucide-react.mjs";
import { s as trackPurchase } from "./helpers-BVzN2yBE.mjs";
import { r as buildPurchasePayload } from "./events-_Zkyx5JA.mjs";
import { t as Route } from "./order-success-BfI7xvSA.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/order-success-BTnUTb9r.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function OrderSuccess() {
	const { total, order } = Route.useSearch();
	const settingsQuery = useQuery(siteSettingsQuery());
	const settings = settingsQuery.data ?? null;
	const isSettingsLoading = settingsQuery.isPending || settingsQuery.isFetching;
	const currency = settings?.currency_symbol ?? "Tk. ";
	const purchaseTrackedRef = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		if (purchaseTrackedRef.current || typeof window === "undefined" || !order) return;
		const raw = window.sessionStorage.getItem("sumera_tracking_pending_purchase");
		if (!raw) return;
		try {
			const pending = JSON.parse(raw);
			if (!pending?.orderNumber || pending.orderNumber !== order) return;
			purchaseTrackedRef.current = true;
			trackPurchase(buildPurchasePayload(pending.orderNumber, Number(pending.total ?? total), (pending.items ?? []).map((item) => ({
				productId: item.productId,
				name: item.name,
				variantLabel: item.variantLabel,
				unitPrice: Number(item.unitPrice ?? 0),
				quantity: Number(item.quantity ?? 1)
			})), settings?.brand_name ?? null, typeof window !== "undefined" ? window.location.href : void 0));
			window.sessionStorage.removeItem("sumera_tracking_pending_purchase");
			window.sessionStorage.removeItem("sumera_tracking_last_purchase");
		} catch {
			purchaseTrackedRef.current = true;
		}
	}, [
		order,
		settings?.brand_name,
		total
	]);
	if (isSettingsLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-2xl px-4 py-24 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto h-14 w-14 animate-pulse rounded-full bg-muted/70" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto mt-6 h-4 w-24 animate-pulse rounded-full bg-muted/70" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto mt-4 h-8 w-2/3 animate-pulse rounded bg-muted/70" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto mt-6 h-4 w-full animate-pulse rounded bg-muted/50" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto mt-3 h-4 w-2/3 animate-pulse rounded bg-muted/50" })
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-2xl px-4 py-24 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, {
				className: "mx-auto size-14 text-gold",
				strokeWidth: 1.5
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 text-[11px] uppercase tracking-[0.35em] text-gold",
				children: "Merci Beaucoup"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-serif text-4xl",
				children: "Your order is placed."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "gold-rule mt-4" }),
			order && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-6 font-mono text-sm",
				children: ["Order #", order]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-muted-foreground",
				children: "A Suméra Luxe advisor will call you shortly to confirm your delivery. Payment is due in cash on arrival."
			}),
			total > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 font-serif text-2xl",
				children: [
					"Total · ",
					currency,
					total.toLocaleString()
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-10 flex flex-wrap justify-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "border border-foreground px-6 py-3 text-xs uppercase tracking-[0.25em] hover:bg-foreground hover:text-background",
					children: "Back home"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/products",
					search: { q: void 0 },
					className: "bg-foreground px-6 py-3 text-xs uppercase tracking-[0.25em] text-background hover:bg-foreground/85",
					children: "Continue shopping"
				})]
			})
		]
	});
}
//#endregion
export { OrderSuccess as component };
