import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-C1p6U3vi.mjs";
import { n as require_react, t as re } from "../_libs/hcaptcha__react-hcaptcha+react.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { _ as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/auth-s3YWohe7.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AuthPage() {
	const navigate = useNavigate();
	const captchaRef = (0, import_react.useRef)(null);
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [captchaToken, setCaptchaToken] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const resetCaptcha = () => {
		try {
			captchaRef.current?.resetCaptcha?.();
		} catch (e) {}
		setCaptchaToken(null);
	};
	const submit = async (e) => {
		e.preventDefault();
		if (!captchaToken) {
			toast.error("Please complete the captcha");
			return;
		}
		setBusy(true);
		try {
			const { data, error } = await supabase.auth.signInWithPassword({
				email,
				password,
				options: { captchaToken }
			});
			if (error) {
				resetCaptcha();
				if (error.message.includes("Invalid login credentials")) toast.error("Password incorrect");
				else if (error.message.includes("Captcha") || error.message.includes("already-seen")) toast.error("Captcha verification failed. Please try again");
				else toast.error(error.message ?? "Something went wrong");
				throw error;
			}
			toast.success("Login successful. Redirecting…");
			navigate({ to: "/admin" });
		} catch (err) {
			console.error("Catch error:", err);
		} finally {
			setBusy(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-md px-4 py-20",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-[11px] uppercase tracking-[0.35em] text-gold",
					children: "Admin"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 font-serif text-3xl",
					children: "Sign in"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "gold-rule mt-4" })
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: submit,
			className: "mt-10 space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "block",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						htmlFor: "auth-email",
						className: "text-xs uppercase tracking-[0.2em] text-muted-foreground",
						children: "Email"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "auth-email",
						name: "email",
						autoComplete: "email",
						required: true,
						type: "email",
						value: email,
						onChange: (e) => setEmail(e.target.value),
						className: "mt-1 w-full border border-border bg-background px-3 py-2.5"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "block",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						htmlFor: "auth-password",
						className: "text-xs uppercase tracking-[0.2em] text-muted-foreground",
						children: "Password"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "auth-password",
						name: "password",
						autoComplete: "current-password",
						required: true,
						type: "password",
						minLength: 6,
						value: password,
						onChange: (e) => setPassword(e.target.value),
						className: "mt-1 w-full border border-border bg-background px-3 py-2.5"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex justify-center py-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(re, {
						ref: captchaRef,
						sitekey: "0c24ffaa-a79e-437e-b262-f0382f983c2a",
						onVerify: (token) => setCaptchaToken(token),
						onExpire: () => setCaptchaToken(null)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					disabled: busy,
					className: "w-full bg-foreground px-6 py-3 text-xs uppercase tracking-[0.25em] text-background hover:bg-foreground/85 disabled:opacity-50",
					children: busy ? "Please wait…" : "Sign in"
				})
			]
		})]
	});
}
//#endregion
export { AuthPage as component };
