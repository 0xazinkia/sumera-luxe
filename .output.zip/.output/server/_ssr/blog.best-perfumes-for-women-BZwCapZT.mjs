import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { c as productsQuery } from "./queries-CN01OqZx.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as ProductCard } from "./product-card-D_y4dTHQ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/blog.best-perfumes-for-women-BZwCapZT.js
var import_jsx_runtime = require_jsx_runtime();
function BestPerfumes() {
	const perfumes = (useQuery(productsQuery()).data ?? []).filter((p) => p.category?.slug === "perfumes").slice(0, 10);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mx-auto max-w-4xl px-4 py-14 md:px-8 md:py-20",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[11px] uppercase tracking-[0.35em] text-gold",
						children: "The Edit"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 font-serif text-4xl md:text-5xl",
						children: "The 10 Best Luxury Perfumes for Women"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "gold-rule mt-4" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mx-auto mt-6 max-w-2xl text-sm leading-relaxed text-muted-foreground",
						children: "A quiet-luxury guide to the fragrances worth wearing this season — from soft floral daywear to warm, radiant evening scents. Every piece here is hand-picked by the Suméra Luxe atelier for its craftsmanship, longevity and elegance on skin."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "prose prose-neutral mt-12 max-w-none font-serif text-lg leading-relaxed",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-2xl",
						children: "How to choose a luxury perfume"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 text-sm leading-relaxed text-muted-foreground font-sans",
						children: [
							"A great fragrance is less about trend and more about the version of yourself you want to show up as. Consider three things: ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: "occasion" }),
							" ",
							"(day, work, evening, gifting), ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: "family" }),
							" (floral, oriental, woody, gourmand), and ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: "longevity" }),
							" — luxury perfumes are usually eau de parfum or extrait, which sit closer to the skin and last longer than eau de toilette."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-10 font-serif text-2xl",
						children: "Editor's picks"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm leading-relaxed text-muted-foreground font-sans",
						children: "Below are our current favourites from the Suméra Luxe collection — each chosen for the kind of woman who prefers considered, wearable luxury over anything loud."
					})
				]
			}),
			perfumes.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-10 grid grid-cols-2 gap-4 md:grid-cols-3 md:gap-8",
				children: perfumes.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCard, { product: p }, p.id))
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-10 text-center text-sm text-muted-foreground",
				children: [
					"Our perfume collection is being restocked.",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/products",
						search: { q: void 0 },
						className: "underline",
						children: "Browse the wider shop"
					}),
					"."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-16 border-t border-border pt-10 text-sm leading-relaxed text-muted-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-2xl text-foreground",
						children: "Styling notes for different occasions"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-4 space-y-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
								className: "text-foreground",
								children: "Daytime & work:"
							}), " Choose soft florals, citrus or clean musks. They read polished without filling the room."] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
								className: "text-foreground",
								children: "Evening & occasion:"
							}), " Warm orientals, ambers and gourmands carry beautifully after dark and layer well over silk and cashmere."] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
								className: "text-foreground",
								children: "Gifting:"
							}), " When in doubt, a universal floral-woody in an eau de parfum concentration is the safest luxury gift."] })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-10 text-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/category/$slug",
							params: { slug: "perfumes" },
							className: "inline-block bg-foreground px-6 py-3 text-xs uppercase tracking-[0.25em] text-background hover:bg-foreground/85",
							children: "Shop the full perfume collection"
						})
					})
				]
			})
		]
	});
}
//#endregion
export { BestPerfumes as component };
