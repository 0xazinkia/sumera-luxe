import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { t as bannersQuery, u as siteSettingsQuery } from "./queries-CN01OqZx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/hooks-BIqWSPKp.js
function useSiteSettings() {
	return useQuery(siteSettingsQuery()).data ?? null;
}
function useBanners() {
	return useQuery(bannersQuery()).data ?? [];
}
function useBannerBySlot(slot) {
	return useBanners().find((b) => b.slot === slot) ?? null;
}
//#endregion
export { useSiteSettings as n, useBannerBySlot as t };
