import { r as categoryBySlugQuery } from "./queries-CN01OqZx.mjs";
import { P as notFound, m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/category._slug-C_fhD6L2.js
var $$splitNotFoundComponentImporter = () => import("./category._slug-DBXono55.mjs");
var $$splitComponentImporter = () => import("./category._slug-WVxs0ZPn.mjs");
var Route = createFileRoute("/category/$slug")({
	loader: async ({ params, context }) => {
		const category = await context.queryClient.ensureQueryData(categoryBySlugQuery(params.slug));
		if (!category) throw notFound();
		return { category };
	},
	head: ({ loaderData }) => {
		if (!loaderData) return { meta: [{ title: "Category — Suméra Luxe" }, {
			name: "robots",
			content: "noindex"
		}] };
		const c = loaderData.category;
		const image = c.image_url ?? void 0;
		const url = `https://sumeraluxe.com/category/${c.slug}`;
		return {
			meta: [
				{ title: `${c.name} in Bangladesh — Suméra Luxe` },
				{
					name: "description",
					content: `Shop ${c.name} at Suméra Luxe — curated luxury beauty in Bangladesh with cash on delivery in Dhaka and nationwide.`
				},
				{
					property: "og:title",
					content: `${c.name} in Bangladesh — Suméra Luxe`
				},
				{
					property: "og:description",
					content: `Shop ${c.name} at Suméra Luxe — cash on delivery across Bangladesh.`
				},
				{
					property: "og:locale",
					content: "en_BD"
				},
				{
					property: "og:url",
					content: url
				},
				...image ? [{
					property: "og:image",
					content: image
				}, {
					name: "twitter:image",
					content: image
				}] : []
			],
			links: [{
				rel: "canonical",
				href: url
			}],
			scripts: [{
				type: "application/ld+json",
				children: JSON.stringify({
					"@context": "https://schema.org",
					"@type": "CollectionPage",
					name: `${c.name} — Suméra Luxe`,
					url,
					inLanguage: "en-BD",
					isPartOf: {
						"@type": "WebSite",
						name: "Suméra Luxe",
						url: "https://sumeraluxe.com"
					},
					about: {
						"@type": "Country",
						name: "Bangladesh"
					},
					...image ? { image } : {}
				})
			}]
		};
	},
	component: lazyRouteComponent($$splitComponentImporter, "component"),
	notFoundComponent: lazyRouteComponent($$splitNotFoundComponentImporter, "notFoundComponent")
});
//#endregion
export { Route as t };
