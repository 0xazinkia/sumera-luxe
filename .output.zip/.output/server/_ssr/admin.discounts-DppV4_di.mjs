import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-C1p6U3vi.mjs";
import { n as require_react } from "../_libs/hcaptcha__react-hcaptcha+react.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { i as useQueryClient, n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { i as discountCodesQuery } from "./queries-CN01OqZx.mjs";
import { g as Plus, h as Save, s as Trash2 } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.discounts-DppV4_di.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var blank = {
	code: "",
	type: "percent",
	value: 10,
	min_subtotal: 0,
	max_uses: null,
	expires_at: null,
	is_active: true
};
function DiscountsAdmin() {
	const qc = useQueryClient();
	const { data } = useQuery(discountCodesQuery());
	const codes = data ?? [];
	const [draft, setDraft] = (0, import_react.useState)(null);
	const refresh = () => qc.invalidateQueries({ queryKey: ["discount-codes"] });
	const save = async () => {
		if (!draft?.code) return toast.error("Code required");
		const payload = {
			code: draft.code.trim().toUpperCase(),
			type: draft.type ?? "percent",
			value: Number(draft.value) || 0,
			min_subtotal: Number(draft.min_subtotal) || 0,
			max_uses: draft.max_uses != null && draft.max_uses !== "" ? Number(draft.max_uses) : null,
			expires_at: draft.expires_at || null,
			is_active: draft.is_active ?? true
		};
		const { error } = await (draft.id ? supabase.from("discount_codes").update(payload).eq("id", draft.id) : supabase.from("discount_codes").insert(payload));
		if (error) return toast.error(error.message);
		toast.success("Saved");
		setDraft(null);
		refresh();
	};
	const remove = async (id) => {
		if (!confirm("Delete this code?")) return;
		const { error } = await supabase.from("discount_codes").delete().eq("id", id);
		if (error) return toast.error(error.message);
		refresh();
	};
	const toggle = async (c) => {
		const { error } = await supabase.from("discount_codes").update({ is_active: !c.is_active }).eq("id", c.id);
		if (error) return toast.error(error.message);
		refresh();
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-serif text-3xl",
					children: "Discount Codes"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => setDraft({ ...blank }),
					className: "inline-flex items-center gap-2 bg-foreground px-5 py-2.5 text-xs uppercase tracking-[0.25em] text-background",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3" }), " New code"]
				})]
			}),
			draft && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 border border-border bg-card p-4 md:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
						label: "Code",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: I,
							value: draft.code ?? "",
							onChange: (e) => setDraft({
								...draft,
								code: e.target.value.toUpperCase()
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
						label: "Type",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: I,
							value: draft.type ?? "percent",
							onChange: (e) => setDraft({
								...draft,
								type: e.target.value
							}),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "percent",
								children: "Percent (%)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "fixed",
								children: "Fixed (Tk. )"
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
						label: "Value",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "number",
							className: I,
							value: draft.value ?? 0,
							onChange: (e) => setDraft({
								...draft,
								value: Number(e.target.value)
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
						label: "Minimum Subtotal (Tk. )",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "number",
							className: I,
							value: draft.min_subtotal ?? 0,
							onChange: (e) => setDraft({
								...draft,
								min_subtotal: Number(e.target.value)
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
						label: "Max Uses (blank = unlimited)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "number",
							className: I,
							value: draft.max_uses ?? "",
							onChange: (e) => setDraft({
								...draft,
								max_uses: e.target.value === "" ? null : Number(e.target.value)
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
						label: "Expires At",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "datetime-local",
							className: I,
							value: draft.expires_at ? String(draft.expires_at).slice(0, 16) : "",
							onChange: (e) => setDraft({
								...draft,
								expires_at: e.target.value ? new Date(e.target.value).toISOString() : null
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center gap-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: draft.is_active ?? true,
							onChange: (e) => setDraft({
								...draft,
								is_active: e.target.checked
							})
						}), " Active"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 md:col-span-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: save,
							className: "inline-flex items-center gap-2 bg-foreground px-5 py-2.5 text-xs uppercase tracking-[0.25em] text-background",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "size-3" }), " Save"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setDraft(null),
							className: "text-xs text-muted-foreground underline",
							children: "Cancel"
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full border-collapse text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-b border-border text-left",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2 pr-3",
								children: "Code"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2 pr-3",
								children: "Discount"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2 pr-3",
								children: "Min"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2 pr-3",
								children: "Used"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2 pr-3",
								children: "Expires"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2 pr-3",
								children: "Active"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {})
						]
					}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [codes.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-b border-border/60",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2 pr-3 font-mono text-xs",
								children: c.code
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2 pr-3",
								children: c.type === "percent" ? `${Number(c.value)}%` : `Tk. ${Number(c.value)}`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "py-2 pr-3",
								children: ["Tk. ", Number(c.min_subtotal)]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "py-2 pr-3",
								children: [c.used_count, c.max_uses != null ? ` / ${c.max_uses}` : ""]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2 pr-3 text-xs text-muted-foreground",
								children: c.expires_at ? new Date(c.expires_at).toLocaleDateString() : "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2 pr-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => toggle(c),
									className: "text-xs underline",
									children: c.is_active ? "Active" : "Inactive"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "py-2 pr-3 text-right",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => setDraft(c),
									className: "mr-3 text-xs underline",
									children: "Edit"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => remove(c.id),
									className: "text-xs text-destructive",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "inline size-3" })
								})]
							})
						]
					}, c.id)), codes.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						colSpan: 7,
						className: "py-10 text-center text-muted-foreground",
						children: "No discount codes yet."
					}) })] })]
				})
			})
		]
	});
}
var I = "w-full border border-border bg-background px-3 py-2 text-sm";
function F({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-1 text-[10px] uppercase tracking-[0.25em] text-muted-foreground",
			children: label
		}), children]
	});
}
//#endregion
export { DiscountsAdmin as component };
