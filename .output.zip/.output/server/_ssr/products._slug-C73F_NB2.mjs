import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/hcaptcha__react-hcaptcha+react.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { c as productsQuery, f as whatsappHrefFor, o as productBySlugQuery, s as productEnquiryMessage, u as siteSettingsQuery } from "./queries-CN01OqZx.mjs";
import { _ as useNavigate, g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { L as Check, N as Copy, _ as Play, d as ShoppingBag, n as X, t as Zap, x as MessageCircle } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as DialogContent, t as Dialog } from "./dialog-CwLzEEob.mjs";
import { t as ProductCard } from "./product-card-D_y4dTHQ.mjs";
import { n as useCart } from "./cart-CreAwi5h.mjs";
import { a as trackAddToCart, c as trackViewItem, r as requestBeginCheckoutIntent } from "./helpers-BVzN2yBE.mjs";
import { a as buildViewItemPayload, t as buildAddToCartPayload } from "./events-_Zkyx5JA.mjs";
import { t as Route } from "./products._slug-DUpJVIAX.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/products._slug-C73F_NB2.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function getYouTubeVideoId(embedUrl) {
	if (!embedUrl) return null;
	const match = embedUrl.match(/embed\/([a-zA-Z0-9_-]+)/);
	return match ? match[1] : null;
}
function getYouTubeEmbedUrl(raw) {
	if (!raw) return null;
	const value = raw.trim();
	if (!value) return null;
	try {
		const url = new URL(value);
		const host = url.hostname.replace(/^www\./, "");
		if (host === "youtube.com" || host === "m.youtube.com" || host === "youtu.be") {
			const videoId = url.searchParams.get("v") ?? url.pathname.split("/").filter(Boolean).pop();
			if (videoId) return `https://www.youtube.com/embed/${videoId}?rel=0&autoplay=1&mute=1`;
		}
		if (host === "youtube-nocookie.com") return value;
	} catch {
		if (value.includes("youtube.com/embed/") || value.includes("youtube-nocookie.com/embed/")) return value;
	}
	return null;
}
function ProductDetail() {
	const { product: initial } = Route.useLoaderData();
	const { data: fresh } = useQuery(productBySlugQuery(initial.slug));
	const product = fresh ?? initial;
	const settingsQuery = useQuery(siteSettingsQuery());
	const settings = settingsQuery.data ?? null;
	const isSettingsLoading = settingsQuery.isPending || settingsQuery.isFetching;
	const currency = settings?.currency_symbol ?? "Tk. ";
	const brand = settings?.brand_name ?? "Suméra Luxe";
	const productBrand = product.brand_name?.trim() || brand;
	const waNumber = settings?.whatsapp_number ?? "8801322126233";
	const cart = useCart();
	const navigate = useNavigate();
	const allProducts = useQuery(productsQuery()).data ?? [];
	const colors = (0, import_react.useMemo)(() => Array.from(new Set(product.variants.map((v) => v.color).filter(Boolean))), [product.variants]);
	const [selectedColor, setSelectedColor] = (0, import_react.useState)(void 0);
	const hasColorOptions = colors.length > 0;
	const sizes = (0, import_react.useMemo)(() => {
		const filtered = hasColorOptions ? product.variants.filter((v) => v.color === selectedColor) : product.variants;
		return Array.from(new Set(filtered.map((v) => v.size).filter((s) => Boolean(s))));
	}, [
		product.variants,
		selectedColor,
		hasColorOptions
	]);
	const [selectedSize, setSelectedSize] = (0, import_react.useState)(void 0);
	const variant = (0, import_react.useMemo)(() => {
		if (hasColorOptions && !selectedColor) return void 0;
		if (sizes.length > 0 && !selectedSize) return void 0;
		return product.variants.find((v) => {
			if (hasColorOptions && v.color !== selectedColor) return false;
			if (sizes.length > 0 && v.size !== selectedSize) return false;
			return true;
		});
	}, [
		product.variants,
		selectedColor,
		selectedSize,
		hasColorOptions,
		sizes.length
	]);
	const videoUrl = (0, import_react.useMemo)(() => getYouTubeEmbedUrl(product.video_url), [product.video_url]);
	const gallery = (0, import_react.useMemo)(() => {
		const baseImages = product.images.map((i) => i.url).filter(Boolean);
		const allVariantImages = product.variants.filter((v) => v.color && v.image_url).map((v) => v.image_url);
		const seenUrls = /* @__PURE__ */ new Set();
		const allImages = [...allVariantImages, ...baseImages].filter((url) => {
			if (seenUrls.has(url)) return false;
			seenUrls.add(url);
			return true;
		});
		const items = [];
		if (videoUrl) {
			const videoId = getYouTubeVideoId(videoUrl);
			items.push({
				type: "video",
				src: videoUrl,
				videoId: videoId ?? void 0
			});
		}
		const seenUrls2 = /* @__PURE__ */ new Set();
		allImages.forEach((url) => {
			if (!url || seenUrls2.has(url)) return;
			seenUrls2.add(url);
			items.push({
				type: "image",
				src: url
			});
		});
		return items;
	}, [
		product.variants,
		product.images,
		videoUrl
	]);
	const mainImageUrl = (0, import_react.useMemo)(() => {
		if (selectedColor) {
			const colorImages = product.variants.filter((v) => v.color === selectedColor && v.image_url).map((v) => v.image_url);
			if (colorImages.length > 0) return colorImages[0];
		}
		return product.images[0]?.url ?? null;
	}, [
		selectedColor,
		product.variants,
		product.images
	]);
	const [activeMedia, setActiveMedia] = (0, import_react.useState)(null);
	const [imageModalOpen, setImageModalOpen] = (0, import_react.useState)(false);
	const [modalImage, setModalImage] = (0, import_react.useState)(null);
	const [cartAddedOpen, setCartAddedOpen] = (0, import_react.useState)(false);
	const [cartAddedImage, setCartAddedImage] = (0, import_react.useState)(null);
	const openImageModal = (src) => {
		setModalImage(src);
		setImageModalOpen(true);
	};
	(0, import_react.useEffect)(() => {
		if (!selectedColor) setSelectedSize(void 0);
	}, [selectedColor]);
	(0, import_react.useEffect)(() => {
		if (selectedColor && sizes.length === 0) setSelectedSize(void 0);
	}, [sizes, selectedColor]);
	(0, import_react.useEffect)(() => {
		if (gallery.length === 0) {
			setActiveMedia(null);
			return;
		}
		setActiveMedia((current) => {
			if (current && gallery.some((item) => item.type === current.type && item.src === current.src)) return current;
			return gallery[0];
		});
	}, [gallery]);
	(0, import_react.useEffect)(() => {
		if (mainImageUrl && selectedColor) {
			const imageItem = gallery.find((item) => item.type === "image" && item.src === mainImageUrl);
			if (imageItem) setActiveMedia(imageItem);
		}
	}, [
		mainImageUrl,
		selectedColor,
		gallery
	]);
	const basePrice = Number(product.base_price);
	const productDiscount = product.discount_price == null ? null : Number(product.discount_price);
	const variantPrice = variant ? Number(variant.price) : void 0;
	const price = (variant && variant.discount_price != null ? Number(variant.discount_price) : void 0) ?? variantPrice ?? productDiscount ?? basePrice;
	const compare = variant ? variantPrice ?? basePrice : basePrice;
	const hasDiscount = price < compare;
	const stock = variant?.stock ?? product.stock;
	const lowStock = stock > 0 && stock < 10;
	const almostSoldOut = stock > 0 && stock < 5;
	const [copied, setCopied] = (0, import_react.useState)(false);
	const [qty, setQty] = (0, import_react.useState)(1);
	const viewItemTrackedRef = (0, import_react.useRef)(null);
	const productUrl = typeof window !== "undefined" ? window.location.href : "";
	const waMsg = productEnquiryMessage(brand, product.name, productUrl);
	(0, import_react.useEffect)(() => {
		if (!product?.id || viewItemTrackedRef.current === product.id) return;
		viewItemTrackedRef.current = product.id;
		trackViewItem(buildViewItemPayload({
			id: product.id,
			name: product.name,
			slug: product.slug,
			category: product.category ? {
				name: product.category.name,
				slug: product.category.slug
			} : null
		}, price, brand, productUrl));
	}, [
		brand,
		price,
		product?.category,
		product?.id,
		product?.name,
		product?.slug,
		productUrl
	]);
	const doAdd = () => {
		const colorMissing = hasColorOptions && !selectedColor;
		const sizeMissing = sizes.length > 0 && !selectedSize;
		if (product.variants.length > 0 && !variant) {
			if (colorMissing && sizeMissing) {
				toast.error("Please select color and size to cart");
				return;
			}
			if (colorMissing) {
				toast.error("Please select color to cart");
				return;
			}
			if (sizeMissing) {
				toast.error("Please select size to cart");
				return;
			}
		}
		cart.add({
			productId: product.id,
			variantId: variant?.id,
			slug: product.slug,
			name: product.name,
			image: variant?.image_url ?? product.images[0]?.url ?? "",
			variantLabel: variant ? variant.size ? `${variant.color}: ${variant.size}` : variant.color : void 0,
			unitPrice: price,
			quantity: qty
		});
		trackAddToCart(buildAddToCartPayload({
			id: product.id,
			name: product.name,
			slug: product.slug,
			category: product.category ? {
				name: product.category.name,
				slug: product.category.slug
			} : null
		}, price, qty, variant ? variant.size ? `${variant.color}: ${variant.size}` : variant.color : void 0, brand, productUrl));
		setCartAddedImage(variant?.image_url ?? product.images[0]?.url ?? null);
		setCartAddedOpen(true);
	};
	const doBuy = () => {
		const colorMissing = hasColorOptions && !selectedColor;
		const sizeMissing = sizes.length > 0 && !selectedSize;
		if (product.variants.length > 0 && !variant) {
			if (colorMissing && sizeMissing) {
				toast.error("Please select color and size to cart");
				return;
			}
			if (colorMissing) {
				toast.error("Please select color to cart");
				return;
			}
			if (sizeMissing) {
				toast.error("Please select size to cart");
				return;
			}
		}
		requestBeginCheckoutIntent();
		doAdd();
		navigate({ to: "/checkout" });
	};
	const copyLink = async () => {
		try {
			await navigator.clipboard.writeText(productUrl);
			setCopied(true);
			setTimeout(() => setCopied(false), 1500);
		} catch {}
	};
	const category = product.category;
	if (isSettingsLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mx-auto max-w-7xl px-4 py-10 md:px-8 md:py-14",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-10 md:grid-cols-2 md:gap-14",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "aspect-[4/5] animate-pulse rounded-sm bg-muted/70" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-4 gap-3",
					children: Array.from({ length: 4 }).map((_, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "aspect-square animate-pulse rounded-sm bg-muted/60" }, index))
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-4 w-24 animate-pulse rounded bg-muted/70" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-10 w-3/4 animate-pulse rounded bg-muted/70" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-4 w-full animate-pulse rounded bg-muted/50" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-4 w-2/3 animate-pulse rounded bg-muted/50" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-12 w-full animate-pulse rounded bg-muted/60" })
				]
			})]
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-7xl px-4 py-10 md:px-8 md:py-14",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-6 text-xs text-muted-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "hover:text-foreground",
						children: "Home"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mx-2",
						children: "/"
					}),
					category && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/category/$slug",
						params: { slug: category.slug },
						className: "hover:text-foreground",
						children: category.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mx-2",
						children: "/"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-foreground",
						children: product.name
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-10 md:grid-cols-2 md:gap-14",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-hidden rounded-sm bg-muted cursor-zoom-in",
					children: activeMedia?.type === "video" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "aspect-video w-full bg-black",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
							src: activeMedia.src,
							title: `${product.name} video`,
							className: "h-full w-full",
							allow: "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture",
							allowFullScreen: true
						})
					}) : activeMedia?.src ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("picture", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("source", {
						srcSet: activeMedia.src.replace(/\.(png|jpe?g|avif)$/i, ".webp"),
						type: "image/webp"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: activeMedia.src,
						alt: product.name,
						loading: activeMedia === gallery[0] ? "eager" : "lazy",
						className: "aspect-video w-full object-cover cursor-pointer hover:opacity-90 transition-opacity",
						onClick: () => openImageModal(activeMedia.src)
					})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "aspect-video w-full bg-muted" })
				}), gallery.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 grid grid-cols-5 gap-2",
					children: gallery.map((item, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setActiveMedia(item),
						className: `overflow-hidden rounded-sm border ${activeMedia?.type === item.type && activeMedia?.src === item.src ? "border-foreground" : "border-border"}`,
						children: item.type === "video" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative aspect-video w-full overflow-hidden bg-black",
							children: [item.videoId && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: `https://img.youtube.com/vi/${item.videoId}/hqdefault.jpg`,
								alt: "Video thumbnail",
								className: "h-full w-full object-cover"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "absolute inset-0 flex items-center justify-center bg-black/30",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-6 fill-white text-white" })
							})]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("picture", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("source", {
							srcSet: item.src.replace(/\.(png|jpe?g|avif)$/i, ".webp"),
							type: "image/webp"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: item.src,
							alt: `${product.name} image ${i + 1}`,
							loading: "lazy",
							className: "aspect-video w-full object-cover"
						})] })
					}, `${item.type}-${item.src}-${i}`))
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-2 text-[11px] uppercase tracking-[0.3em] text-gold",
						children: [category && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: category.name }), productBrand && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-full border border-gold/30 bg-gold/10 px-2 py-1 text-[10px] font-medium tracking-[0.25em] text-gold",
							children: productBrand
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 font-serif text-3xl md:text-4xl",
						children: product.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex items-baseline gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-serif text-3xl",
								children: [currency, price.toLocaleString()]
							}),
							hasDiscount && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-lg text-muted-foreground line-through",
								children: [currency, compare.toLocaleString()]
							}),
							hasDiscount && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "rounded-full bg-accent px-2 py-0.5 text-[10px] font-medium uppercase tracking-wider text-accent-foreground",
								children: [
									"Save ",
									currency,
									(compare - price).toLocaleString()
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 text-xs uppercase tracking-[0.2em] flex flex-wrap gap-2",
						children: [
							stock > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-green-700",
								children: "In Stock"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-destructive",
								children: "Sold Out"
							}),
							stock > 0 && almostSoldOut && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "rounded-full bg-destructive/10 px-2 py-1 text-destructive",
								children: [stock, " items left"]
							}),
							stock > 0 && !almostSoldOut && lowStock && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "rounded-full bg-destructive/10 px-2 py-1 text-destructive",
								children: "Low stock"
							})
						]
					}),
					product.variants.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 grid grid-cols-2 gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mb-3 text-xs uppercase tracking-[0.25em]",
							children: "Color"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap gap-2",
							children: colors.map((color) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => setSelectedColor(color),
								className: `px-4 py-2 text-sm border ${selectedColor === color ? "border-foreground bg-foreground text-background" : "border-border hover:border-foreground"}`,
								children: color
							}, color))
						})] }), sizes.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mb-3 text-xs uppercase tracking-[0.25em]",
							children: "Size"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap gap-2",
							children: sizes.map((size) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => setSelectedSize(size),
								className: `px-4 py-2 text-sm border ${selectedSize === size ? "border-foreground bg-foreground text-background" : "border-border hover:border-foreground"}`,
								children: size
							}, size))
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-8 flex items-center gap-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center border border-border",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => setQty((q) => Math.max(1, q - 1)),
									className: "px-3 py-2",
									children: "−"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "w-10 text-center text-sm",
									children: qty
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => setQty((q) => q + 1),
									className: "px-3 py-2",
									children: "+"
								})
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 grid gap-3 sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: doAdd,
								disabled: stock === 0,
								className: "inline-flex items-center justify-center gap-2 border border-foreground bg-background px-6 py-3 text-xs uppercase tracking-[0.25em] hover:bg-foreground hover:text-background disabled:opacity-40",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingBag, { className: "size-4" }), " Add to Cart"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: doBuy,
								disabled: stock === 0,
								className: "inline-flex items-center justify-center gap-2 bg-foreground px-6 py-3 text-xs uppercase tracking-[0.25em] text-background hover:bg-foreground/85 disabled:opacity-40",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "size-4" }), " Buy Now"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: whatsappHrefFor(waNumber, waMsg),
								target: "_blank",
								rel: "noopener noreferrer",
								className: "sm:col-span-2 inline-flex items-center justify-center gap-2 border border-[#25D366] bg-[#25D366] px-6 py-3 text-xs uppercase text-white hover:opacity-90",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "size-4" }), " Any Issues? Contact WhatsApp"]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: copyLink,
						className: "mt-6 inline-flex items-center gap-2 text-xs text-muted-foreground hover:text-foreground",
						children: [copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4 text-green-700" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" }), copied ? "Link copied" : "Copy product link"]
					})
				] })]
			}),
			(() => {
				const rel = allProducts.filter((p) => p.id !== product.id && p.category?.slug === category?.slug).slice(0, 4);
				const hasDesc = Boolean(product.description);
				const hasSizeChart = Boolean(product.size_chart_url);
				if (rel.length === 0 && !hasDesc && !hasSizeChart) return null;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [(hasDesc || hasSizeChart) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "mt-16 md:mt-20 max-w-5xl",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-8 lg:grid-cols-[minmax(0,1.4fr)_minmax(280px,0.8fr)]",
						children: [hasDesc && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mb-4 text-[11px] uppercase tracking-[0.3em] text-gold",
							children: "Description"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm leading-relaxed text-muted-foreground whitespace-pre-line",
							children: product.description
						})] }), hasSizeChart && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded border border-border bg-card p-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mb-4 text-[11px] uppercase tracking-[0.3em] text-gold",
								children: "Size Chart"
							}), /\.(png|jpe?g|webp|avif|gif|svg)$/i.test(product.size_chart_url) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: product.size_chart_url,
								alt: `${product.name} size chart`,
								className: "w-full rounded object-contain"
							}) : /\.pdf$/i.test(product.size_chart_url) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
								src: product.size_chart_url,
								title: `${product.name} size chart`,
								className: "min-h-[420px] w-full rounded border border-border"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm leading-relaxed text-muted-foreground",
									children: "Open the size chart for this product."
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: product.size_chart_url,
									target: "_blank",
									rel: "noreferrer",
									className: "inline-flex items-center text-sm font-medium underline",
									children: "Open size chart"
								})]
							})]
						})]
					})
				}), rel.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mt-24",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-8 text-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11px] uppercase tracking-[0.35em] text-gold",
							children: "You may also love"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-2 font-serif text-3xl",
							children: "Related pieces"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-2 gap-4 md:grid-cols-4 md:gap-8",
						children: rel.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCard, { product: p }, p.id))
					})]
				})] });
			})(),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: cartAddedOpen,
				onOpenChange: setCartAddedOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent, {
					className: "w-full max-w-md border-0 bg-background p-0 sm:rounded-xl",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col items-center space-y-4 p-8 text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-24 w-24 overflow-hidden rounded-full border border-border bg-muted",
								children: cartAddedImage ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: cartAddedImage,
									alt: product.name,
									className: "h-full w-full object-cover"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-full w-full bg-muted" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-serif text-2xl",
								children: "Added to cart"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-sm text-muted-foreground",
								children: [product.name, " has been added to your bag."]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "w-full grid gap-3 pt-2 sm:grid-cols-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setCartAddedOpen(false),
									className: "inline-flex items-center justify-center border border-foreground px-4 py-3 text-xs uppercase tracking-[0.25em] hover:bg-foreground hover:text-background",
									children: "Continue Shopping"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => {
										requestBeginCheckoutIntent();
										setCartAddedOpen(false);
										navigate({ to: "/checkout" });
									},
									className: "inline-flex items-center justify-center bg-foreground px-4 py-3 text-xs uppercase tracking-[0.25em] text-background hover:bg-foreground/85",
									children: "Go to Checkout"
								})]
							})
						]
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: imageModalOpen,
				onOpenChange: setImageModalOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-w-md w-full p-1 bg-background border-0 flex items-center justify-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => setImageModalOpen(false),
						className: "absolute right-2 top-2 z-50 inline-flex items-center justify-center rounded-full bg-red-600 opacity-100 ring-offset-background transition-opacity hover:opacity-90 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none p-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4 text-yellow-100" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "sr-only",
							children: "Close"
						})]
					}), modalImage && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "aspect-square w-full overflow-hidden",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("picture", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("source", {
							srcSet: modalImage.replace(/\.(png|jpe?g|avif)$/i, ".webp"),
							type: "image/webp"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: modalImage,
							alt: product.name,
							loading: "eager",
							className: "w-full h-full object-cover"
						})] })
					})]
				})
			})
		]
	});
}
//#endregion
export { ProductDetail as component };
