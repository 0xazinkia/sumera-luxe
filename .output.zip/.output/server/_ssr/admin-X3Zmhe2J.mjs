import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-C1p6U3vi.mjs";
import { n as require_react } from "../_libs/hcaptcha__react-hcaptcha+react.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { c as productsQuery, n as categoriesQuery } from "./queries-CN01OqZx.mjs";
import { _ as useNavigate, f as Outlet, g as Link, l as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as DialogOverlay, c as DialogTrigger, i as DialogDescription, n as DialogClose, o as DialogPortal, r as DialogContent, s as DialogTitle, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { C as Megaphone, O as LayoutDashboard, S as Menu, T as LogOut, c as Ticket, k as Image, l as Tag, n as X, p as Settings, r as Users, u as ShoppingCart, y as Package } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-X3Zmhe2J.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Sheet = Dialog;
var SheetTrigger = DialogTrigger;
var SheetPortal = DialogPortal;
var SheetOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {
	className: cn("fixed inset-0 z-50 bg-black/80  data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props,
	ref
}));
SheetOverlay.displayName = DialogOverlay.displayName;
var sheetVariants = cva("fixed z-50 gap-4 bg-background p-6 shadow-lg transition ease-in-out data-[state=closed]:duration-300 data-[state=open]:duration-500 data-[state=open]:animate-in data-[state=closed]:animate-out", {
	variants: { side: {
		top: "inset-x-0 top-0 border-b data-[state=closed]:slide-out-to-top data-[state=open]:slide-in-from-top",
		bottom: "inset-x-0 bottom-0 border-t data-[state=closed]:slide-out-to-bottom data-[state=open]:slide-in-from-bottom",
		left: "inset-y-0 left-0 h-full w-3/4 border-r data-[state=closed]:slide-out-to-left data-[state=open]:slide-in-from-left sm:max-w-sm",
		right: "inset-y-0 right-0 h-full w-3/4 border-l data-[state=closed]:slide-out-to-right data-[state=open]:slide-in-from-right sm:max-w-sm"
	} },
	defaultVariants: { side: "right" }
});
var SheetContent = import_react.forwardRef(({ side = "right", className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
	ref,
	className: cn(sheetVariants({ side }), className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background cursor-pointer transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-secondary",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Close"
		})]
	}), children]
})] }));
SheetContent.displayName = DialogContent.displayName;
var SheetHeader = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col space-y-2 text-center sm:text-left", className),
	...props
});
SheetHeader.displayName = "SheetHeader";
var SheetFooter = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
	...props
});
SheetFooter.displayName = "SheetFooter";
var SheetTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
	ref,
	className: cn("text-lg font-semibold text-foreground", className),
	...props
}));
SheetTitle.displayName = DialogTitle.displayName;
var SheetDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
SheetDescription.displayName = DialogDescription.displayName;
function AdminLayout() {
	const navigate = useNavigate();
	const [role, setRole] = (0, import_react.useState)(void 0);
	const [email, setEmail] = (0, import_react.useState)("");
	const [navOpen, setNavOpen] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setNavOpen(false);
	}, [useRouterState({ select: (s) => s.location.pathname })]);
	(0, import_react.useEffect)(() => {
		(async () => {
			const { data: userRes } = await supabase.auth.getUser();
			if (!userRes.user) return setRole(null);
			setEmail(userRes.user.email ?? "");
			const { data } = await supabase.from("user_roles").select("role").eq("user_id", userRes.user.id);
			const roles = (data ?? []).map((r) => r.role);
			if (roles.includes("admin")) return setRole("admin");
			if (roles.includes("staff")) return setRole("staff");
			const { data: claim } = await supabase.rpc("claim_admin");
			setRole(claim ? "admin" : null);
		})();
	}, []);
	const signOut = async () => {
		await supabase.auth.signOut();
		navigate({ to: "/auth" });
	};
	if (role === void 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "p-10 text-center text-muted-foreground",
		children: "Loading…"
	});
	if (!role) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-lg p-10 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-serif text-2xl",
				children: "Access denied"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted-foreground",
				children: "Your account doesn't have admin or staff access."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: signOut,
				className: "mt-6 border border-foreground px-6 py-3 text-xs uppercase tracking-[0.25em]",
				children: "Sign out"
			})
		]
	});
	const NavContents = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/",
			className: "flex items-center gap-3 border-b border-border px-5 py-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: "/sumera_luxe_logo.png",
				alt: "Suméra Luxe",
				className: "size-9 rounded-full object-cover"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "font-serif text-lg",
				children: ["Suméra ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-gold",
					children: "Luxe"
				})]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
			className: "flex-1 space-y-1 overflow-y-auto p-3",
			children: [
				role === "admin" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminLink, {
					to: "/admin",
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayoutDashboard, { className: "size-[18px]" }),
					children: "Dashboard"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminLink, {
					to: "/admin/orders",
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingCart, { className: "size-[18px]" }),
					children: "Orders"
				}),
				role === "admin" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminLink, {
						to: "/admin/products",
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Package, { className: "size-[18px]" }),
						children: "Products"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminLink, {
						to: "/admin/categories",
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tag, { className: "size-[18px]" }),
						children: "Categories"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminLink, {
						to: "/admin/discounts",
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ticket, { className: "size-[18px]" }),
						children: "Discount Codes"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminLink, {
						to: "/admin/hero-slides",
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Image, { className: "size-[18px]" }),
						children: "Hero Slides"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminLink, {
						to: "/admin/banners",
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Megaphone, { className: "size-[18px]" }),
						children: "Banners"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminLink, {
						to: "/admin/team",
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-[18px]" }),
						children: "Team & Roles"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminLink, {
						to: "/admin/settings",
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "size-[18px]" }),
						children: "Settings"
					})
				] })
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-3 border-t border-border p-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "truncate text-xs text-muted-foreground",
				children: email
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "flex-1 border border-border px-3 py-2 text-center text-xs uppercase tracking-[0.15em] hover:bg-muted",
					children: "View shop"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: signOut,
					className: "flex items-center gap-1.5 bg-destructive px-3 py-2 text-xs uppercase tracking-[0.15em] text-destructive-foreground hover:opacity-90",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "size-4" }), " Sign out"]
				})]
			})]
		})
	] });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background md:grid md:grid-cols-[260px_1fr]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-30 flex items-center gap-3 border-b border-border bg-card px-4 py-3 md:hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
					open: navOpen,
					onOpenChange: setNavOpen,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTrigger, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							"aria-label": "Open menu",
							className: "grid size-9 place-items-center rounded-md border border-border",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
						side: "left",
						className: "flex w-72 flex-col p-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, {
							className: "sr-only",
							children: "Admin navigation"
						}), NavContents]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-w-0 items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/sumera_luxe_logo.png",
						alt: "",
						className: "size-7 shrink-0 rounded-full object-cover"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "truncate font-serif text-base",
						children: ["Suméra ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-gold",
							children: "Luxe"
						})]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
				className: "hidden flex-col border-border bg-card md:sticky md:top-0 md:flex md:h-screen md:border-r",
				children: NavContents
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "min-w-0 p-4 sm:p-5 md:p-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
			})
		]
	});
}
function AdminLink({ to, icon, children }) {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to,
		className: `flex items-center gap-3 rounded-md px-3 py-2.5 text-sm transition-colors ${(to === "/admin" ? pathname === "/admin" : pathname.startsWith(to)) ? "bg-muted font-medium text-foreground" : "text-muted-foreground hover:bg-muted/60 hover:text-foreground"}`,
		children: [
			icon,
			" ",
			children
		]
	});
}
function AdminDashboardStats() {
	const products = useQuery(productsQuery()).data ?? [];
	const cats = useQuery(categoriesQuery()).data ?? [];
	return {
		products: products.length,
		categories: cats.length
	};
}
//#endregion
export { AdminDashboardStats, AdminLayout as component };
