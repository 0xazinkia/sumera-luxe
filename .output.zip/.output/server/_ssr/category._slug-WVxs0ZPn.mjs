import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { c as productsQuery } from "./queries-CN01OqZx.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as ProductCard } from "./product-card-D_y4dTHQ.mjs";
import { t as Route } from "./category._slug-C_fhD6L2.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/category._slug-WVxs0ZPn.js
var import_jsx_runtime = require_jsx_runtime();
function CategoryPage() {
	const { category } = Route.useLoaderData();
	const products = (useQuery(productsQuery()).data ?? []).filter((p) => p.category?.slug === category.slug);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-7xl px-4 py-12 md:px-8 md:py-16",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative mb-12 overflow-hidden rounded-sm",
			children: [
				category.image_url && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: category.image_url,
					alt: `${category.name} collection banner`,
					className: "h-48 w-full object-cover md:h-72"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-r from-background/85 to-background/30" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute inset-0 flex items-center px-8 md:px-14",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11px] uppercase tracking-[0.35em] text-gold",
							children: "The Collection"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-2 font-serif text-4xl md:text-5xl",
							children: category.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-sm text-muted-foreground",
							children: [products.length, " pieces"]
						})
					] })
				})
			]
		}), products.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "py-24 text-center text-muted-foreground",
			children: ["Nothing here yet. ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/products",
				search: { q: void 0 },
				className: "underline",
				children: "View all products"
			})]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-2 gap-4 md:grid-cols-4 md:gap-8",
			children: products.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCard, { product: p }, p.id))
		})]
	});
}
//#endregion
export { CategoryPage as component };
