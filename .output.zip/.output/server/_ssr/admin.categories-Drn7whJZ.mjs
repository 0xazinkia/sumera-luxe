import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-C1p6U3vi.mjs";
import { n as require_react } from "../_libs/hcaptcha__react-hcaptcha+react.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { i as useQueryClient, n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { n as categoriesQuery } from "./queries-CN01OqZx.mjs";
import { a as Upload, g as Plus, k as Image, s as Trash2, v as Pencil } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-CwLzEEob.mjs";
import { i as uploadOptimizedImage, n as isLocalUploadUrl, t as deleteLocalUploads } from "./image-upload-Dmd5qsio.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.categories-Drn7whJZ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function slugify(s) {
	return s.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
}
function emptyForm(sortOrder) {
	return {
		name: "",
		slug: "",
		tagline: "",
		image_url: "",
		sort_order: sortOrder
	};
}
function CategoriesAdmin() {
	const qc = useQueryClient();
	const cats = useQuery(categoriesQuery()).data ?? [];
	const [dialogOpen, setDialogOpen] = (0, import_react.useState)(false);
	const [editingCategory, setEditingCategory] = (0, import_react.useState)(null);
	const [form, setForm] = (0, import_react.useState)(emptyForm(0));
	const [uploadingImage, setUploadingImage] = (0, import_react.useState)(false);
	const [pendingCategoryImageFile, setPendingCategoryImageFile] = (0, import_react.useState)(null);
	const [resetCategoryImage, setResetCategoryImage] = (0, import_react.useState)(false);
	const refresh = () => qc.invalidateQueries({ queryKey: ["categories"] });
	const openCreateDialog = () => {
		setEditingCategory(null);
		setForm(emptyForm(cats.length + 1));
		setResetCategoryImage(false);
		setDialogOpen(true);
	};
	const openEditDialog = (category) => {
		setEditingCategory(category);
		setForm({
			name: category.name,
			slug: category.slug,
			tagline: category.tagline ?? "",
			image_url: category.image_url ?? "",
			sort_order: category.sort_order
		});
		setDialogOpen(true);
		setResetCategoryImage(false);
	};
	const closeDialog = () => {
		setDialogOpen(false);
		setEditingCategory(null);
	};
	const handleImagePick = (event) => {
		const file = event.target.files?.[0];
		if (!file) return;
		setPendingCategoryImageFile(file);
		setResetCategoryImage(false);
		toast.success("Image selected — it will be saved when you click Save");
		event.target.value = "";
	};
	const save = async () => {
		if (!form.name.trim()) return toast.error("Name required");
		setUploadingImage(true);
		try {
			const name = form.name.trim();
			const slug = (form.slug || slugify(name)).trim();
			let imageUrl = form.image_url.trim() || null;
			const deleteOldUrls = [];
			if (pendingCategoryImageFile) {
				const result = await uploadOptimizedImage(pendingCategoryImageFile, {
					folder: "category-images",
					prefix: slug || "category"
				});
				if (isLocalUploadUrl(form.image_url) && form.image_url !== result.url) deleteOldUrls.push(form.image_url);
				imageUrl = result.url;
			}
			if (resetCategoryImage && editingCategory && isLocalUploadUrl(editingCategory.image_url) && editingCategory.image_url !== imageUrl) deleteOldUrls.push(editingCategory.image_url);
			const payload = {
				name,
				slug,
				tagline: form.tagline.trim() || null,
				image_url: imageUrl,
				sort_order: Number(form.sort_order) || 0
			};
			if (editingCategory) {
				const { error } = await supabase.from("categories").update(payload).eq("id", editingCategory.id);
				if (error) throw error;
				toast.success("Category updated");
			} else {
				const { error } = await supabase.from("categories").insert(payload);
				if (error) throw error;
				toast.success("Category created");
			}
			if (deleteOldUrls.length) deleteLocalUploads(deleteOldUrls).catch(() => {
				console.warn("Failed to delete old local category image(s)", deleteOldUrls);
			});
			setPendingCategoryImageFile(null);
			closeDialog();
			refresh();
		} catch (error) {
			toast.error(error?.message ?? "Failed to save");
		} finally {
			setUploadingImage(false);
		}
	};
	const remove = async (c) => {
		if (!confirm(`Delete "${c.name}"? Products in it will be uncategorized.`)) return;
		const { error } = await supabase.from("categories").delete().eq("id", c.id);
		if (error) return toast.error(error.message);
		const localUrls = [c.image_url].filter(isLocalUploadUrl);
		if (localUrls.length) deleteLocalUploads(localUrls).catch(() => {
			console.warn("Failed to delete local category image", localUrls);
		});
		toast.success("Deleted");
		refresh();
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-serif text-3xl",
					children: "Categories"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: openCreateDialog,
					className: "inline-flex items-center gap-2 bg-foreground px-4 py-2 text-xs uppercase tracking-[0.25em] text-background",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3" }), " Add Category"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto border border-border",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "bg-muted",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "text-left",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2",
									children: "Category"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2",
									children: "Tagline"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2",
									children: "Order"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2 text-right",
									children: "Actions"
								})
							]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [cats.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-t border-border",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3",
									children: [c.image_url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: c.image_url,
										alt: "",
										className: "h-10 w-10 rounded object-cover"
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex h-10 w-10 items-center justify-center rounded bg-muted text-muted-foreground",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Image, { className: "size-4" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-medium",
										children: c.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-xs text-muted-foreground",
										children: ["/", c.slug]
									})] })]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-2 text-muted-foreground",
								children: c.tagline || "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-2",
								children: c.sort_order
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-end gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: () => openEditDialog(c),
										className: "inline-flex items-center gap-1 border border-border px-3 py-1 text-xs",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-3" }), " Edit"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => remove(c),
										className: "inline-flex items-center gap-1 border border-destructive/40 px-3 py-1 text-xs text-destructive",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3" })
									})]
								})
							})
						]
					}, c.id)), cats.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						colSpan: 4,
						className: "px-3 py-8 text-center text-muted-foreground",
						children: "No categories yet."
					}) })] })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: dialogOpen,
				onOpenChange: (open) => open ? setDialogOpen(true) : closeDialog(),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-w-2xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: editingCategory ? "Edit Category" : "New Category" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Fill in the details below and save when you are ready." })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-4 sm:grid-cols-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Name",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: inputCls,
										value: form.name,
										onChange: (e) => setForm((prev) => ({
											...prev,
											name: e.target.value,
											slug: prev.slug || slugify(e.target.value)
										}))
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Slug",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: inputCls,
										value: form.slug,
										onChange: (e) => setForm((prev) => ({
											...prev,
											slug: e.target.value
										}))
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Tagline",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: inputCls,
										value: form.tagline,
										onChange: (e) => setForm((prev) => ({
											...prev,
											tagline: e.target.value
										}))
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Image",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "file",
												accept: "image/*",
												className: inputCls,
												onChange: handleImagePick
											}),
											uploadingImage && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs text-muted-foreground",
												children: "Saving image…"
											}),
											pendingCategoryImageFile && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs text-muted-foreground",
												children: "New image selected — it will be saved with the category."
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
													type: "button",
													onClick: () => {
														setForm((prev) => ({
															...prev,
															image_url: ""
														}));
														setResetCategoryImage(true);
														toast.success("Image cleared — it will be removed when you click Save");
													},
													className: "inline-flex items-center gap-1 border border-border px-3 py-2 text-xs uppercase tracking-[0.2em]",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3" }), " Clear"]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
													type: "button",
													onClick: () => document.getElementById("category-image-input")?.click(),
													className: "inline-flex items-center gap-1 bg-foreground px-3 py-2 text-xs uppercase tracking-[0.2em] text-background",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-3" }), " Pick file"]
												})]
											}),
											form.image_url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
												src: form.image_url,
												alt: "Category preview",
												className: "h-24 w-full rounded object-cover"
											}) : null,
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												id: "category-image-input",
												type: "file",
												accept: "image/*",
												className: "hidden",
												onChange: handleImagePick
											})
										]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Order",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "number",
										className: inputCls,
										value: form.sort_order,
										onChange: (e) => setForm((prev) => ({
											...prev,
											sort_order: Number(e.target.value) || 0
										}))
									})
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, {
							className: "sm:justify-end",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: closeDialog,
								className: "border border-border px-4 py-2 text-xs uppercase tracking-[0.25em]",
								children: "Cancel"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: save,
								className: "bg-foreground px-4 py-2 text-xs uppercase tracking-[0.25em] text-background",
								children: "Save"
							})]
						})
					]
				})
			})
		]
	});
}
var inputCls = "w-full border border-border bg-background px-3 py-2 text-sm outline-none focus:border-foreground";
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-1 text-[10px] uppercase tracking-[0.25em] text-muted-foreground",
			children: label
		}), children]
	});
}
//#endregion
export { CategoriesAdmin as component };
