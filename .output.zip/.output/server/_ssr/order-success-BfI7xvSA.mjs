import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/order-success-BfI7xvSA.js
var $$splitComponentImporter = () => import("./order-success-BTnUTb9r.mjs");
var Route = createFileRoute("/order-success")({
	validateSearch: (s) => ({
		total: Number(s.total) || 0,
		order: typeof s.order === "string" ? s.order : ""
	}),
	head: () => ({
		meta: [
			{ title: "Order Placed — Suméra Luxe" },
			{
				name: "description",
				content: "Thank you for your Suméra Luxe order — our team will call to confirm delivery details shortly."
			},
			{
				property: "og:title",
				content: "Order Placed — Suméra Luxe"
			},
			{
				property: "og:description",
				content: "Thank you for your Suméra Luxe order — confirmation coming shortly."
			},
			{
				property: "og:url",
				content: "https://sumeraluxe.com/order-success"
			},
			{
				name: "robots",
				content: "noindex"
			}
		],
		links: [{
			rel: "canonical",
			href: "https://sumeraluxe.com/order-success"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
