import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-C1p6U3vi.mjs";
import { n as require_react } from "../_libs/hcaptcha__react-hcaptcha+react.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { i as useQueryClient, n as useQuery, t as queryOptions } from "../_libs/tanstack__react-query.mjs";
import { u as siteSettingsQuery } from "./queries-CN01OqZx.mjs";
import { _ as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { f as ShieldCheck, h as Save } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as SwitchThumb, t as Switch$1 } from "../_libs/@radix-ui/react-switch+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.settings-DnQKr-6l.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Switch = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch$1, {
	className: cn("peer inline-flex h-5 w-9 shrink-0 cursor-pointer items-center rounded-full border-2 border-transparent shadow-sm transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-primary data-[state=unchecked]:bg-input", className),
	...props,
	ref,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchThumb, { className: cn("pointer-events-none block h-4 w-4 rounded-full bg-background shadow-lg ring-0 transition-transform data-[state=checked]:translate-x-4 data-[state=unchecked]:translate-x-0") })
}));
Switch.displayName = Switch$1.displayName;
var trackingSettingsQuery = () => queryOptions({
	queryKey: ["tracking-settings"],
	queryFn: async () => {
		const { data, error } = await supabase.rpc("admin_get_tracking_settings");
		if (error) throw error;
		return (Array.isArray(data) ? data[0] : data) ?? null;
	}
});
var MASKED_TOKEN_PLACEHOLDER = "••••••••••••••••";
function TrackingSettingsSection() {
	const qc = useQueryClient();
	const { data, isPending, isError, error } = useQuery(trackingSettingsQuery());
	const [pixelId, setPixelId] = (0, import_react.useState)("");
	const [capiEnabled, setCapiEnabled] = (0, import_react.useState)(false);
	const [testEventCode, setTestEventCode] = (0, import_react.useState)("");
	const [accessToken, setAccessToken] = (0, import_react.useState)("");
	const [hasStoredToken, setHasStoredToken] = (0, import_react.useState)(false);
	const [saving, setSaving] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!data) return;
		setPixelId(data.meta_pixel_id ?? "");
		setCapiEnabled(Boolean(data.meta_capi_enabled));
		setTestEventCode(data.meta_test_event_code ?? "");
		setHasStoredToken(Boolean(data.has_access_token));
	}, [data]);
	(0, import_react.useEffect)(() => {
		if (isError) toast.error(error instanceof Error ? error.message : "Could not load tracking settings.");
	}, [isError, error]);
	const pixelIdValid = pixelId.trim().length === 0 || /^\d{5,20}$/.test(pixelId.trim());
	const save = async () => {
		if (!pixelId.trim()) return toast.error("Meta Pixel ID is required.");
		if (!pixelIdValid) return toast.error("Meta Pixel ID must contain only digits.");
		if (capiEnabled && !hasStoredToken && !accessToken.trim()) return toast.error("Add a Meta CAPI access token before enabling CAPI.");
		setSaving(true);
		const { error } = await supabase.rpc("admin_save_tracking_settings", {
			_meta_pixel_id: pixelId.trim(),
			_meta_capi_enabled: capiEnabled,
			_meta_test_event_code: testEventCode.trim() || null,
			_meta_access_token: accessToken.trim() || null
		});
		setSaving(false);
		if (error) return toast.error(error.message);
		toast.success("Tracking settings saved");
		setAccessToken("");
		qc.invalidateQueries({ queryKey: ["tracking-settings"] });
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "border-t border-border pt-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-4 text-gold" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-serif text-2xl",
					children: "Tracking Settings"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-[11px] uppercase tracking-[0.2em] text-muted-foreground",
				children: "Meta Conversions API · server-side event forwarding for Purchase, InitiateCheckout, AddToCart, ViewContent."
			}),
			isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 grid gap-4 md:grid-cols-2",
				children: Array.from({ length: 4 }).map((_, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-16 animate-pulse rounded-sm bg-muted/60" }, index))
			}) : isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 text-sm text-destructive",
				children: "Could not load tracking settings. You may not have admin access, or the connection failed."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 grid gap-4 md:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mb-1 text-[10px] uppercase tracking-[0.25em] text-muted-foreground",
								children: "Meta Pixel ID"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: `w-full border bg-background px-3 py-2 text-sm ${pixelIdValid ? "border-border" : "border-destructive"}`,
								value: pixelId,
								onChange: (e) => setPixelId(e.target.value),
								placeholder: "123456789012345"
							}),
							!pixelIdValid && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-xs text-destructive",
								children: "Digits only."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-1 text-[10px] uppercase tracking-[0.25em] text-muted-foreground",
								children: ["Meta CAPI Access Token ", hasStoredToken && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-gold",
									children: "(saved)"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "password",
								className: "w-full border border-border bg-background px-3 py-2 text-sm",
								value: accessToken,
								onChange: (e) => setAccessToken(e.target.value),
								placeholder: hasStoredToken ? MASKED_TOKEN_PLACEHOLDER : "Enter access token",
								autoComplete: "new-password"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-[11px] text-muted-foreground",
								children: "Leave blank to keep the current token. Never shown or sent back to the browser."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mb-1 text-[10px] uppercase tracking-[0.25em] text-muted-foreground",
							children: "Test Event Code (optional)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "w-full border border-border bg-background px-3 py-2 text-sm",
							value: testEventCode,
							onChange: (e) => setTestEventCode(e.target.value),
							placeholder: "TEST12345"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 pt-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
							checked: capiEnabled,
							onCheckedChange: setCapiEnabled
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm",
							children: "Enable Meta CAPI"
						})]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				onClick: save,
				disabled: saving,
				className: "mt-6 inline-flex items-center gap-2 bg-foreground px-6 py-3 text-xs uppercase tracking-[0.25em] text-background disabled:opacity-60",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "size-3" }),
					" ",
					saving ? "Saving…" : "Save Tracking Settings"
				]
			})] })
		]
	});
}
function SettingsAdmin() {
	const navigate = useNavigate();
	const qc = useQueryClient();
	const data = useQuery(siteSettingsQuery()).data;
	const [form, setForm] = (0, import_react.useState)({});
	const [isAdmin, setIsAdmin] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (data) setForm(data);
	}, [data]);
	(0, import_react.useEffect)(() => {
		(async () => {
			const { data: userRes } = await supabase.auth.getUser();
			if (!userRes.user) return navigate({ to: "/auth" });
			const { data: allowed, error: roleError } = await supabase.rpc("has_role", {
				_user_id: userRes.user.id,
				_role: "admin"
			});
			if (roleError) {
				toast.error(roleError.message || "Could not verify admin access.");
				return navigate({ to: "/admin" });
			}
			if (!allowed) return navigate({ to: "/admin" });
			setIsAdmin(true);
		})();
	}, [navigate]);
	if (!isAdmin) return null;
	const save = async () => {
		const payload = {
			brand_name: form.brand_name,
			brand_tagline: form.brand_tagline,
			whatsapp_number: form.whatsapp_number,
			whatsapp_display: form.whatsapp_display,
			contact_email: form.contact_email,
			facebook_url: form.facebook_url,
			instagram_url: form.instagram_url,
			delivery_inside_dhaka: Number(form.delivery_inside_dhaka) || 0,
			delivery_outside_dhaka: Number(form.delivery_outside_dhaka) || 0,
			currency_symbol: form.currency_symbol,
			about_text: form.about_text,
			gtm_head_snippet: form.gtm_head_snippet ?? null,
			gtm_body_snippet: form.gtm_body_snippet ?? null
		};
		const { error } = await supabase.from("site_settings").update(payload).eq("id", 1);
		if (error) return toast.error(error.message);
		toast.success("Settings saved");
		qc.invalidateQueries({ queryKey: ["site-settings"] });
	};
	const set = (k, v) => setForm((p) => ({
		...p,
		[k]: v
	}));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-serif text-3xl",
				children: "Store Settings"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 md:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
						label: "Brand Name",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: I,
							value: form.brand_name ?? "",
							onChange: (e) => set("brand_name", e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
						label: "Brand Tagline",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: I,
							value: form.brand_tagline ?? "",
							onChange: (e) => set("brand_tagline", e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
						label: "WhatsApp Number (intl, no +)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: I,
							value: form.whatsapp_number ?? "",
							onChange: (e) => set("whatsapp_number", e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
						label: "WhatsApp Display",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: I,
							value: form.whatsapp_display ?? "",
							onChange: (e) => set("whatsapp_display", e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
						label: "Contact Email",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: I,
							value: form.contact_email ?? "",
							onChange: (e) => set("contact_email", e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
						label: "Currency Symbol",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: I,
							value: form.currency_symbol ?? "",
							onChange: (e) => set("currency_symbol", e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
						label: "Facebook URL",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: I,
							value: form.facebook_url ?? "",
							onChange: (e) => set("facebook_url", e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
						label: "Instagram URL",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: I,
							value: form.instagram_url ?? "",
							onChange: (e) => set("instagram_url", e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
						label: "Delivery Inside Dhaka (Tk. )",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "number",
							className: I,
							value: form.delivery_inside_dhaka ?? 0,
							onChange: (e) => set("delivery_inside_dhaka", Number(e.target.value))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
						label: "Delivery Outside Dhaka (Tk. )",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "number",
							className: I,
							value: form.delivery_outside_dhaka ?? 0,
							onChange: (e) => set("delivery_outside_dhaka", Number(e.target.value))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "md:col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
							label: "About Text",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								className: I + " min-h-32",
								value: form.about_text ?? "",
								onChange: (e) => set("about_text", e.target.value)
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "md:col-span-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-4 md:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
								label: "GTM / Tracking Snippet (Head)",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									className: I + " min-h-40 font-mono text-xs",
									value: form.gtm_head_snippet ?? "",
									onChange: (e) => set("gtm_head_snippet", e.target.value),
									placeholder: "Paste the script snippets that should load in the head."
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
								label: "GTM / Tracking Snippet (Body)",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									className: I + " min-h-40 font-mono text-xs",
									value: form.gtm_body_snippet ?? "",
									onChange: (e) => set("gtm_body_snippet", e.target.value),
									placeholder: "Paste the noscript or body fallback snippets here."
								})
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-[11px] uppercase tracking-[0.2em] text-muted-foreground",
							children: "Use this for GTM, GA4, Meta Pixel, and other tracking snippets."
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				onClick: save,
				className: "inline-flex items-center gap-2 bg-foreground px-6 py-3 text-xs uppercase tracking-[0.25em] text-background",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "size-3" }), " Save Settings"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrackingSettingsSection, {})
		]
	});
}
var I = "w-full border border-border bg-background px-3 py-2 text-sm";
function F({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-1 text-[10px] uppercase tracking-[0.25em] text-muted-foreground",
			children: label
		}), children]
	});
}
//#endregion
export { SettingsAdmin as component };
