import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as useSiteSettings } from "./hooks-BIqWSPKp.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/about-Bdk8_JzB.js
var import_jsx_runtime = require_jsx_runtime();
function AboutPage() {
	const brand = useSiteSettings()?.brand_name ?? "Suméra Luxe";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mx-auto max-w-4xl px-4 py-14 md:px-8 md:py-20",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[11px] uppercase tracking-[0.35em] text-gold",
						children: "Our Story"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "mt-2 font-serif text-4xl md:text-5xl",
						children: ["About ", brand]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "gold-rule mt-4" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mx-auto mt-6 max-w-2xl text-sm leading-relaxed text-muted-foreground",
						children: "A quiet-luxury beauty house created in Bangladesh, for the modern Bangladeshi woman who values craft, restraint and quality above trend."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-12 space-y-6 text-[15px] leading-[1.85] text-foreground/85",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [brand, " was founded in Dhaka with a simple belief — that luxury beauty should feel personal, considered and made to last. From our first fragrance to the newest gifting edit, every piece we release is chosen for its craftsmanship, longevity on skin and the quiet confidence it gives the woman wearing it."] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "We work with trusted ateliers and skincare formulators to bring an international standard of luxury to Bangladesh, at prices that respect our customer. Every order is packed by hand in Dhaka and delivered across the country with cash on delivery, because we believe buying something beautiful should feel effortless." })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "mt-12 grid gap-6 md:grid-cols-3",
				children: [
					{
						t: "Considered Craft",
						d: "Small-batch fragrances, refined skincare and gifting curated by our atelier — never mass-market."
					},
					{
						t: "Made for Bangladesh",
						d: "Prices in BDT, cash on delivery nationwide, and customer care over WhatsApp in Bangla and English."
					},
					{
						t: "Quiet Luxury",
						d: "Timeless over trend. Every piece is chosen to last on your vanity, not disappear next season."
					}
				].map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg border border-border/60 bg-cream/40 p-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-serif text-lg",
						children: v.t
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-relaxed text-muted-foreground",
						children: v.d
					})]
				}, v.t))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-14 rounded-lg border border-border/60 bg-cream/50 p-8 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-2xl",
						children: "Discover the collection"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mx-auto mt-3 max-w-xl text-sm text-muted-foreground",
						children: "Perfumes, skincare, makeup and gift sets — hand-picked for the Bangladeshi woman, delivered with care from Dhaka."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 flex flex-wrap justify-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/products",
							search: { q: void 0 },
							className: "rounded-full bg-ink px-6 py-2.5 text-sm text-cream hover:opacity-90",
							children: "Shop all"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/categories",
							className: "rounded-full border border-border/60 px-6 py-2.5 text-sm hover:bg-cream/60",
							children: "Browse categories"
						})]
					})
				]
			})
		]
	});
}
//#endregion
export { AboutPage as component };
