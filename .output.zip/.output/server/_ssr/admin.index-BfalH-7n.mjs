import { t as supabase } from "./client-C1p6U3vi.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { M as DollarSign, o as TrendingUp, u as ShoppingCart, y as Package } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.index-BfalH-7n.js
var import_jsx_runtime = require_jsx_runtime();
async function loadStats() {
	const now = /* @__PURE__ */ new Date();
	const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate()).toISOString();
	const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1).toISOString();
	const [ordersRes, recentRes, productsRes] = await Promise.all([
		supabase.from("orders").select("total,status,created_at"),
		supabase.from("orders").select("id,order_number,customer_name,total,status").order("created_at", { ascending: false }).limit(6),
		supabase.from("products").select("id", {
			count: "exact",
			head: true
		})
	]);
	const orders = ordersRes.data ?? [];
	const billable = (o) => o.status !== "cancelled";
	const activeOrders = orders.filter(billable);
	const today = activeOrders.filter((o) => o.created_at >= startOfDay);
	const month = activeOrders.filter((o) => o.created_at >= startOfMonth);
	const monthlyCancelled = orders.filter((o) => o.status === "cancelled" && o.created_at >= startOfMonth).length;
	const sum = (list) => list.reduce((t, o) => t + Number(o.total ?? 0), 0);
	return {
		todayCount: today.length,
		todayRevenue: sum(today),
		monthCount: month.length,
		monthRevenue: sum(month),
		monthlyCancelled,
		totalProducts: productsRes.count ?? 0,
		recent: recentRes.data ?? []
	};
}
var money = (n) => `Tk. ${Number(n).toLocaleString()}`;
function Dashboard() {
	const { data } = useQuery({
		queryKey: ["admin-dashboard"],
		queryFn: loadStats,
		staleTime: 3e4
	});
	const s = data;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "flex items-start justify-between",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-serif text-4xl",
					children: "Dashboard"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: "Overview of orders and performance"
				})] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-4 gap-2 sm:gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Today",
						value: s?.todayCount ?? 0,
						sub: money(s?.todayRevenue ?? 0),
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingCart, { className: "size-3 sm:size-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Month",
						value: s?.monthCount ?? 0,
						sub: money(s?.monthRevenue ?? 0),
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "size-3 sm:size-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Month cancelled",
						value: s?.monthlyCancelled ?? 0,
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DollarSign, { className: "size-3 sm:size-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Total products",
						value: s?.totalProducts ?? 0,
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Package, { className: "size-3 sm:size-4" })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-lg border border-border bg-card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between border-b border-border px-6 py-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-xl",
						children: "Recent Orders"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/admin/orders",
						className: "text-sm text-gold hover:underline",
						children: "View all →"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "divide-y divide-border",
					children: [(s?.recent ?? []).map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center gap-4 px-6 py-4 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-xs",
								children: o.order_number
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "truncate",
								children: o.customer_name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "ml-auto flex items-center gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { status: o.status }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium",
									children: money(o.total)
								})]
							})
						]
					}, o.id)), (!s || s.recent.length === 0) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "px-6 py-10 text-center text-sm text-muted-foreground",
						children: "No orders yet."
					})]
				})]
			})
		]
	});
}
function Stat({ label, value, sub, icon }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg border border-border bg-card p-3 sm:p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-[9px] uppercase tracking-wider text-muted-foreground sm:text-[11px] sm:tracking-[0.2em]",
					children: label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "flex size-7 items-center justify-center rounded-full bg-muted text-gold sm:size-9",
					children: icon
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 font-serif text-2xl sm:mt-4 sm:text-4xl",
				children: value
			}),
			sub && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-0.5 text-[10px] text-muted-foreground sm:mt-1 sm:text-xs",
				children: sub
			})
		]
	});
}
function StatusPill({ status }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `rounded-full px-2.5 py-1 text-[11px] ${status === "cancelled" ? "bg-destructive/10 text-destructive" : status === "delivered" ? "bg-gold/15 text-gold" : "bg-muted text-muted-foreground"}`,
		children: status
	});
}
//#endregion
export { Dashboard as component };
