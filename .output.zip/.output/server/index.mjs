globalThis.__nitro_main__ = import.meta.url;
import { i as serve, r as NodeResponse } from "./_libs/h3-v2+rou3+srvx.mjs";
import { a as toEventHandler, i as defineLazyEventHandler, n as HTTPError, r as defineHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { i as withoutTrailingSlash, n as joinURL, r as withLeadingSlash, t as decodePath } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/llms.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"2f5-tmINjW+mR6oZAgA5aEABa8LkCh0\"",
		"mtime": "2026-07-30T09:23:59.158Z",
		"size": 757,
		"path": "../public/llms.txt"
	},
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"a1-dmMA7ZPjfkEzx/KX1OJTrOqOeyk\"",
		"mtime": "2026-08-06T11:05:26.087Z",
		"size": 161,
		"path": "../public/robots.txt"
	},
	"/favicon.ico": {
		"type": "image/vnd.microsoft.icon",
		"etag": "\"10f98-hMMpL6ZwuJGHbyJwz6vsdK6nea0\"",
		"mtime": "2026-07-26T10:03:58.000Z",
		"size": 69528,
		"path": "../public/favicon.ico"
	},
	"/seed/cat-gifts.jpg": {
		"type": "image/jpeg",
		"etag": "\"14316-RJuaL0S7exs2wvXDFp8xewWkKXs\"",
		"mtime": "2026-07-26T10:03:58.000Z",
		"size": 82710,
		"path": "../public/seed/cat-gifts.jpg"
	},
	"/seed/cat-bath.jpg": {
		"type": "image/jpeg",
		"etag": "\"15ce4-w64W4/MeKCjvq/8ZdcoU9hVsYH4\"",
		"mtime": "2026-07-26T10:03:58.000Z",
		"size": 89316,
		"path": "../public/seed/cat-bath.jpg"
	},
	"/seed/hero-1.jpg": {
		"type": "image/jpeg",
		"etag": "\"11610-x2YQfDLYZbx1xhPDpGL3dftzhb8\"",
		"mtime": "2026-07-26T10:03:58.000Z",
		"size": 71184,
		"path": "../public/seed/hero-1.jpg"
	},
	"/seed/cat-perfumes.jpg": {
		"type": "image/jpeg",
		"etag": "\"17a5f-1oG8lIyeNLq6LdHnraTNRVF9Si0\"",
		"mtime": "2026-07-26T10:03:58.000Z",
		"size": 96863,
		"path": "../public/seed/cat-perfumes.jpg"
	},
	"/seed/cat-makeup.jpg": {
		"type": "image/jpeg",
		"etag": "\"1b6f6-/2omrEsCtTzzwEI5fIOAyem2u3c\"",
		"mtime": "2026-07-26T10:03:58.000Z",
		"size": 112374,
		"path": "../public/seed/cat-makeup.jpg"
	},
	"/seed/hero-3.jpg": {
		"type": "image/jpeg",
		"etag": "\"13470-0Q2zmAnpX4IgdOcgwRoK3LYCwQ0\"",
		"mtime": "2026-07-26T10:03:58.000Z",
		"size": 78960,
		"path": "../public/seed/hero-3.jpg"
	},
	"/seed/cat-skincare.jpg": {
		"type": "image/jpeg",
		"etag": "\"135fa-2Iv8fNfHEChzrxIEv28e/+2RBIY\"",
		"mtime": "2026-07-26T10:03:58.000Z",
		"size": 79354,
		"path": "../public/seed/cat-skincare.jpg"
	},
	"/seed/product-cream.jpg": {
		"type": "image/jpeg",
		"etag": "\"8394-DRLKAW5eUbiQzXGaWkP52EUVDEM\"",
		"mtime": "2026-07-26T10:03:58.000Z",
		"size": 33684,
		"path": "../public/seed/product-cream.jpg"
	},
	"/seed/product-bodyoil.jpg": {
		"type": "image/jpeg",
		"etag": "\"a0a3-oe0CD+MrWrtY0KIfw6P7foMr0NM\"",
		"mtime": "2026-07-26T10:03:58.000Z",
		"size": 41123,
		"path": "../public/seed/product-bodyoil.jpg"
	},
	"/seed/product-giftbox.jpg": {
		"type": "image/jpeg",
		"etag": "\"c7d6-dXLTZz/xGdqZJVQdWm/7QDUkvOI\"",
		"mtime": "2026-07-26T10:03:58.000Z",
		"size": 51158,
		"path": "../public/seed/product-giftbox.jpg"
	},
	"/seed/product-lipstick.jpg": {
		"type": "image/jpeg",
		"etag": "\"8006-fee1q59jOMS8aLu+dBS2SnVD+8w\"",
		"mtime": "2026-07-26T10:03:58.000Z",
		"size": 32774,
		"path": "../public/seed/product-lipstick.jpg"
	},
	"/seed/hero-2.jpg": {
		"type": "image/jpeg",
		"etag": "\"1ad71-2UVeO0QfUI81Elt6KuNOTcU8CVw\"",
		"mtime": "2026-07-26T10:03:58.000Z",
		"size": 109937,
		"path": "../public/seed/hero-2.jpg"
	},
	"/seed/product-palette.jpg": {
		"type": "image/jpeg",
		"etag": "\"fc4d-2z10PJXZZq8sRbCsNUO07qK8hr4\"",
		"mtime": "2026-07-26T10:03:58.000Z",
		"size": 64589,
		"path": "../public/seed/product-palette.jpg"
	},
	"/seed/product-perfume-rose.jpg": {
		"type": "image/jpeg",
		"etag": "\"c0d6-pNj8FroufsLtr/zXvzw5dVVxYA4\"",
		"mtime": "2026-07-26T10:03:58.000Z",
		"size": 49366,
		"path": "../public/seed/product-perfume-rose.jpg"
	},
	"/seed/product-perfume-amber.jpg": {
		"type": "image/jpeg",
		"etag": "\"899a-mhwuROFtw85R0pfhNJcSIo1afJs\"",
		"mtime": "2026-07-26T10:03:58.000Z",
		"size": 35226,
		"path": "../public/seed/product-perfume-amber.jpg"
	},
	"/seed/product-serum.jpg": {
		"type": "image/jpeg",
		"etag": "\"aedf-uXrPdjahBu6RhEK+GGWEGHH1XQ4\"",
		"mtime": "2026-07-26T10:03:58.000Z",
		"size": 44767,
		"path": "../public/seed/product-serum.jpg"
	},
	"/assets/about-COMIEt3N.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c3c-hCuickNy7PJ05fPSyOM/21IOaus\"",
		"mtime": "2026-08-07T15:12:39.202Z",
		"size": 3132,
		"path": "../public/assets/about-COMIEt3N.js"
	},
	"/seed/promo-banner.jpg": {
		"type": "image/jpeg",
		"etag": "\"1b637-MHKTxHcY9MO4rEhj5aipNzD8OZ0\"",
		"mtime": "2026-07-26T10:03:58.000Z",
		"size": 112183,
		"path": "../public/seed/promo-banner.jpg"
	},
	"/assets/admin-access-CWPq0Mqf.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"424-OC6I8fBnpD4k/DANCDHb6SwXPqo\"",
		"mtime": "2026-08-07T15:12:39.202Z",
		"size": 1060,
		"path": "../public/assets/admin-access-CWPq0Mqf.js"
	},
	"/assets/admin-DysR5kgJ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2735-sMl8lrsugYI1z24uNWi+nfJ9dBg\"",
		"mtime": "2026-08-07T15:12:39.202Z",
		"size": 10037,
		"path": "../public/assets/admin-DysR5kgJ.js"
	},
	"/assets/admin.banners-BMUSPl3S.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2929-gcBG4cpxkz5aIE5wYSDFJO8BzMA\"",
		"mtime": "2026-08-07T15:12:39.202Z",
		"size": 10537,
		"path": "../public/assets/admin.banners-BMUSPl3S.js"
	},
	"/sumera_luxe_logo.png": {
		"type": "image/png",
		"etag": "\"10d4e0-m2FJAhYrQEgoG0bdK6nS6yOrbSY\"",
		"mtime": "2026-07-25T04:39:02.186Z",
		"size": 1103072,
		"path": "../public/sumera_luxe_logo.png"
	},
	"/assets/admin.categories-BG4U0r71.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1dc4-0QJCI2WoWZQaIocJgI3b+KbPOOI\"",
		"mtime": "2026-08-07T15:12:39.202Z",
		"size": 7620,
		"path": "../public/assets/admin.categories-BG4U0r71.js"
	},
	"/assets/admin.discounts-CogtjaHH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"167b-hdJ1RgzxJVcCObkxuMPxlRJPZZc\"",
		"mtime": "2026-08-07T15:12:39.202Z",
		"size": 5755,
		"path": "../public/assets/admin.discounts-CogtjaHH.js"
	},
	"/assets/admin.index-Bzf9wJ8S.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1096-e6v+oeS9hLhCuq07z5h92mXeeik\"",
		"mtime": "2026-08-07T15:12:39.202Z",
		"size": 4246,
		"path": "../public/assets/admin.index-Bzf9wJ8S.js"
	},
	"/assets/admin.hero-slides-QkrSEbO0.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2878-DHqj4H3+Bl5eMuZzPAuYRSrHTBk\"",
		"mtime": "2026-08-07T15:12:39.202Z",
		"size": 10360,
		"path": "../public/assets/admin.hero-slides-QkrSEbO0.js"
	},
	"/assets/admin.orders-Di5uuKeO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"24d8-3FUHNuTdG8MgnLKYsrgBjK8HSKM\"",
		"mtime": "2026-08-07T15:12:39.202Z",
		"size": 9432,
		"path": "../public/assets/admin.orders-Di5uuKeO.js"
	},
	"/assets/admin.products.index-BvJDF3jZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"165b-EZnRva2WxIy3d1hVtic4IGnDsFw\"",
		"mtime": "2026-08-07T15:12:39.202Z",
		"size": 5723,
		"path": "../public/assets/admin.products.index-BvJDF3jZ.js"
	},
	"/assets/admin.products._id-DvJ59jhB.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"566d-LfsnOs2VbloLM/e1sXtBMrCeA0I\"",
		"mtime": "2026-08-07T15:12:39.202Z",
		"size": 22125,
		"path": "../public/assets/admin.products._id-DvJ59jhB.js"
	},
	"/assets/admin.settings-jlXd28hV.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"35f4-s8uZxfV8V/KrLEAA/CshOFi41Ns\"",
		"mtime": "2026-08-07T15:12:39.202Z",
		"size": 13812,
		"path": "../public/assets/admin.settings-jlXd28hV.js"
	},
	"/assets/admin.team-hw4rTkAe.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"cf2-rNWkWdf2qcqJmVCWlJUQTTezdYE\"",
		"mtime": "2026-08-07T15:12:39.202Z",
		"size": 3314,
		"path": "../public/assets/admin.team-hw4rTkAe.js"
	},
	"/assets/auth-CHA-UseP.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4fcc-Eu9RYFKJPvE8B8pWlkrBBTvawc8\"",
		"mtime": "2026-08-07T15:12:39.202Z",
		"size": 20428,
		"path": "../public/assets/auth-CHA-UseP.js"
	},
	"/assets/blog.best-perfumes-for-women-CDY5-_TR.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ec1-Lgzs4WjQ57jW2sFWh1Qz7iGBs6c\"",
		"mtime": "2026-08-07T15:12:39.202Z",
		"size": 3777,
		"path": "../public/assets/blog.best-perfumes-for-women-CDY5-_TR.js"
	},
	"/assets/cart-sxOOBCBl.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"12f8-WAWzBZ80txkQ6FJHlxuxx5LqG9Y\"",
		"mtime": "2026-08-07T15:12:39.218Z",
		"size": 4856,
		"path": "../public/assets/cart-sxOOBCBl.js"
	},
	"/assets/categories-CQsU6e0Y.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5be-HU8jOflHm9E/lYor7xIxsvyLi5o\"",
		"mtime": "2026-08-07T15:12:39.218Z",
		"size": 1470,
		"path": "../public/assets/categories-CQsU6e0Y.js"
	},
	"/assets/category._slug-B6iW0ZwJ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"19a-V5hr35xv6eSalxzipnwWjq8q7D0\"",
		"mtime": "2026-08-07T15:12:39.218Z",
		"size": 410,
		"path": "../public/assets/category._slug-B6iW0ZwJ.js"
	},
	"/assets/category._slug-C7TmuKAZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5bd-bXnbtVCd3PdjV+TV72d/at7yo6A\"",
		"mtime": "2026-08-07T15:12:39.219Z",
		"size": 1469,
		"path": "../public/assets/category._slug-C7TmuKAZ.js"
	},
	"/assets/checkout-BsRuLo7k.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2a60-MhYp89C2fEUDJDUEJgOLgG/IO2w\"",
		"mtime": "2026-08-07T15:12:39.219Z",
		"size": 10848,
		"path": "../public/assets/checkout-BsRuLo7k.js"
	},
	"/assets/ClientOnly-BQ2HqsLz.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"357b-4wksgrttgjWUYhZ11MTul4uZtmU\"",
		"mtime": "2026-08-07T15:12:39.202Z",
		"size": 13691,
		"path": "../public/assets/ClientOnly-BQ2HqsLz.js"
	},
	"/assets/copy-besOSMk9.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e1-SrF7leClHj7xLhrgaPo7rAt8DaY\"",
		"mtime": "2026-08-07T15:12:39.220Z",
		"size": 225,
		"path": "../public/assets/copy-besOSMk9.js"
	},
	"/assets/client-CzLp7i15.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"327e2-cd8uX09OZwAGpD9pVYB/m6tl81c\"",
		"mtime": "2026-08-07T15:12:39.219Z",
		"size": 206818,
		"path": "../public/assets/client-CzLp7i15.js"
	},
	"/assets/dialog-BBcV5vGi.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"844-ZPUIveuLE9B03Hm+KOOKYc4ot8Q\"",
		"mtime": "2026-08-07T15:12:39.220Z",
		"size": 2116,
		"path": "../public/assets/dialog-BBcV5vGi.js"
	},
	"/assets/dist-CO-sSgE8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"731b-goXUjVrKUJj898c04W++UZqRCWg\"",
		"mtime": "2026-08-07T15:12:39.220Z",
		"size": 29467,
		"path": "../public/assets/dist-CO-sSgE8.js"
	},
	"/assets/events-BSX9TTgh.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"508-5rOwSDbnDzwns6eD5d1rwjS2W0o\"",
		"mtime": "2026-08-07T15:12:39.221Z",
		"size": 1288,
		"path": "../public/assets/events-BSX9TTgh.js"
	},
	"/assets/image-BFfS1Et5.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"102-3gPW+v7s32cuHiFzxsZKBeofHMg\"",
		"mtime": "2026-08-07T15:12:39.221Z",
		"size": 258,
		"path": "../public/assets/image-BFfS1Et5.js"
	},
	"/assets/image-upload-Bp-enUog.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7c6-HCqy55puzsNukitvdlwEz/3epEM\"",
		"mtime": "2026-08-07T15:12:39.221Z",
		"size": 1990,
		"path": "../public/assets/image-upload-Bp-enUog.js"
	},
	"/assets/index-BWln93Ke.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"611f1-H5VHz4cnSWjaPRUojpY96wuETNE\"",
		"mtime": "2026-08-07T15:12:39.202Z",
		"size": 397809,
		"path": "../public/assets/index-BWln93Ke.js"
	},
	"/assets/not-found-i5RsCZif.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"76-Trmr7GZIBZuvfg4uM18tBiRtOXg\"",
		"mtime": "2026-08-07T15:12:39.223Z",
		"size": 118,
		"path": "../public/assets/not-found-i5RsCZif.js"
	},
	"/assets/matchContext-3ve4yMhq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8e-/npp7idg8m4LNMP+Cilem+y+ZSI\"",
		"mtime": "2026-08-07T15:12:39.222Z",
		"size": 142,
		"path": "../public/assets/matchContext-3ve4yMhq.js"
	},
	"/assets/link-HTrDkdBQ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1169-xZdCexNpANIJpbISGq9if8aFgVA\"",
		"mtime": "2026-08-07T15:12:39.222Z",
		"size": 4457,
		"path": "../public/assets/link-HTrDkdBQ.js"
	},
	"/assets/jsx-runtime-KJkY8l8U.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2157-uh2PnvJKYWZAlieFni6eRY8YAVs\"",
		"mtime": "2026-08-07T15:12:39.222Z",
		"size": 8535,
		"path": "../public/assets/jsx-runtime-KJkY8l8U.js"
	},
	"/assets/plus-DEL2S65a.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8e-6Ex+yePpy8ASrjShA1H1gFTUw0U\"",
		"mtime": "2026-08-07T15:12:39.224Z",
		"size": 142,
		"path": "../public/assets/plus-DEL2S65a.js"
	},
	"/assets/privacy-cn6VfWl2.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1067-gBIWGvvxgC1sGZKc5putRp1/yAs\"",
		"mtime": "2026-08-07T15:12:39.224Z",
		"size": 4199,
		"path": "../public/assets/privacy-cn6VfWl2.js"
	},
	"/assets/order-success-Cyd9unXp.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b55-4dGieKI4mJCjq1ARcmXZuaI3lHw\"",
		"mtime": "2026-08-07T15:12:39.223Z",
		"size": 2901,
		"path": "../public/assets/order-success-Cyd9unXp.js"
	},
	"/assets/product-card-LU02O4LX.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9f2-Kgj68BW8LtXf6TWv58uHUarpScs\"",
		"mtime": "2026-08-07T15:12:39.224Z",
		"size": 2546,
		"path": "../public/assets/product-card-LU02O4LX.js"
	},
	"/assets/products.index-BzwJZmXq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ae1-AKW7fCHofqhcC8me//9YIpTihXk\"",
		"mtime": "2026-08-07T15:12:39.225Z",
		"size": 2785,
		"path": "../public/assets/products.index-BzwJZmXq.js"
	},
	"/assets/products._slug-DmFFu0-V.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"180-MFBmywOwkcmpNM7u5nJIThvnF20\"",
		"mtime": "2026-08-07T15:12:39.225Z",
		"size": 384,
		"path": "../public/assets/products._slug-DmFFu0-V.js"
	},
	"/assets/products._slug-DZtvVWat.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3f45-k/fmho6Vdwa2wszXoW5j/JXVsGQ\"",
		"mtime": "2026-08-07T15:12:39.224Z",
		"size": 16197,
		"path": "../public/assets/products._slug-DZtvVWat.js"
	},
	"/assets/react-dom-BsrxZfdi.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"dda-/KkbQdWpmEcddLNsaiMx/D5PdtI\"",
		"mtime": "2026-08-07T15:12:39.225Z",
		"size": 3546,
		"path": "../public/assets/react-dom-BsrxZfdi.js"
	},
	"/assets/redirect-1Dss4sOM.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"216-AhfiXwQqYdLrM+uQAOtPHfIddmI\"",
		"mtime": "2026-08-07T15:12:39.225Z",
		"size": 534,
		"path": "../public/assets/redirect-1Dss4sOM.js"
	},
	"/assets/route-fgWHQjZc.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8d-9k1nd31JanvvMPtseFbyCczv2LM\"",
		"mtime": "2026-08-07T15:12:39.225Z",
		"size": 141,
		"path": "../public/assets/route-fgWHQjZc.js"
	},
	"/assets/save-BxyhNpYU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"13c-9o+ccaKQlZT4jTgcb5gw1S45bF4\"",
		"mtime": "2026-08-07T15:12:39.225Z",
		"size": 316,
		"path": "../public/assets/save-BxyhNpYU.js"
	},
	"/assets/routes-COExHxvZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"29b0-z2DhcHDvj8P4stiFI4SVX+H3XQk\"",
		"mtime": "2026-08-07T15:12:39.225Z",
		"size": 10672,
		"path": "../public/assets/routes-COExHxvZ.js"
	},
	"/assets/shipping-returns-DdTdZ2-L.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"10f6-l5D7JNUcAmRVY5BgSrZjTHL3+OY\"",
		"mtime": "2026-08-07T15:12:39.225Z",
		"size": 4342,
		"path": "../public/assets/shipping-returns-DdTdZ2-L.js"
	},
	"/assets/shopping-cart-LavYP9EI.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"258-U8NEMInQC+cPmNc1OBnLby/itrc\"",
		"mtime": "2026-08-07T15:12:39.225Z",
		"size": 600,
		"path": "../public/assets/shopping-cart-LavYP9EI.js"
	},
	"/assets/styles-023XbdU-.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"17aa2-OIxTRbdD2J4858vOQwoS3/Nx2Qc\"",
		"mtime": "2026-08-07T15:12:39.225Z",
		"size": 96930,
		"path": "../public/assets/styles-023XbdU-.css"
	},
	"/assets/terms-VVAkZwlp.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1013-6PC+UDg3Rl+zhTXJk04TFBcauas\"",
		"mtime": "2026-08-07T15:12:39.225Z",
		"size": 4115,
		"path": "../public/assets/terms-VVAkZwlp.js"
	},
	"/assets/track-DpTZE1ev.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"15da-tVulx4YV1o5unZ+47b3r8IsY5s8\"",
		"mtime": "2026-08-07T15:12:39.225Z",
		"size": 5594,
		"path": "../public/assets/track-DpTZE1ev.js"
	},
	"/assets/trash-2-DBYvyXE8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"13d-VPJUUnhXzPbCDAoekjygw94vgA0\"",
		"mtime": "2026-08-07T15:12:39.225Z",
		"size": 317,
		"path": "../public/assets/trash-2-DBYvyXE8.js"
	},
	"/assets/upload-7teenmoa.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"db-UW7oQktiv847eygnowpt53e7jTs\"",
		"mtime": "2026-08-07T15:12:39.225Z",
		"size": 219,
		"path": "../public/assets/upload-7teenmoa.js"
	},
	"/assets/useMatch-BCjhSLD_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"292-6TSTI/EJfG8cKVF9TaYe/mD12T4\"",
		"mtime": "2026-08-07T15:12:39.225Z",
		"size": 658,
		"path": "../public/assets/useMatch-BCjhSLD_.js"
	},
	"/assets/useRouter-DVsENc7m.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"97-RXy+aSzXQ/Ou7MqebK00+gWmwOU\"",
		"mtime": "2026-08-07T15:12:39.225Z",
		"size": 151,
		"path": "../public/assets/useRouter-DVsENc7m.js"
	},
	"/assets/useStore-DhdvUlye.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1560-NW0IYYlfI4C465RDY6RN6zShoeM\"",
		"mtime": "2026-08-07T15:12:39.225Z",
		"size": 5472,
		"path": "../public/assets/useStore-DhdvUlye.js"
	},
	"/assets/utils-CFoPT9p-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8930-333rreQgSBDJxucGsvJlcV5681E\"",
		"mtime": "2026-08-07T15:12:39.225Z",
		"size": 35120,
		"path": "../public/assets/utils-CFoPT9p-.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets-node
function readAsset(id) {
	const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
	return promises.readFile(resolve(serverDir, public_assets_data_default[id].path));
}
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
function getAsset(id) {
	return public_assets_data_default[id];
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/static.mjs
var METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
var EncodingMap = {
	gzip: ".gz",
	br: ".br",
	zstd: ".zst"
};
var static_default = defineHandler((event) => {
	if (event.req.method && !METHODS.has(event.req.method)) return;
	let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
	let asset;
	const encodings = [...(event.req.headers.get("accept-encoding") || "").split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
	for (const encoding of encodings) for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
		const _asset = getAsset(_id);
		if (_asset) {
			asset = _asset;
			id = _id;
			break;
		}
	}
	if (!asset) {
		if (isPublicAssetURL(id)) {
			event.res.headers.delete("Cache-Control");
			throw new HTTPError({ status: 404 });
		}
		return;
	}
	if (encodings.length > 1) event.res.headers.append("Vary", "Accept-Encoding");
	if (event.req.headers.get("if-none-match") === asset.etag) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	const ifModifiedSinceH = event.req.headers.get("if-modified-since");
	const mtimeDate = new Date(asset.mtime);
	if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	if (asset.type) event.res.headers.set("Content-Type", asset.type);
	if (asset.etag && !event.res.headers.has("ETag")) event.res.headers.set("ETag", asset.etag);
	if (asset.mtime && !event.res.headers.has("Last-Modified")) event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
	if (asset.encoding && !event.res.headers.has("Content-Encoding")) event.res.headers.set("Content-Encoding", asset.encoding);
	if (asset.size > 0 && !event.res.headers.has("Content-Length")) event.res.headers.set("Content-Length", asset.size.toString());
	return readAsset(id);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_U0OdXj = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_U0OdXj
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
var globalMiddleware = [toEventHandler(static_default)].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~middleware"].push(...globalMiddleware);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		middleware.push(...h3App["~middleware"]);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/hooks.mjs
function _captureError(error, type) {
	console.error(`[${type}]`, error);
	useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
	process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
	process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
//#endregion
//#region #nitro/virtual/tracing
var tracingSrvxPlugins = [];
//#endregion
//#region node_modules/nitro/dist/presets/node/runtime/node-server.mjs
var _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
var port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
var host = process.env.NITRO_HOST || process.env.HOST;
var cert = process.env.NITRO_SSL_CERT;
var key = process.env.NITRO_SSL_KEY;
var nitroApp = useNitroApp();
serve({
	port,
	hostname: host,
	tls: cert && key ? {
		cert,
		key
	} : void 0,
	fetch: nitroApp.fetch,
	plugins: [...tracingSrvxPlugins]
});
trapUnhandledErrors();
var node_server_default = {};
//#endregion
export { node_server_default as default };
