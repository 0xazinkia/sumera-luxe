//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DX1FdES1.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/Users/Mr. Anonymous/Documents/sumera-luxe/src/routes/__root.tsx",
		children: [
			"/",
			"/_authenticated",
			"/about",
			"/admin-access",
			"/auth",
			"/cart",
			"/categories",
			"/checkout",
			"/fb-feed-12111014.csv",
			"/order-success",
			"/privacy",
			"/shipping-returns",
			"/sitemap.xml",
			"/terms",
			"/track",
			"/blog/best-perfumes-for-women",
			"/category/$slug",
			"/products/$slug",
			"/products/"
		],
		preloads: [
			"/assets/index-BWln93Ke.js",
			"/assets/jsx-runtime-KJkY8l8U.js",
			"/assets/react-dom-BsrxZfdi.js",
			"/assets/useStore-DhdvUlye.js",
			"/assets/ClientOnly-BQ2HqsLz.js",
			"/assets/not-found-i5RsCZif.js",
			"/assets/redirect-1Dss4sOM.js",
			"/assets/link-HTrDkdBQ.js",
			"/assets/useRouter-DVsENc7m.js",
			"/assets/matchContext-3ve4yMhq.js",
			"/assets/useMatch-BCjhSLD_.js",
			"/assets/client-CzLp7i15.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BWln93Ke.js"
		} }]
	},
	"/": {
		filePath: "C:/Users/Mr. Anonymous/Documents/sumera-luxe/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-COExHxvZ.js", "/assets/product-card-LU02O4LX.js"]
	},
	"/_authenticated": {
		filePath: "C:/Users/Mr. Anonymous/Documents/sumera-luxe/src/routes/_authenticated/route.tsx",
		children: ["/_authenticated/admin"],
		preloads: ["/assets/route-fgWHQjZc.js"]
	},
	"/about": {
		filePath: "C:/Users/Mr. Anonymous/Documents/sumera-luxe/src/routes/about.tsx",
		children: void 0,
		preloads: ["/assets/about-COMIEt3N.js"]
	},
	"/admin-access": {
		filePath: "C:/Users/Mr. Anonymous/Documents/sumera-luxe/src/routes/admin-access.tsx",
		children: void 0,
		preloads: ["/assets/admin-access-CWPq0Mqf.js"]
	},
	"/auth": {
		filePath: "C:/Users/Mr. Anonymous/Documents/sumera-luxe/src/routes/auth.tsx",
		children: void 0,
		preloads: ["/assets/auth-CHA-UseP.js"]
	},
	"/cart": {
		filePath: "C:/Users/Mr. Anonymous/Documents/sumera-luxe/src/routes/cart.tsx",
		children: void 0,
		preloads: ["/assets/cart-sxOOBCBl.js", "/assets/trash-2-DBYvyXE8.js"]
	},
	"/categories": {
		filePath: "C:/Users/Mr. Anonymous/Documents/sumera-luxe/src/routes/categories.tsx",
		children: void 0,
		preloads: ["/assets/categories-CQsU6e0Y.js"]
	},
	"/checkout": {
		filePath: "C:/Users/Mr. Anonymous/Documents/sumera-luxe/src/routes/checkout.tsx",
		children: void 0,
		preloads: ["/assets/checkout-BsRuLo7k.js", "/assets/events-BSX9TTgh.js"]
	},
	"/order-success": {
		filePath: "C:/Users/Mr. Anonymous/Documents/sumera-luxe/src/routes/order-success.tsx",
		children: void 0,
		preloads: ["/assets/order-success-Cyd9unXp.js", "/assets/events-BSX9TTgh.js"]
	},
	"/privacy": {
		filePath: "C:/Users/Mr. Anonymous/Documents/sumera-luxe/src/routes/privacy.tsx",
		children: void 0,
		preloads: ["/assets/privacy-cn6VfWl2.js"]
	},
	"/shipping-returns": {
		filePath: "C:/Users/Mr. Anonymous/Documents/sumera-luxe/src/routes/shipping-returns.tsx",
		children: void 0,
		preloads: ["/assets/shipping-returns-DdTdZ2-L.js"]
	},
	"/terms": {
		filePath: "C:/Users/Mr. Anonymous/Documents/sumera-luxe/src/routes/terms.tsx",
		children: void 0,
		preloads: ["/assets/terms-VVAkZwlp.js"]
	},
	"/track": {
		filePath: "C:/Users/Mr. Anonymous/Documents/sumera-luxe/src/routes/track.tsx",
		children: void 0,
		preloads: ["/assets/track-DpTZE1ev.js"]
	},
	"/_authenticated/admin": {
		filePath: "C:/Users/Mr. Anonymous/Documents/sumera-luxe/src/routes/_authenticated/admin.tsx",
		children: [
			"/_authenticated/admin/banners",
			"/_authenticated/admin/categories",
			"/_authenticated/admin/discounts",
			"/_authenticated/admin/hero-slides",
			"/_authenticated/admin/orders",
			"/_authenticated/admin/settings",
			"/_authenticated/admin/team",
			"/_authenticated/admin/",
			"/_authenticated/admin/products/$id",
			"/_authenticated/admin/products/"
		],
		preloads: [
			"/assets/admin-DysR5kgJ.js",
			"/assets/image-BFfS1Et5.js",
			"/assets/shopping-cart-LavYP9EI.js",
			"/assets/utils-CFoPT9p-.js",
			"/assets/dist-CO-sSgE8.js"
		]
	},
	"/blog/best-perfumes-for-women": {
		filePath: "C:/Users/Mr. Anonymous/Documents/sumera-luxe/src/routes/blog.best-perfumes-for-women.tsx",
		children: void 0,
		preloads: ["/assets/blog.best-perfumes-for-women-CDY5-_TR.js", "/assets/product-card-LU02O4LX.js"]
	},
	"/category/$slug": {
		filePath: "C:/Users/Mr. Anonymous/Documents/sumera-luxe/src/routes/category.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/category._slug-B6iW0ZwJ.js",
			"/assets/category._slug-C7TmuKAZ.js",
			"/assets/product-card-LU02O4LX.js"
		]
	},
	"/products/$slug": {
		filePath: "C:/Users/Mr. Anonymous/Documents/sumera-luxe/src/routes/products.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/products._slug-DZtvVWat.js",
			"/assets/copy-besOSMk9.js",
			"/assets/events-BSX9TTgh.js",
			"/assets/dialog-BBcV5vGi.js",
			"/assets/product-card-LU02O4LX.js",
			"/assets/products._slug-DmFFu0-V.js"
		]
	},
	"/products/": {
		filePath: "C:/Users/Mr. Anonymous/Documents/sumera-luxe/src/routes/products.index.tsx",
		children: void 0,
		preloads: ["/assets/products.index-BzwJZmXq.js", "/assets/product-card-LU02O4LX.js"]
	},
	"/_authenticated/admin/banners": {
		filePath: "C:/Users/Mr. Anonymous/Documents/sumera-luxe/src/routes/_authenticated/admin.banners.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.banners-BMUSPl3S.js",
			"/assets/image-upload-Bp-enUog.js",
			"/assets/plus-DEL2S65a.js",
			"/assets/trash-2-DBYvyXE8.js",
			"/assets/upload-7teenmoa.js",
			"/assets/dialog-BBcV5vGi.js"
		]
	},
	"/_authenticated/admin/categories": {
		filePath: "C:/Users/Mr. Anonymous/Documents/sumera-luxe/src/routes/_authenticated/admin.categories.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.categories-BG4U0r71.js",
			"/assets/image-upload-Bp-enUog.js",
			"/assets/plus-DEL2S65a.js",
			"/assets/trash-2-DBYvyXE8.js",
			"/assets/upload-7teenmoa.js",
			"/assets/dialog-BBcV5vGi.js"
		]
	},
	"/_authenticated/admin/discounts": {
		filePath: "C:/Users/Mr. Anonymous/Documents/sumera-luxe/src/routes/_authenticated/admin.discounts.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.discounts-CogtjaHH.js",
			"/assets/plus-DEL2S65a.js",
			"/assets/save-BxyhNpYU.js",
			"/assets/trash-2-DBYvyXE8.js"
		]
	},
	"/_authenticated/admin/hero-slides": {
		filePath: "C:/Users/Mr. Anonymous/Documents/sumera-luxe/src/routes/_authenticated/admin.hero-slides.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.hero-slides-QkrSEbO0.js",
			"/assets/image-upload-Bp-enUog.js",
			"/assets/plus-DEL2S65a.js",
			"/assets/trash-2-DBYvyXE8.js",
			"/assets/upload-7teenmoa.js",
			"/assets/dialog-BBcV5vGi.js"
		]
	},
	"/_authenticated/admin/orders": {
		filePath: "C:/Users/Mr. Anonymous/Documents/sumera-luxe/src/routes/_authenticated/admin.orders.tsx",
		children: void 0,
		preloads: ["/assets/admin.orders-Di5uuKeO.js", "/assets/trash-2-DBYvyXE8.js"]
	},
	"/_authenticated/admin/settings": {
		filePath: "C:/Users/Mr. Anonymous/Documents/sumera-luxe/src/routes/_authenticated/admin.settings.tsx",
		children: void 0,
		preloads: ["/assets/admin.settings-jlXd28hV.js", "/assets/save-BxyhNpYU.js"]
	},
	"/_authenticated/admin/team": {
		filePath: "C:/Users/Mr. Anonymous/Documents/sumera-luxe/src/routes/_authenticated/admin.team.tsx",
		children: void 0,
		preloads: ["/assets/admin.team-hw4rTkAe.js"]
	},
	"/_authenticated/admin/": {
		filePath: "C:/Users/Mr. Anonymous/Documents/sumera-luxe/src/routes/_authenticated/admin.index.tsx",
		children: void 0,
		preloads: ["/assets/admin.index-Bzf9wJ8S.js"]
	},
	"/_authenticated/admin/products/$id": {
		filePath: "C:/Users/Mr. Anonymous/Documents/sumera-luxe/src/routes/_authenticated/admin.products.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.products._id-DvJ59jhB.js",
			"/assets/image-upload-Bp-enUog.js",
			"/assets/plus-DEL2S65a.js",
			"/assets/save-BxyhNpYU.js",
			"/assets/trash-2-DBYvyXE8.js",
			"/assets/upload-7teenmoa.js",
			"/assets/dialog-BBcV5vGi.js"
		]
	},
	"/_authenticated/admin/products/": {
		filePath: "C:/Users/Mr. Anonymous/Documents/sumera-luxe/src/routes/_authenticated/admin.products.index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.products.index-BvJDF3jZ.js",
			"/assets/copy-besOSMk9.js",
			"/assets/image-upload-Bp-enUog.js",
			"/assets/plus-DEL2S65a.js",
			"/assets/trash-2-DBYvyXE8.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
